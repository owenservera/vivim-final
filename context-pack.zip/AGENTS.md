# AGENTS.md — vivim-final Project Instructions

## Project Overview

**vivim-final** is cap-store v1 Knowledge Graph Rebuild — a local-first AI conversation platform built with Bun + Prisma + TypeScript.

- **Runtime:** Bun
- **Language:** TypeScript (strict mode, ESNext target)
- **ORM:** Prisma v6.5
- **Linter/Formatter:** Biome
- **Git Hooks:** Lefthook
- **Testing:** Bun test runner
- **Build:** tsup (ESM + DTS)

## Architecture

13 engines organized in layers:
- **L0-L1:** Provider Knowledge Graph (ProviderRegistrar, ProviderHealthKernel)
- **L2-L3:** Capability System (CapabilityResolutionEngine, CapabilityEngine)
- **L4:** Session & State (ConversationManager, StreamBlockStore)
- **Chrome Layer:** ChromeGovernor (CDP proxy, lifecycle, trace, health)
- **Cross-cutting:** CapabilityEventBus, ConfigManager, StreamParserEngine
- **Lifecycle:** RegistrationAuditor, VersionManager, TelemetryAggregator

Design docs are in `docs/` (fresh set: `docs/README.md` map, `docs/architecture/`,
`docs/runbooks/`, `docs/decisions/`). The old `docs/merged-design-v2/` set is
archived in `.archive/`.

## Binary Size Optimization (CRITICAL)

### Bun Runtime Baseline
- **Bun runtime on Windows:** ~94 MB (irreducible via bundling alone)
- **Our app code:** ~3 MB on top of runtime
- **Total uncompressed:** ~97 MB
- **WASM engines:** NOT embedded by `bun build --compile` (loaded at runtime via `process.dlopen()`)
- **Prisma WASM:** Uses native library mode (`LibraryEngine`), not WASM base64

### UPX Compression (Implemented)
- **Tool:** UPX v5.2.0 (`winget install UPX.UPX`)
- **Optimal settings:** Level 3 with `--no-lzma` for speed/ratio balance
- **Results:**
  - Level 1: 46.4 MB (47.81% ratio, 13.5 seconds)
  - Level 3: 45.6 MB (46.94% ratio, 24.8 seconds) ← **Production default**
  - Level 5: 35.5 MB (36.58% ratio, 68.8 seconds)
- **All compressed binaries verified working** (`--version` returns `1.3.14`)

### Build Pipeline
```bash
# Full desktop build (sidecar + frontend static export + cargo tauri NSIS installer)
pwsh scripts/tauri/build.ps1

# Sidecar-only build (bun compile + UPX level 3 compression)
pwsh scripts/tauri/build-sidecar.ps1

# Manual UPX compression (if needed)
upx -3 --no-lzma src-tauri/binaries/vivim-server-x86_64-pc-windows-msvc.exe
```

### Future Optimizations
- **Bun v1.4.0 (Rust rewrite):** ~20% binary size reduction (76 MB vs 94 MB) — available in canary
- **bkg (Bun Packager):** LZ4 compression with custom runtime decompression
- **NSIS installer:** LZMA compression for installer packaging

## Desktop Build Testing (CRITICAL)

> **When working on Tauri builds, NSIS installers, or desktop packaging — use the devops/desktop toolkit first.** The `devops/desktop/` toolkit (driven by `bun run devops desktop-loop <action>`) provides a 15-action CLI with hash-gated rebuild detection, a 5-gate orchestrator (Build → Install → Launch+Render → Capture → Report), and structured diagnostics.
>
> **Quick start:** `bun run devops desktop-loop run --version <x.y.z>` runs the full 5-gate pipeline end-to-end. For individual checks, use granular actions (`status`, `build`, `install`, `kill`, `launch`, `test smoke`, etc.). All artifacts are stored in `dist/debug/<version>/cycle-N/`.
>
> **Core workflow:** The toolkit wraps the raw Tauri build scripts (`scripts/tauri/build.ps1`, `build-sidecar.ps1`) with verification, process management, port-owner checks, screenshot capture, and structured reporting. It does NOT replace the build scripts — it orchestrates them and validates the *installed* binary.
>
> **Hash-gated rebuilds:** `build.ts` fingerprints source directories (`src/`, `src-tauri/src/`, `frontend/src/`) using sorted mtime+size SHA-256 hashes, version-scoped per stage (`sidecar`, `tauri-rust`, `tauri-frontend`). Unchanged stages skip rebuilds. Cache lives in `dist/build-hashes.json`.
>
> **Test batteries:** `test smoke` (process → readyz → window → screenshot → probe) is the fastest CI gate. `test boot` kills+relaunches fresh. `test http` probes `/readyz`, `/health`, `/api/openapi.json`. `test window` checks window + screenshot. `test process` checks window info. `test all` runs everything.
>
> **Version management:** `scripts/tauri/version.ts` is the single source of truth — reads/writes `tauri.conf.json` + `Cargo.toml` + derives exe metadata at compile time. Always pass `--version` to scope state correctly.

### Desktop DevOps CLI

Full 15-action toolkit at `devops/desktop/` driven by `bun run devops desktop-loop <action>`.

| Action | What It Does | Key Flags |
|--------|-------------|-----------|
| `status` | Check installed exe, processes, port owner, registry key | `--version` |
| `build` | Hash-gated check: sidecar/tauri/frontend changed → skip if unchanged | `--version` (required) |
| `install` | Kill stale → uninstall prior → install NSIS silently (`/S`) | `--version` (required) |
| `uninstall` | Kill stale → uninstall via NSIS QuietUninstallString | |
| `kill` | Kill vivim-desktop.exe + vivim-server.exe | |
| `launch` | Start installed exe → poll /readyz with owner PID verification → wait for window | `--port`, `--timeout`, `--wait-window` |
| `readyz` | Poll /readyz, verify owner PID matches launched process | `--port`, `--timeout` |
| `probe` | HTTP probe a specific path (default `/readyz`) | `--expect`, `--contains`, `--method`, `--body` |
| `screenshot` | Focus window → capture full-screen → assert non-blank via ImageMagick | `--out`, `--focus`, `--verify` |
| `window` | Get window title/handle/responding for vivim-desktop + vivim-server | |
| `process` | Port owner PID + window info for both processes | |
| `logs` | Tail vivim-server.log + vivim-supervisor.log from `%LOCALAPPDATA%\vivim\` | `--tail` |
| `test <battery>` | Run test batteries: smoke, boot, http, window, process, all | battery (positional) |
| `report` | Generate markdown report from last gate cycle | `--version` |
| `reset` | Clear ledger + runtime state | |

### Gate Orchestrator (`run` action)

`bun run devops desktop-loop run --version <x.y.z>` runs a 5-gate pipeline:

```
G1 Build → G2 Install → G3 Launch+Render → G4 Capture (on fail) → G5 Report
```

- **G1 Build:** Hash-gated sidecar + tauri rebuilds. Fingerprints `src/`, `src-tauri/src/`, `frontend/src/` by sorted mtime+size; version-scoped cache at `dist/build-hashes.json`. Skips stages with no changes.
- **G2 Install:** Kill stale processes → uninstall prior via NSIS QuietUninstallString → install with `installer /S`.
- **G3 Launch+Render:** Launch installed exe → poll `/readyz` with owner-PID verification (kills stale servers) → screenshot → `assertNonBlank` via ImageMagick.
- **G4 Capture:** On failure, copy `vivim-server.log` + `vivim-supervisor.log` from `%LOCALAPPDATA%\vivim\` into cycle dir.
- **G5 Report:** Write `report.json` + `report.md` to cycle dir; on success, stage installer to `dist/debug/<version>/`.

**Artifacts:** All cycle outputs go to `dist/debug/<version>/cycle-N/` (`.log` files, screenshots, `report.json`, `report.md`, copied logs).

### Key Files

| File | Purpose |
|------|---------|
| `devops/desktop/index.ts` | CLI entry + 5-gate orchestrator (`runDesktopLoop`). Gates: G1 Build → G2 Install → G3 Launch+Render → G4 Capture (on fail) → G5 Report. |
| `devops/desktop/cli.ts` | Arg parsing (`parseArgs`), action dispatch (`dispatchAction`), per-invocation log tee (`teeConsoleToLog`). All actions return `ActionResult`. |
| `devops/desktop/actions.ts` | 15 action handlers: `status`, `build`, `install`, `uninstall`, `kill`, `launch`, `readyz`, `probe`, `screenshot`, `window`, `process`, `logs`, `test` (batteries: smoke, boot, http, window, process, all), `report`, `reset`. |
| `devops/desktop/spawn.ts` | Streaming output capture (`spawnStreaming`), process management (`killVivimProcesses`, `launchInstalled`), NSIS install/uninstall helpers (`installNsis`, `uninstallNsis`, `getUninstallRegistryKey`). |
| `devops/desktop/verify.ts` | Pure decision logic (`parseNetstat`, `assessReady`, `checkNonBlank`) + PowerShell wrappers (`ownerPidForPort`, `scanPortForPid`, `pollReady`, `windowInfo`, `focusWindow`, `captureScreenshot`, `assertNonBlank`). |
| `devops/desktop/build.ts` | Hash-gated rebuilds (`needsBuild`, `markBuilt`, `dirFingerprint`). Fingerprint = sorted mtime+size SHA-256 over source files. Cache at `dist/build-hashes.json`, version-scoped per stage. |
| `devops/desktop/state.ts` | Ledger (cycle history at `dist/loop-state.json`) + runtime (per-install state at `dist/desktop-runtime.json`). `DesktopRuntime` stores port/PID/readyMs as defaults for granular actions. |
| `scripts/tauri/version.ts` | Single source of truth for desktop version — reads/writes `tauri.conf.json` + `Cargo.toml`. `ensureDesktopVersion(v)` bumps stored copies. `nsisPathFor(v)` derives installer path. |
| `scripts/tauri/compile-sidecar.ts` | Sidecar compilation with UPX compression (Level 3, `--no-lzma`). |
| `scripts/tauri/prepare-frontend.ts` | Next.js build + `out/` generation for Tauri (patches `next.config.mjs` to `output: 'export'`, builds, restores). |

### Tauri V2 Build Config (Post-Upgrade)

The Tauri V2 upgrade removed `tauri-plugin-updater` and WIX/MSi targets entirely.
The current `src-tauri/tauri.conf.json` uses:
- `"targets": ["nsis"]` (NSIS only, no WIX)
- `"createUpdaterArtifacts": false` (no updater artifacts)
- `"plugins": { "shell": { "open": true } }` (no updater plugin)
- `"visible": false` in the window config (window shows on `backend-ready` event)
- CSP includes `'unsafe-eval'` and `'unsafe-inline'` for static JS

### Debugging App Crashes

1. **Run from command line** to capture stderr:
   ```powershell
   & "$env:LOCALAPPDATA\vivim\vivim-desktop.exe" 2>&1
   ```
2. **Check logs** at `%LOCALAPPDATA%\vivim\`:
   - `vivim-supervisor.log` — sidecar spawn/restart events
   - `vivim-server.log` — server boot/port/errors
3. **Use desktop-loop actions** for structured diagnostics:
   ```bash
   bun run devops desktop-loop status     # installed state
   bun run devops desktop-loop logs       # tail app logs
   bun run devops desktop-loop screenshot  # capture window
   bun run devops desktop-loop test smoke  # full smoke battery
   ```

### Desktop Debug Gotchas

#### PowerShell Object-Pipeline Read Bug (CRITICAL)
**`Invoke-RestMethod | Select-Object -ExpandProperty <x> | Out-File` produces EMPTY files / empty output even when the API returns data.** The PowerShell object pipeline drops the deserialized JSON payload before it reaches `Out-File`/`Get-Content`.

**ALWAYS read API/JSON data through a BUN SCRIPT, never through the PowerShell object pipeline:**
```bash
# WRONG — silently yields empty output:
Invoke-RestMethod "http://localhost:$port/api/capabilities?surface=cli" |
  Select-Object -ExpandProperty slug | Out-File -Encoding utf8 file.txt
# CORRECT — write a .ts file and bun run it:
bun run .runtime/list-data.ts   # reads fetch, writes .txt via fs
```

#### `Bun.spawn` exitCode is null
`proc.exitCode` returns `null` until `await proc.exited` resolves. Always await the promise before reading exit code.

#### Smoke tests must have client-side timeouts
Endpoints like `/api/conversations/:id/send` block forever waiting for a CDP browser that isn't attached. Always wrap `fetch` calls with `AbortController` + timeout so the test completes.

### Desktop Dev Workflow Quick Reference

| Task | Command |
|------|---------|
| Full clean build + install + test | `bun run devops desktop-loop run --version <x.y.z>` |
| Check if rebuild needed (no rebuild) | `bun run devops desktop-loop build --version <x.y.z>` |
| Install latest installer silently | `bun run devops desktop-loop install --version <x.y.z>` |
| Launch + verify readyz | `bun run devops desktop-loop launch --version <x.y.z>` |
| Full smoke test (process+window+render) | `bun run devops desktop-loop test smoke` |
| Kill all vivim processes | `bun run devops desktop-loop kill` |
| Tail server+supervisor logs | `bun run devops desktop-loop logs --tail 100` |
| Capture + verify non-blank screenshot | `bun run devops desktop-loop screenshot --verify` |

## Provider System (KNOW THIS FIRST)

### What Providers Exist

The system supports **16 registered providers** (`chatgpt`, `claude`, `deepseek`,
`facebook`, `gemini`, `generic`, `grok`, `mistral`, `opencode`, `qwen`, `slack`,
`studio-ai`, `system`, `telegram`, `whatsapp`, `z-ai`). Of these, **6 are
UI-facing chat providers**: `chatgpt`, `claude`, `gemini`, `deepseek`, `qwen`,
`grok`; the rest are framework/API aliases (`generic`, `system`, `facebook`,
`slack`, `telegram`, `whatsapp`, `studio-ai`, `z-ai`, `opencode`, `mistral`).
Each is seeded from `seeds/providers/manifests.ts` (manifest with endpoints,
parsers, models, capabilities).

### Provider File Layout

| File | Purpose |
|------|---------|
| `seeds/providers/manifests.ts` | Provider manifest definitions (selectors, endpoints, parsers, models) |
| `seeds/parsers/harvested/<slug>-*.ts` | Stream parser `LOGIC_CODE` (inline, DB-driven) |
| `seeds/adapters/<slug>.ts` | Import adapter for external data portability |
| `src/engines/provider-selectors.ts` | CDP selector fallback lists (composer, send button, URL patterns) |
| `src/engines/conversation-manager.ts` | Provider-specific capture patterns + response parsing |

### What "Testing a Provider" Means

Testing a provider is an **8-phase onboarding pipeline** (`devops/onboard-controller.ts`):

```
discover → infer → test-selectors → test-parse → test-cap → test-frontend → verify → converge
```

| Phase | Command | What It Does | Pass Gate |
|-------|---------|-------------|-----------|
| discover | `bun run devops discover-protocol <url> --hint=<name>` | CDP protocol discovery: composer selectors, send method, capture patterns, response DOM | Returns manifest with detected selectors + format |
| infer | `bun run devops runtime-test onboard infer --provider=<slug>` | Infer parser from real streaming data | Confidence >= 0.7 |
| test-selectors | `bun run devops runtime-test onboard test-selectors --provider=<slug>` | Validate all CDP selectors against live DOM | All selectors match |
| test-parse | `bun run devops runtime-test onboard test-parse --provider=<slug>` | Real wire-format parsing against fixtures | All known formats parse |
| test-cap | `bun run devops runtime-test onboard test-cap --provider=<slug>` | Capability registration + execution via `/api/interpret` | Capability resolves |
| test-frontend | `bun run devops runtime-test onboard test-frontend --provider=<slug>` | E2E frontend: canvas mount + capability invoke + DOM assert | UI renders capability |
| verify | `bun run devops runtime-test onboard verify --provider=<slug>` | Final cross-surface verification | CLI + API + MCP + UI all resolve |
| converge | `bun run devops runtime-test onboard converge --provider=<slug>` | Convergence analysis: spec + code + arch alignment | No drift from spec |

### Existing Provider Test Status (Capability Matrix)

Parsers live **only** in the DB (inline `logic_code`, `logic_type=inline`). The
`provider-protocol.ts` static file is generated from the DB. Capabilities are
**provider-bound** (e.g. `send_message`, `select_model`), NOT per-provider UnifiedCapability
slugs like `gemini_send`. Verify a capability via the interpreter, not `--slug=gemini_send`:

| Provider | Status | Parsers (DB) | Capabilities | Gaps |
|----------|--------|--------------|--------------|------|
| claude | `seeded + registered` | `claude/001_streaming_sse` (inline) | `send_message`, `select_model` | none |
| gemini | `seeded + registered` | `gemini/001_batchexecute`, `gemini/002_ai_studio` + generic fallback | `send_message`, `select_model` | no stream_config row (custom batchexecute RPC) |
| chatgpt | `seeded + registered` | `chatgpt/001_openai_delta` (inline) + generic fallback | `send_message` | parser uses API format; wire uses chat UI format — needs real-world validation |
| deepseek | `seeded + registered` | `deepseek/001_reasoning_sse` (inline) | `send_message` | none (reasoning-channel SSE parser seeded) |
| qwen | `seeded` | none configured | `send_message` | no parser row yet |
| grok | `seeded` | none configured | `send_message` | no parser row yet |

> The 16-provider protocol also includes `facebook`, `mistral`, `opencode`,
> `studio-ai`, `z-ai` etc. See `src/__generated__/provider-protocol.ts` for the full list.

### How to Check Provider Status

```bash
# Full preflight (all providers)
bun run devops runtime-test preflight

# Single provider deep-dive
bun run devops runtime-test status --provider=gemini

# Check individual dimensions:
bun run devops runtime-test health                     # DB + server
bun run devops runtime-test setup --provider=gemini --account=gemini_owservera@gmail.com   # Restore profile → launch
bun run devops runtime-test onboard --provider=gemini  # 8-phase onboarding pipeline
bun run devops discover-protocol https://gemini.google.com/app --hint=gemini
bun run devops runtime-test test --nl="send message to gemini"
# Capabilities are provider-bound (e.g. send_message), exposed via the interpreter:
bun run devops runtime-test test --nl="send message to gemini"
```

> **Provider Protocol Data Layer (`src/__generated__/provider-protocol.ts`):**
> The DB is the single source of truth; `bun run gen:protocol` compiles it to a static file
> (plus an editable dev clone `provider-protocol.dev.ts`). During testing/devops you can flip the
> system to read the dev clone and promote fixes back:
> ```bash
> bun run devops protocol dev            # how to set PROVIDER_PROTOCOL_SOURCE=dev
> bun run devops protocol diff           # show dev vs prod provider deltas
> bun run devops protocol promote --provider=gemini   # push dev overrides → DB → regenerate prod
> bun run devops protocol prod           # flip back to prod (default)
> # regen prod, preserving the dev clone (default); --reset-dev resyncs dev from prod
> bun run gen:protocol
> bun run gen:protocol --reset-dev
> ```

### Chrome Profile Layout (CANONICAL — do not deviate)

Chrome slaves (logged-in browser profiles) live **only** under `chrome-profiles/<providerSlug>/<accountId>`:

```
chrome-profiles/
  gemini/owservera/      # one authenticated profile per provider
  chatgpt/owservera/
  claude/owservera/
  discovery/protocol-probe/
```

- This is the resolved `profileBaseDir` (`ProfileAllocator` → `chrome-profiles/`; overridable via `dataDir`/config, see `src/config.ts` + `src/executor/profile-allocator.ts`).
- **Never** create top-level `gemini/`, `chatgpt/`, `claude/` directories at the repo root — those are stray duplicates and get deleted.
- **One account per provider** is the intended steady state (`owservera` for all three). When adopting/cleaning up, keep a single `owservera` profile and delete the rest.
- Each profile dir holds a `.profile-meta.json` (`providerSlug`, `accountId`, `allocatedAt`, `lastUsed`).
- The profile dir is the source of truth for "is this provider authenticated" (`ProfileAllocator.isAuthenticated` checks `Default/Network/Cookies` or `Profile N/Network/Cookies`), not the `Account` DB row.

### CDP Connection Gotchas (Provider-Specific)

- **Gemini** uses Quill-based `div.ql-editor[contenteditable="true"]` composer. Send requires clicking the send button (Enter doesn't work in Quill). Streaming is custom Google RPC batchexecute format (NOT SSE).
- **ChatGPT** uses `#prompt-textarea` / `textarea[data-testid="prompt-textarea"]`. Streaming is `data: {message: {content: {parts: [text]}}}` with `[DONE]` terminator.
- **Claude** uses `div[contenteditable="true"]` with ProseMirror. Streaming is Anthropic SSE format (`data: {type, delta, content_block_start/stop}`).

## Code Conventions

### TypeScript
- Use `@/*` path aliases (maps to `./src/*`)
- Prefer `type` imports: `import type { Foo } from './bar.js'`
- Use `.js` extension in imports (Bun ESM requirement)
- No `any` — use `unknown` + type narrowing
- Use Zod for runtime validation at boundaries
- Prefer `const` over `let`, avoid `var`
- Use ULID for IDs (`src/ids.ts`)
- Export from `src/index.ts` as barrel

### Error Handling
- Custom error classes from `src/errors.ts`
- Never swallow errors silently
- Use `Result<T, E>` pattern where appropriate
- Log errors with context before throwing

### Database
- All schema in Prisma (`prisma/schema.prisma`)
- **Schema changes applied via `bunx prisma db push`** (DDL only — no `_prisma_migrations`; `prisma migrate diff` is authoritative, target is zero drift)
- **Data migrations** (column-value reshaping, backfills) go through the SchemaMeta-backed `MigrationRunner` (`src/storage/migration/`) — wired into boot at `bootstrapSeedsPhase` via `applyPendingMigrations()`. Register new steps in `migrations-registry.ts`. Do NOT add a second migration mechanism.
- Seeds in `seeds/` directory
- Use transactions for multi-table writes
- Never bypass Prisma for raw SQL unless performance-critical
- After any Prisma schema change, rebuild the test fixture: `DATABASE_URL="file:C:/0-BlackBoxProject-0/vivim-final/tests/fixtures/node-store-test.db" bunx prisma db push --skip-generate --accept-data-loss` (use an ABSOLUTE `file:` path — relative ones resolve against `prisma/schema.prisma` and would write to `prisma/tests/fixtures/`)

### Typecheck guardrail (CRITICAL)
- **NEVER run `tsc` / `bunx tsc --noEmit` / `bun run typecheck` unless the human explicitly directs it.**
- Only run a typecheck when the full task list / todos are complete AND you have asked the human first.
- Mid-task typechecking is wasteful (the project has many pre-existing errors in `tests/` owned by other agents). Build the feature first; verify at the human's request.

### Testing
- Unit tests: `tests/unit/` — test individual functions
- Integration tests: `tests/integration/` — test engine interactions with mocked stores
- E2E tests: `tests/e2e/` — full stack tests
- Mock store contracts for unit/isolation tests
- Aim for 80%+ coverage on engines

### File Organization
```
src/
  cli/          # CLI entry points
  config.ts     # Configuration
  engines/      # Core engines (one file per engine)
  errors.ts     # Custom error classes
  ids.ts        # ID generation (ULID)
  index.ts      # Public barrel exports
  schema/       # Zod schemas
  server/       # HTTP server / API routes
  storage/      # Database access layer (Prisma wrappers)
tests/
  unit/         # Unit tests
  integration/  # Integration tests
  e2e/          # End-to-end tests
  helpers/      # Test utilities
seeds/          # Database seed files
```

### File Organization (Frontend)
```
frontend/
  src/
    app/          # Next.js App Router (layout, page, api/)
    canvas/       # Canvas live-config
    cli/          # Frontend CLI tools (canvas-scaffold)
    components/   # React components (canvas/, chat/, memory/, ui/)
    engines/      # Frontend engines (canvas, workspace, plugin, rbac, presence, etc.)
    features/     # Feature modules (onboarding, provider-setup-wizard)
    hooks/        # React hooks
    registry/     # CapabilityRegistry
    sdk/          # Frontend SDK
    storage/      # Storage contracts + memory impls
    ui/           # Slot system (slots.ts, registry.ts, context.tsx, defaults/)
    actions/      # ActionRegistry + auto-populate
    api/          # API client
    types/        # TypeScript types
  plugins/        # Plugin system (sample-plugin, demo-plugin)
  tests/          # Frontend tests (unit, integration, e2e)
  prisma/         # Frontend Prisma schema
```

## When Implementing Engines

1. Understand the current architecture from `docs/architecture/OVERVIEW.md` (mental model) and `docs/architecture/ENGINES.md` (each engine, its job, its code path).
2. Define TypeScript interface first (match spec exactly)
3. Define Store Contract (what the engine needs from storage)
4. Implement with proper error handling
5. Write unit tests with mocked store contract
6. Write integration tests for engine-to-engine interactions

## Invariants (Boundary Conditions)

**Full document:** the invariants below are the canonical boundary conditions (the
old `docs/roadmap/INVARIANTS.md` doc was archived with the 2026-08-06 cleanup).

Non-negotiable constraints enforced by `bun run devops invariants check`.

### Critical Boundaries (Never Violate)

1. **Governor Canon:** Only `ChromeGovernor` touches CDP. No engine imports `BunCdpClient`.
2. **Store Contracts:** Engines depend on `src/storage/contracts/*.ts`, never `src/storage/impl/*.ts`.
3. **Research-First:** No implementation without research report classification.
4. **Phase Gates:** Phase N requires phase N-1 complete.
5. **DB-Only Parser Logic:** `StreamParserEngine` loads parser logic **only** from DB (`parser_logic_code` with `logic_type=inline`). File-based parsers are rejected unless `allowFileLogic` is explicitly enabled. All seeded parsers live in `seeds/parsers/harvested/*.ts` as `LOGIC_CODE` strings and are upserted into DB via `seeds/parsers/harvest.seed.ts`.
6. **Chrome Slave Profile = Source of Truth:** Cookie files in profile directory determine "logged in" state — NOT DB loginState row. `isAuthenticated()` checks cookie files.
7. **One Profile Per (Provider, Account):** ProfileAllocator enforces singleton — no duplicate profiles for same provider+account combination.
8. **Lazy Startup:** Chrome slaves auto-launch when first needed, keep alive until `stop` command. No always-on requirement for dev loop.
9. **No Runaway Creation:** FleetSupervisor limits (maxConcurrent, queue, timeout) + ProfileAllocator singleton + spawn guard prevent duplicate Chrome instances.
10. **Triple-Layer State:** Profile + DB + runtime must stay consistent. Profile dir is canonical, DB and runtime are derived from profile state.
11. **Relogin Ready:** Agent detects session expiry via `isAuthenticated()`, suggests relogin to user, user confirms, system executes relogin flow.

### Harness Command Registry (Completed — spec 017)

Browser-free schema repair pipeline with declarative harness commands.

**Engines:**
- `src/engines/harness-command-registry.ts` — semver version resolution, required-field validation
- `src/engines/harness-repair-engine.ts` — Zod schema repair with alias remapping, code-fence strip, trailing-comma fix, apostrophe-safe quote balancing
- `src/engines/harness-feedback-coordinator.ts` — escalating retry prompts with exponential backoff + diff (never repeats same prompt)

**Prisma models:**
- `HarnessCommand` — versioned command definitions with JSON schema (seeded from `seeds/harness/commands.json`)
- `RepairSession` — audit trail for LLM payload repairs

**Storage contracts:**
- `GovernorStore` — `getHarnessCommand`, `listHarnessCommands`, `upsertHarnessCommand`, `getProviderFleetConfig`
- `HarnessRepairStore` — `createRepairSession`, `findRepairSessionsByConversation`

**Repair metadata side-table:** `src/schema/repair-metadata.ts` — `registerRepair`/`getRepairMetadata` with `repairString`/`repairNumber`/`repairBoolean` helpers. Never monkey-patches Zod prototypes.

**Seeding:** `seeds/harness/commands.seed.ts` → `seedHarnessCommands()` called in `src/engines/capability-bootstrap.ts` at boot.

**Key rules:**
- String schemas passthrough (never rewrite interior apostrophes)
- Zod 3.23+ `_def.shape()` is a function — call it
- Field-level `repairString({aliases})` for alias remapping (not top-level `registerRepair`)

### Parser System (Completed — features 019 + 020)

DB-only parser execution with real fallback chains. Parsers never live in engine code — they are DB rows executed via `SandboxRunner`.

**Engines:**
- `src/engines/stream-parser.ts` — `StreamParserEngine` loads inline `logic_code` from DB, resolves via `fallbackParserId` chain; `SandboxRunner` preferred (legacy `new Function` fallback only)
- `src/engines/stream-align.ts` — `StreamAlignmentEngine` (`computeParserHash`, version resolution)
- `src/engines/provider-registrar.ts` — 2-pass `fallbackParserId` wiring at seed time

**Seed parsers (`seeds/parsers/harvested/`):**
| Parser | Provider | Format |
|--------|----------|--------|
| `claude-streaming-sse` | Claude | SSE `content_block_delta` |
| `chatgpt-openai-delta` | ChatGPT | `choices[].delta.content` + patches + parts |
| `gemini-batchexecute` | Gemini | XSSI `decodeEnvelope` + `parseStreamChunk` |
| `google-ai-studio` | Gemini | `candidates[].content.parts[].text` |
| `deepseek-reasoning-sse` | DeepSeek | SSE `delta.content` with reasoning-channel separation |
| `generic-format-agnostic` | generic | SSE/JSON/array best-effort |
| `system-raw-text` | system | Last-resort raw text (never throws) |

**Fallback chain:** `provider/001` → `generic/001` → `system/001`. Wired by `seeds/parsers/harvest.seed.ts` via 2-pass upsert (`ProviderStore.upsertParser` + `setParserFallback`).

**Provider manifests (`seeds/providers/manifests.ts`):** Each provider declares `fallback` (parser name of the next tier). `ProviderRegistrar` reads this during registration and builds the `fallbackParserId` chain.

**Inline `logic_code` contract:**
```
function(module, exports) {
  exports.default = {
    name, version, providerId,
    parse(rawBody) -> ContentBlock[],
    detectCompletion(rawBody) -> boolean,
    getConfidence(rawBody) -> number
  }
}
```
`ContentBlock` shape: `{type:'text',text}`, `{type:'reasoning',text}`, `{type:'tool-call',...}`, `{type:'file',url,mediaType}`, `{type:'meta',key,value}`.

**Boot snapshot (`CapabilitySnapshot`):** Loaded once at boot from `CapabilityBinding` rows for registered providers. `ChromeGovernor.executeSnapshotProgram` iterates `recipe.steps[]` (multi-step) via `browserHarness.runAction`.

**Storage contracts:**
- `ParserStore` — `getParserByProviderAndVersion`, `getParserById`, `getActiveParser`, `getParser`, `getGenericParser`, `getSystemFallbackParser`, `upsertParser`, `listParsers`, `getParserByFile`, `getParserByHash`
- `ParserExecutionLogStore` — `logExecution`, `getRecentByProvider`, `getLowConfidenceEntries`, `getStatsByProvider`
- `ContentUnitStore` — `upsertContentUnits`, `getByMessageId`, `getByType`, `getByConversationId`, `getStats`
- `ProviderStore` — `upsertParser`, `listParsers`
- `CapabilityStore` — `loadSnapshot` (active bindings for registered providers)

**Tests:** `tests/unit/engines/harvested-parser.test.ts` (format correctness), `tests/unit/engines/stream-parser.test.ts` (fallback chain), `tests/unit/engines/capability-snapshot.test.ts` (boot snapshot).

### Harness Executor (DB-Driven Protocol)

The harness executor (`src/engines/harness/harness-executor-engine.ts`) uses `StreamParserEngine.parse()` — NOT `captureAndStore()` — to parse provider responses through the full parser chain with fallback support. Block metadata (`parserName`, `confidence`, `wireFormat`) is persisted as `blockMeta` JSON.

### One Entry Point (v10 Invariant)

Every operation is a `UnifiedCapability`. CLI and frontend are thin NL shells that
call `POST /api/interpret` → `POST /api/capabilities/:id/execute`.

- **New capability?** Register in `registerDefaultCapabilities` / a `*caps.ts` module.
- **New NL phrase?** Add a pattern to `catalog.ts` bound to a `capabilityId`.
- **Never:** hand-write CLI commands, hand-write UI actions, or open a second transport.

#### Adding a Capability

Use Unit 24.1 (registry contract), Unit 24.3 (CLI generation), and Unit 25.1 (catalog binding):

1. Create a capability in `src/engines/*caps.ts` using `makeCapability` or `registerSessionCaps` pattern
2. Register it with `surfaces: ['cli', 'ui', 'api']` to enable all transports
3. Add NL patterns to `src/engines/nlcl/catalog.ts` linking to your capabilityId
4. Add `cliCommand`, `ui`, and `mcpToolName` for cross-surface parity

#### LLM-as-Human Testing (Spec 032)

The LLM-as-Human production test suite is itself a `UnifiedCapability` set (no second
transport). Source of truth is `devops/llm-testing/capabilities.ts`, which registers
`cap:llm_test:{run,report,status,patterns,providers,parity}` (surfaces: cli/api/mcp) and is
wired into `src/server/index.ts` bootstrap (registration in `devops/llm-testing/capabilities.ts`). The orchestrator lives in
`devops/llm-testing/`; adapters for cli/ui/api/mcp/workflow/provider all derive their
test cases from the live `UnifiedCapabilityRegistry` (never hardcoded). NL phrases
(`run llm tests`, `check parity`) bind in `src/engines/nlcl/catalog.ts` to the
`cap:llm_test:*` ids. `llm_test_parity` asserts the frontend=backend=cli=api=mcp mandate.


#### CLI Dispatch (how the thin-client actually routes)

`src/cli/index.ts` is **not** a second transport — it is a thin client to a running
server (default `CAP_STORE_PORT=9420`; this env runs on `9421`). Two layers feed the
in-process `CommandRegistry`:

1. **Bridged capabilities** — `syncCliFromUnified()` copies every `cli`-surface
   capability from the `UnifiedCapabilityRegistry` into `CommandRegistry` (alias-
   collision guard: warns + skips duplicates instead of silent overwrite).
2. **Builtin commands** — `registerBuiltinCommands()` registers `automate` and
   `moments`, which bypass the capability registry and talk to the API directly
   (legacy extension pattern). They are still first-class members of the command
   tree and appear in `help`.

Multi-word commands (`admin db status`) resolve via `CommandRegistry.resolve()`
(longest-prefix match), not single-token `find()`. New builtins go in
`src/cli/commands/builtins.ts` — do NOT hand-write standalone `commands/*.ts`
scripts that bypass the registry.

### Taxonomy Chain Gotchas (CRITICAL)

Lessons from building the taxonomy generation pipeline and cross-surface verification.

1. **UI slot IDs must be namespaced** — The frontend `SLOT_IDS` in `frontend/src/ui/slots.ts` use `chat.actionBar`, `chat.composer`, `chat.sidebar` (not short names). The taxonomy pipeline's `CATEGORY_POSITIONS` table must use these exact values or `ui_position` silently fails.

2. **Capability nodes may lack `category`** — Shared capability nodes often have no `category` field. When generating `apiEndpoint.path`, derive category from `slug.split('_')[0]` — not `node.category`.

3. **`Bun.spawn` exitCode is null** — `proc.exitCode` returns `null` until `await proc.exited` resolves. Always await the promise before reading exit code.

4. **Single-segment slugs** — `capId` format is `cap:${category}:${action}`. For single-segment slugs (e.g. `help`), use `cap:help:help` — never `cap:undefined:help`.

5. **Verify after taxonomy changes** — Run `bun run devops verify-cross-surface` after any change to taxonomy pipeline, shared pool, or skeleton platforms. It checks CLI (name), API (path), MCP (tool name), UI (slot id).

## Shell Environment (CRITICAL)

**All commands MUST be PowerShell-compatible.** The default shell is PowerShell 7+.

### Dev Server Startup (`scripts/dev.ts` + `scripts/stop.ts`)

The old PowerShell startup scripts (`scripts/start-all.ps1`, `scripts/stop-all.ps1`, etc.)
have been replaced by pure TypeScript scripts:

| Command | Purpose |
|---------|---------|
| `bun run dev` | Start backend + frontend in one foreground process (Ctrl+C to stop) |
| `bun run stop` | Kill any orphaned processes on ports 9420/3000, clean `.runtime/` |
| `bun run dev:backend` | Start backend only (standalone) |
| `bun run dev:frontend` | Start frontend only (standalone) |

**Usage:**
```bash
# Start both services (blocking — Ctrl+C to stop)
bun run dev

# Or start individually in separate terminals:
bun run dev:backend   # terminal 1
bun run dev:frontend  # terminal 2

# Cleanup orphaned processes:
bun run stop
```

**Key behaviors:**
- `bun run dev` kills stale processes on ports 9420/3000 before starting
- Output is prefixed with `[backend]` / `[frontend]` labels
- Ctrl+C shuts down both services gracefully
- `bun run stop` is a port-scanner (no PID files needed), kills any process on the known ports and cleans `.runtime/`

**Smoke tests must have client-side timeouts.** Endpoints like `/api/conversations/:id/send`
block forever waiting for a CDP browser that isn't attached. Always wrap `fetch` calls with
`AbortController` + timeout so the test completes.

### PowerShell Command Patterns
```powershell
# Navigate to project root
Set-Location "C:\0-BlackBoxProject-0\vivim-final"

# Run typecheck with output capture
bun run typecheck 2>&1 | Select-Object -First 50

# List engine files
Get-ChildItem -Path src/engines -Recurse -Filter *.ts

# Search for TODOs in codebase
Get-ChildItem -Path src -Recurse -Filter *.ts | Select-String -Pattern "TODO"
```

### PowerShell Object-Pipeline Read Bug (CRITICAL — NEVER GET WRONG)

**`Invoke-RestMethod | Select-Object -ExpandProperty <x> | Out-File` produces EMPTY
files / empty output even when the API returns data.** This has silently broken
multiple dev loops: the agent "reads" a capability list, gets nothing, and reports
a false empty state ("no capabilities", "DB read issue"). The PowerShell object
pipeline drops the deserialized JSON payload before it reaches `Out-File`/`Get-Content`.

**✅ ALWAYS read API/JSON data through a BUN SCRIPT, never the PowerShell object pipeline:**
```powershell
# WRONG — silently yields empty output (DO NOT USE):
$port = Get-Content .runtime/backend.port
Invoke-RestMethod "http://localhost:$port/api/capabilities?surface=cli" |
  Select-Object -ExpandProperty slug | Out-File -Encoding utf8 .runtime/caps.txt
Get-Content .runtime/caps.txt          # -> EMPTY, even though 93 caps exist

# CORRECT — write a .ts file and bun run it (reliable parse + write):
#   .runtime/list-caps.ts:
#     const port = (await Bun.file('.runtime/backend.port').text()).trim()
#     const r = await fetch(`http://localhost:${port}/api/capabilities?surface=cli`)
#     const j = await r.json()
#     console.log('TOTAL', (j.capabilities ?? []).length)
#     for (const c of (j.capabilities ?? [])) console.log(c.slug)
bun run .runtime/list-caps.ts
```

Similarly, never pipe `ConvertFrom-Json | Select-Object -ExpandProperty ... | Out-File`
for the same reason. If you must inspect JSON in PowerShell, pretty-print with
`ConvertTo-Json -Depth 6 | Out-File` is also unreliable — prefer bun. Rule of thumb:
**any structured data read/write goes through a bun script in `.runtime/`, not
PowerShell's `Select-Object`/`Out-File` pipeline.**

## Testing Protocol

- Run `bun test` before every commit
- Run `bun run typecheck` to catch type errors
- Run `bun run lint` to catch style issues
- Run `bun run devops audit-code [surface|standard|deep|full]` for a source-code audit (P0–P3 findings + fix instructions); `audit-code fix <id> [--apply]` applies auto-fixable ones
- Run `bun run devops verify-cross-surface` after any taxonomy chain change (verifies every capability resolves across CLI/API/MCP/UI)
- Use `bun test tests/unit/engines/[engine-name]` for targeted testing
- Integration tests should use in-memory or test database
- **ALWAYS** use PowerShell-compatible commands

### Maintenance Testing (Phase 3 Upgrade)

After upgrading from vivim-page source files, run the full maintenance test suite:

```bash
# All ledger-client tests (chain verifier, client, manifest applier)
bun test tests/unit/lib/ledger-client/

# All tunnel-client tests (frame protocol, connection, heartbeat, reconnection, request handler)
bun test tests/unit/lib/tunnel-client/

# All orchestrator tests (service manager, health monitor, config)
bun test tests/unit/lib/orchestrator/

# All shared/tunnel tests (constants, errors)
bun test tests/unit/lib/tunnel-shared/

# P2P and local server tests
bun test tests/unit/lib/p2p-node/ tests/unit/lib/local-server/

# Integration tests (sync pipeline, crypto verification)
bun test tests/integration/lib/

# Full gate (all new tests)
bun test tests/unit/lib/ledger-client/ tests/unit/lib/tunnel-client/ tests/unit/lib/orchestrator/ tests/unit/lib/tunnel-shared/ tests/unit/lib/p2p-node/ tests/unit/lib/local-server/ tests/integration/lib/
```

**Coverage targets:**
- ledger-client/*: 100% of public functions
- tunnel-client/*: 100% of public functions
- orchestrator/*: 100% of public functions
- tunnel-shared/*: Constants + error hierarchy
- Integration: Full pipeline (signup → sync → verify → apply → mint)

## Git Conventions

- Conventional commits: `feat:`, `fix:`, `refactor:`, `test:`, `docs:`, `chore:`
- One logical change per commit
- Reference engine names in commits: `feat(CapabilityEngine): add selector resolution`

## MCP Servers

- **Playwright** — browser automation for E2E testing and UI validation

---

**For devops workflow, atomic task tracking, and implementation protocols:** Load the relevant skills from `.opencode/skill/`.

## Skill Management

- **Source of truth:** `.opencode/skill/` (30 project skills; `desktop-build-testing` and `production-build` exist locally but are gitignored)
- **Sync to kilocode:** `pwsh scripts/sync-skills.ps1`
- **Global skills:** `~/.agents/skills/` (171) + `~/.claude/skills/` (94)
- **Adding new skills:** Create in `.opencode/skill/`, run sync, test
- **Audit:** archived at `.archive/docs-stale-2026-08-06/audits/SKILL-DEVOPS-AUDIT-2026-07-19.md`
- **Architecture:** archived at `.archive/docs-stale-2026-08-06/skill-architecture.md`

## Available Skills

### Core DevOps
- **devops** — Autonomous DevOps orchestrator (127 atomic units)
- **devops-fullstack** — LLM-driven full-stack dev loop
- **devops-db** — Database architecture & schema governance
- **devops-generators** — Taxonomy generation pipeline (4-round)
- **devops-research** — Research-first intelligence layer
- **devops-roadmap** — Research-first roadmap system
- **devops-toolkit** — Surface regeneration + cross-surface parity (regen/verify/diff)
- **feature-governance** — Feature registry, lifecycle, skill mapping, health dashboard
- **convergence-auditor** — Spec/code/arch convergence audit & drift detection
- **agentic** — Limited-context agentic dev loop

#### DevOps Loop Commands (atomic unit pipeline)
The `devops` CLI drives the atomic-unit tracker (archived with the docs cleanup;
restore/point to a fresh tracker under `docs/` if needed):
```bash
bun run devops select                 # next implementable unit as JSON
bun run devops mark <id> <state>      # pending|in_progress|done|blocked
bun run devops mark <id> done "<msg>" # SINGLE-PASS: mark done + PROGRESS.md audit line + ONE git commit
bun run devops gate [--strict]        # quality gate, exit non-zero on fail
bun run devops parallelize --max 4 [--dry-run] [--tracker <path>]  # fan out N units to isolated subagents
bun run devops context                # durable task-state snapshot (resume after compaction)
bun run devops audit <id> "<notes>"   # append PROGRESS.md line w/ resolved sha (post-commit)
bun run devops code-index <index|search|stats|watch|mcp|clear> [--all] [--no-embed] [--no-watch]  # local offline code indexing
```
**Single-pass commit rule:** always use `devops mark <id> done "<msg>"` — it transitions state,
appends the PROGRESS.md audit line with the real resolved sha, and folds everything into ONE git
commit (no `[PENDING-COMMIT]` placeholder, no second commit). Engines should `import { getLogger }`
from `src/lib/logger.ts` (pino) instead of `console.*`; set `OTEL_EXPORTER_OTLP_ENDPOINT` to
forward logs via `src/engines/otel-sink.ts`.

### Implementation
- **vivim-build** — Engine implementation workflow (13-engine architecture)
- **vivim-runtime** — Agent-as-runtime dev loop

### Quality
- **vivim-testing** — Testing patterns & workflows
- **source-audit** — P0-P3 source-code audit (4 depth tiers)
- **arch-audit** — Architecture audit (cycles, layering, coupling)
- **provider-testing** — 8-phase provider onboarding
- **db-agent** — Oracle-vision database agent
- **prisma-workflow** — Prisma ORM patterns
- **provider-onboard-explorer** — Agent-as-explorer provider onboarding (APOP-AX)

### Frontend & UX
- **frontend-ux-refinement** — Iterative frontend UX refinement + cross-surface wiring
- **llm-provider-frontend-testing** — LLM-as-Human exploratory frontend testing per provider
- **vivi-frontend** — Hot-swappable frontend UI slots (see Implementation below)

### Debugging
- **diagnose** — Structured diagnosis loop (reproduce → fix)
- **systematic-debugging** — Bug/test failure debugging workflow

### Development Workflow
- **tdd** — Test-driven development (red-green-refactor)
- **review** — Two-axis code review (standards + spec)
- **verification-before-completion** — Pre-ship verification gate
- **handoff** — Session handoff for continuity
- **visual-explainer** — HTML diagram generation

## Memory Plugin (Compaction Survival)

Plugin `opencode-agent-memory` gives you 3 tools that survive all compactions:
- `memory_list` — list available memory blocks
- `memory_set` — store/update a memory block (full overwrite)
- `memory_replace` — update a substring within a block

**Project block** at `.opencode/memory/project.md` is injected into system prompt on every request. Use `memory_set` to store files you've read and key intel — it persists across compaction. Blocks default to 5000 char limit.

Regenerate `.opencode/memory/project.md` from real project data at any time:
```bash
bun run devops seed-memory
```
This reads package.json, Prisma schema, provider manifests, and test counts to produce an accurate snapshot. Run early in a session to maximize context survival after compaction.

## vivim-runtime — Agentic Dev Loop

Agent becomes the runtime of its own dev loop. Every command exits bounded, returns structured JSON, never hangs.

```bash
# Full loop (default 5 cycles, autonomous)
bun run devops runtime-test

# Custom
bun run devops runtime-test loop --max-cycles=3 --mitm

# Individual
bun run devops runtime-test preflight
bun run devops runtime-test discover-backend
bun run devops runtime-test test --nl "list conversations"
```

**Modes:** autonomous (full loop) | mitm (pauses after debug for agent decision)

**Agent-safety:** 15s bootstrap timeout, 5s per fetch, 2min overall cap, fast-port if server alive.

**Skill source:** `.kilo/skills/vivim-runtime/SKILL.md` (devops dir, source of truth)
**Harness copy:** `.opencode/skill/vivim-runtime/SKILL.md` (generated from source)

## Local Code Indexing (devops `code-index`)

Locally-indexed, offline code retrieval for agents. **Prefer `code-index search` over
grep+read for code discovery** — it returns ranked `path:line` chunks within a token budget
instead of forcing full-file reads (cuts the ~60–70% exploration tax). Native
(`devops/code-index.ts`, Bun `Bun.sqlite` FTS5), zero runtime deps, fully offline. See
`docs/decisions/README.md` (ADR index — ADR-017 archived, re-record if still load-bearing) and the A5 research brief
(archived: `.archive/docs-stale-2026-08-06/research/briefs/local-code-indexing-llm-brief.md`).

```bash
bun run devops code-index index           # index code-only roots (src, devops, frontend, scripts, seeds, prisma); watch by default
bun run devops code-index index --all     # index the whole repo
bun run devops code-index index --no-watch # one-shot, no file watcher
bun run devops code-index search "StreamParserEngine fallback"
bun run devops code-index stats
bun run devops code-index mcp              # stdio MCP: code_index_search + code_index_stats
```

- **Scope:** code-only roots by default; `--all` for the whole repo. `harvest/` dumps and
  `.html` are excluded to avoid OOM.
- **Retrieval:** lexical FTS5/BM25 by default; semantic opt-in via a pluggable HTTP embedder
  (`nomic-embed-text` at `localhost:11434/v1` by default). Falls back to lexical if no local
  model is reachable (one-time warning). Override with `CODE_INDEX_EMBEDDER_URL` /
  `CODE_INDEX_EMBEDDER_MODEL`. Semantic + lexical are fused with RRF(k=60).
- **Store:** `.runtime/code-index.sqlite` (`chunks`, `chunks_fts` FTS5 external-content, `files`
  hash table, `meta`). Incremental by content hash; watch mode keeps it fresh in-session.
- **Surfaces:** CLI for sub-agents (they can't call MCP directly) + stdio MCP for the
  top-level agent. This is the recommended replacement for `grep`/`Read` during exploration.

## Frontend

**Location:** `frontend/` (NOT `web/ui/` — that dir is empty)
- **Framework:** Next.js 16 + React 19 + Tailwind 4
- **Package:** `vivim-frontend` v0.2.0
- **Entry:** `frontend/src/app/` (Next.js App Router)
- **Engines:** `frontend/src/engines/` (canvas, workspace, plugin, rbac, presence, etc.)
- **UI slots:** `frontend/src/ui/slots.ts`, `frontend/src/ui/registry.ts`, `frontend/src/ui/defaults/`
- **Canvas:** `frontend/src/canvas/`, `frontend/src/features/`
- **Storage contracts:** `frontend/src/storage/contracts/` (memory impls in `storage/impl/`)
- **CLI:** `frontend/src/cli/` (canvas-scaffold, etc.)
- **Plugins:** `frontend/plugins/` (sample-plugin, demo-plugin)
- **Commands:** `cd frontend && bun run dev` (port 3000), `bun run build`, `bun run typecheck`, `bun run test`

## Frontend Convergence (Sandbox Harvest — completed)

All sandbox behavioral concepts have been collapsed into the main UI (`frontend/`).
The empty `web/sandbox/` dir remains (stale file lock from bun watcher, harmless).

### Architecture Rules
- **Design system:** CSS variables (`var(--bg)`, `var(--text)`, `var(--border)`, `var(--accent)`) with inline styles — NOT Tailwind.
- **FRONTEND = BACKEND:** capability `slug` is the single link; no `if (slug === 'x')` conditionals.
- **Backend:** `http://localhost:9420`, WebSocket `ws://localhost:9420/ws`.

### Harvested Components (10 total)

| Tier | Component | File | Surface |
|------|-----------|------|---------|
| 1 — Chat UX | RAF-batched WS streaming + block rendering | `Composer.tsx`, `MessageBlock.tsx` | `chat` |
| 1 — Chat UX | Latency breakdown bar chart | `LatencyBreakdown.tsx` | `chat` |
| 1 — Chat UX | Provider badges/colors | `ConversationList.tsx` | sidebar |
| 2 — Capability | Searchable capability grid | `CapabilityCatalog.tsx` | `capabilities` |
| 3 — Dev Tools | WS event firehose + NL inject + latency monitor | `DevConsole.tsx` | overlay |
| 4 — Admin | Provider health cards | `HealthDashboard.tsx` | `health` |
| 4 — Admin | Account CRUD modal | `ProviderManager.tsx` | modal |
| 4 — Admin | Fleet/chrome config modal | `WorkspaceSettings.tsx` | modal |

**Barrel exports:** `components/canvas/index.ts` exports all 7 new components + 2 types.

### Keyboard Shortcuts
| Shortcut | Action | Component |
|----------|--------|-----------|
| `Ctrl+K` / `⌘K` | Command Palette | `CommandPalette.tsx` |
| `Ctrl+\`` / `⌘\`` | Dev Console toggle | `DevConsole.tsx` (wired in `page.tsx`) |
| `Ctrl+Tab` / `⌘+Tab` | Cycle surface tabs | `SurfaceTabs.tsx` |
| `Ctrl+Shift+Tab` / `⌘+Shift+Tab` | Cycle surface tabs (reverse) | `SurfaceTabs.tsx` |

### UX Patterns
- **Conversation search** — text filter with memoized list (`ConversationList.tsx`)
- **Execution toast** — 2s auto-dismiss green/red toast on capability execute (`CapabilityCatalog.tsx`)
- **Error states** — all components catch HTTP + network errors with red message
- **Empty states** — "No X yet" / "No X match your filter" for all lists
- **Auto-refresh** — HealthDashboard refreshes every 15s
- **WS streaming** — RAF-batched (60fps flush) via `pendingBlocksRef` + `requestAnimationFrame`

### TypeScript
- All new/modified files pass `tsc --noEmit`. The only error is pre-existing `LoginPanel.tsx:37` (`Property 'token' does not exist`).

### Next Steps for Professional Frontend
1. **Virtual scrolling** for large conversation/message lists (react-window or similar)
2. **Theme system** — light/dark/auto + 6 accent colors + font scale (already seeded as `#4` in `page.tsx` Phase 3)
3. **Onboarding tour** (already seeded as `#5` in `page.tsx`)
4. **Responsive layout** — mobile breakpoints for sidebar/overlay/surfaces
5. **CSS transitions** — smooth surface tab transitions, modal open/close, toast animations
6. **Accessibility** — aria labels, focus trapping in modals, keyboard navigation for all surfaces
7. **Loading skeletons** — placeholder UI during data fetches (not just text "Loading…")
8. **Error recovery** — retry buttons on failed API calls
9. **Undo/redo** for destructive actions (delete conversation, capability execute)
10. **Moment (time-relative)** formatting in conversation list timestamps

## Node-Layer v2 (Universal Node DB — completed)

Full documentation: `docs/architecture/DATA.md` (Node model section — the old
`docs/node-layer-v2/` was archived with the 2026-08-06 cleanup).

### What was built
- **ACU-proven fields** on `Node` model (`contentHash`, `version`, `state`, `securityLevel`, `contentType`, `authorDid`, `signature`, `acl`, `quality`, `validFrom`/`validUntil`, `parentVersion`)
- **NodeVersion** — time-travel version chain (every mutation recorded, `getNodeAtVersion`/`getNodeHistory`)
- **NodeAlias** — entity alias→canonical resolution (`registerAlias`/`resolveAlias`)
- **NodeEdge.weight** — edge weight/confidence
- **Typed data shapes** for 8 additional types: Memory (+FSRS-6), Acu, Notebook, Note, Bookmark, Artifact, Document, Email — registered as `cap-store.*` schemas
- **`captureAsNode()`** in ConversationManager — auto-captures every message as a Node with fork-linking (assistant→user via `responds_to` edge)
- **`recordMemory()`** in MemoryEngine — emits `cap-store.memory` Nodes with FSRS-6 initial state
- **`rebuildGraphFromNodes()`** — re-materializes edges from source (ADR-001)

### Key contract
Engines depend on `NodeStoreContract` (never `NodeStoreImpl` directly). Located at `src/storage/contracts/node-store.ts` — implements Store Contracts invariant.

### Fixture DB
After any Prisma schema change, rebuild the canonical test fixture (tracked in git at
`tests/fixtures/node-store-test.db`). Use an ABSOLUTE `file:` path — Prisma resolves
relative ones against `prisma/schema.prisma`, which would silently create a duplicate
at `prisma/tests/fixtures/` (DB proliferation; flagged by `scripts/db-reports/report-db-inventory.ts`):
```bash
DATABASE_URL="file:C:/0-BlackBoxProject-0/vivim-final/tests/fixtures/node-store-test.db" bunx prisma db push --skip-generate --accept-data-loss
```

### Migration history
- `20260718022736_universal_node_layer` — base Node + NodeEdge
- `20260718041000_node_layer_v2` — ACU fields + NodeVersion + NodeAlias + NodeEdge.weight