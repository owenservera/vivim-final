# CODE_SPEC — vivim-final (context-pack edition)

Spec for an AI to regenerate or extend this codebase. Compiled from the live
sources in this pack; if a file in this pack disagrees with this spec, the
file wins.

## 1. Stack

| Layer    | Tech | Evidence |
|----------|------|----------|
| Runtime  | Bun (Windows host) | `package.json` |
| Language | TypeScript strict, ESNext, `.js` import extensions (Bun ESM), `@/*` → `./src/*` | AGENTS.md |
| ORM      | Prisma v6.5, SQLite via `bunx prisma db push` (DDL only, no `_prisma_migrations`) | AGENTS.md |
| API      | Native Bun HTTP server on port 9420 (dev env: 9421), WebSocket `/ws` | AGENTS.md |
| Frontend | Next.js 16 App Router + React 19 + Tailwind 4, port 3000 | `frontend/package.json` |
| Desktop  | Tauri v2, NSIS installer, Rust sidecar (bun-compiled exe, UPX L3) | `src-tauri/Cargo.toml` |
| Testing  | Bun test runner (`bun test`), Biome lint, tsup build | `package.json` |

## 2. Data model (prisma/schema.prisma)

Full schema in the pack (162 KB). Shape highlights:

- **Provider graph (L0-L1):** `Provider`, `ProviderType`, `ProviderEndpoint`, `ProviderModel`, `Parser`, `ParserFallback`, `ParserExecutionLog`, `StreamConfig`.
- **Capability system (L2-L3):** `Capability`, `CapabilityBinding`, `CapabilityRecipe`, `CapabilityProgram`, `CapabilitySnapshot`, `UnifiedCapability`, `HarnessCommand`, `RepairSession`.
- **Session/state (L4):** `Conversation`, `Message`, `ContentBlock`, `ContentUnit`, `StreamBlock`, `StreamChunk`, `Node`, `NodeVersion`, `NodeAlias`, `NodeEdge` (knowledge graph).
- **Knowledge:** `Memory`, `KnowledgeItem`, `Entity`, `EntityFact`, `Decision`, `ContextAssembly`.
- **Fleet/desktop:** `ChromeSlave`, `Account`, `FleetConfig`, `Profile`, `GovernorEvent`.
- **Cross-cutting:** `ConfigItem`, `EventLog`, `Telemetry`, `RegistrationAudit`, `SchemaMeta`, `VersionInfo`, `Workspace`.

Conventions: ULID ids (`src/ids.ts`), `@updatedAt` timestamps, JSON columns via
Prisma `Json` type, `logic_code` inline parser bodies as TEXT.

## 3. Runtime layers (13 engines)

```
L0-L1  Provider Knowledge Graph  ProviderRegistrar, ProviderHealthKernel
L2-L3  Capability System         CapabilityResolutionEngine, CapabilityEngine
L4     Session & State           ConversationManager, StreamBlockStore
Chrome ChromeGovernor            CDP proxy, lifecycle, trace, health
X-Cut  CapabilityEventBus, ConfigManager, StreamParserEngine
Life   RegistrationAuditor, VersionManager, TelemetryAggregator
```

One entry point: every operation is a `UnifiedCapability`. CLI + frontend are
thin NL shells. New capability → register in a `*caps.ts` module with
`surfaces: ['cli','ui','api']`, add NL patterns to `catalog.ts`, add
`cliCommand`/`ui`/`mcpToolName` for cross-surface parity.

## 4. Stream parser contract (DB-driven)

Parsers never live in engine code. They are DB rows
(`Parser.logic_code`, `logic_type=inline`) executed via `SandboxRunner`
(legacy `new Function` fallback). Boot wiring: `StreamParserEngine` loads the
active parser for a provider, resolves the `fallbackParserId` chain
(`provider/001` → `generic/001` → `system/001`), and parses raw wire bytes
into `ContentBlock[]`.

Inline `logic_code` module contract (see `chatgpt-openai-delta.ts`):

```js
// function(module, exports) { ... }
module.exports.default = {
  name: '<provider>/001_<format>', version: 1, providerId: '<slug>',
  parse(rawBody)        -> ContentBlock[] | {type:'text',text} | ...
  detectCompletion(rawBody) -> boolean
  getConfidence(rawBody)    -> number (0..1)
}
```

`ContentBlock` variants: `{type:'text',text}` | `{type:'reasoning',text}` |
`{type:'tool-call',toolCallId,toolName,input}` |
`{type:'file',url,mediaType,filename}` | `{type:'meta',key,value}`.

7 harvested parsers in the pack (one per provider/wire format):
`claude-streaming-sse`, `chatgpt-openai-delta`, `gemini-batchexecute`,
`google-ai-studio`, `deepseek-reasoning-sse`, `generic-format-agnostic`,
`system-raw-text`. Each declares confidence + completion detection;
`ChatGPT` handles OpenAI `choices[].delta.content`, `o:'patch'` / `o:'add'`
parts, `[DONE]`, tool calls, images (`asset_pointer`).

`StreamAlignmentEngine` (`stream-align.ts`) computes parser hashes for
version resolution; `ProviderRegistrar` does a 2-pass
`fallbackParserId` wiring at seed time from `seeds/providers/manifests.ts`.

## 5. Embedding / vector search stack

`SemanticSearchEngine` (`src/engines/semantic-search.ts`):

```
interface EmbeddingProvider {
  name: string; dimensions: number
  embed(text: string): Promise<number[]>
  embedBatch(texts: string[]): Promise<number[][]>
}
interface SearchQuery { text: string; limit?: number; entityType?: string;
                        minScore?: number; useHybrid?: boolean }
interface SearchResult { type: 'conversation'|'message'|'fact'|'entity'|'decision';
                         id: string; score: number; snippet?: string }
class SemanticSearchEngine {
  index(text, entityType, entityId): Promise<void>
  indexBatch(items): Promise<...>
  search(query): Promise<SearchResult[]>
  searchHybrid(query): Promise<SearchResult[]>   // sparse + dense fused
  reindexAll(): Promise<{indexed, skipped, errors}>
  getStats(): Promise<{totalEmbeddings}>
}
```

Providers (all implement `EmbeddingProvider`):
- `OllamaEmbeddingProvider` — `nomic-embed-text` (768-d), `POST /api/embeddings`, 120 s abort timeout, graceful fail.
- `MiniLMEmbeddingProvider` (`embedding-minilm.ts`) — real non-zero dense vectors with cosine structure, no external service.
- `HuggingFaceEmbeddingProvider` (`embedding-hf.ts`).
- `EmbeddingClassifier` (`embedding-classifier.ts`) — classify text by cosine similarity to category anchor embeddings.

Hybrid retrieval (`nlcl/semantic-resolver.ts`): sparse TF-IDF cosine
(high precision) + dense MiniLM cosine (high recall); sparse threshold 0.60+
gates contribution, dense lower. Pure-TS TF-IDF + cosine in `nlcl/tfidf.ts`
(zero deps).

## 6. Store contracts (src/storage/contracts/)

Engines depend on these contracts, never `impl/*`. 56 contracts, notable:
`NodeStoreContract`, `ParserStore`, `ParserExecutionLogStore`,
`ContentUnitStore`, `ProviderStore`, `CapabilityStore` (`loadSnapshot`),
`GovernorStore`, `ConversationStore`, `MemoryStore`, `SemanticSearchStore`,
`KernelStore`. Parser/execution logging flows are fully contracted.

## 7. Key behaviors / gotchas

- **CDP:** only `ChromeGovernor`; `BunCdpClient` is private. Gemini = Quill
  `div.ql-editor[contenteditable="true"]` + send-button click (Enter broken),
  custom batchexecute RPC (not SSE). ChatGPT = `#prompt-textarea`, `[DONE]`.
  Claude = ProseMirror `div[contenteditable]`, Anthropic SSE
  `content_block_delta`.
- **Profiles:** `chrome-profiles/<slug>/<account>/` is canonical; cookies file
  = auth truth; `ProfileAllocator` singleton per (provider, account).
- **No `tsc` mid-task** (pre-existing errors in `tests/` owned elsewhere);
  verify at human request only.
- **PowerShell trap:** never read JSON through `Invoke-RestMethod |
  Select-Object -ExpandProperty x | Out-File` — empty output; read via bun script.
- **Bun.spawn:** `proc.exitCode` is `null` until `await proc.exited`.
- **Smoke tests:** wrap fetches in `AbortController` + timeout (send endpoints
  block on unattached CDP browser).
