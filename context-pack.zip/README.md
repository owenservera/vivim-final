# vivim-final — Context Pack

Complete self-contained context for regenerating/extending the vivim-final
codebase. 128 files, ~697 KB uncompressed — well under any 5 MB upload cap.
Zip: `context-pack.zip` in the project root.

## What this is

vivim-final (cap-store v1 Knowledge Graph Rebuild) is a local-first AI
conversation platform: Bun + Prisma (SQLite) + TypeScript backend, Next.js 16
frontend, Tauri v2 desktop shell. It drives real logged-in Chrome profiles
(CDP) against LLM provider web UIs (ChatGPT, Claude, Gemini, DeepSeek, Qwen,
Grok) and captures/parses their streaming responses.

## How to use

1. Upload `context-pack.zip` (or paste files) to your AI.
2. Read `CODE_SPEC.md` first — it is the architectural spec.
3. `prisma/schema.prisma` is the full DB (54+ tables).
4. `src/domain/types.ts` + `src/schema/` = the TypeScript interface layer.
5. `seeds/parsers/harvested/*.ts` = real stream parsers (sample = `chatgpt-openai-delta.ts`).
6. `src/engines/semantic-search.ts` + `embedding-*.ts` = embedding/vector search stack.

## File map

```
AGENTS.md                        ← full project instructions (conventions, invariants, workflows)
CODE_SPEC.md                     ← this pack's architectural spec (read first)
manifest.json                    ← machine-readable manifest (paths, sizes, SHA-256, purpose)
prisma/schema.prisma             ← full Prisma schema (DB = source of truth)
package.json / frontend/package.json / src-tauri/Cargo.toml
                                 ← exact dependency manifests (backend, frontend, Tauri shell)
src/domain/types.ts, index.ts    ← domain types
src/schema/*.ts                  ← Zod runtime validation layer (37 files)
src/storage/contracts/*.ts       ← store contracts — engines depend on these, never impls (56 files)
src/engines/
  semantic-search.ts             ← SemanticSearchEngine (embedding-based search + hybrid rerank)
  embedding-ollama.ts            ← OllamaEmbeddingProvider (nomic-embed-text, 768-d)
  embedding-minilm.ts            ← MiniLM dense provider
  embedding-hf.ts                ← HuggingFace provider
  embedding-classifier.ts        ← classify entities by cosine to category anchors
  stream-parser.ts               ← StreamParserEngine (DB-only parser logic + fallback chain)
  stream-align.ts                ← StreamAlignmentEngine (parser hash / version resolution)
  conversation-manager.ts        ← provider capture patterns + response parsing
  provider-registrar.ts          ← 2-pass fallbackParserId wiring at seed time
  nlcl/semantic-resolver.ts      ← hybrid sparse (TF-IDF) + dense (MiniLM) retrieval
  nlcl/tfidf.ts                  ← sparse TF-IDF vectorization + cosine
seeds/providers/manifests.ts     ← 16 provider manifests (endpoints, selectors, models, fallbacks)
seeds/parsers/harvested/*.ts     ← 7 real stream parsers as inline LOGIC_CODE (DB-driven)
src/config.ts                    ← runtime configuration
src/ids.ts                       ← ULID id generation
src/errors.ts                    ← error hierarchy (EngineError etc.)
```

## Key invariants (enforced by `bun run devops invariants check`)

1. Only `ChromeGovernor` touches CDP.
2. Engines depend on `src/storage/contracts/*`, never impls.
3. Parser logic is DB-only (`parser_logic_code`, `logic_type=inline`); file parsers rejected unless `allowFileLogic`.
4. Chrome slave profile dir (cookies) = source of truth for "logged in", not DB.
5. One profile per (provider, account) — `ProfileAllocator` enforces singleton.
6. Every operation is a `UnifiedCapability`; CLI/UI are thin NL shells → `POST /api/interpret` → `POST /api/capabilities/:id/execute`.
