/**
 * shared/agent-canvas.ts
 * --------------------------------------------------------------------
 * V6 #2 — Agent Canvas Co-Pilot.
 *
 * The agent can: spawn_node, wire(a→b), arrange_cluster, summarize_region.
 * Changes appear as ghosted overlays; user accepts/rejects per-node (HITL).
 */

export type AgentCanvasAction =
  | 'spawn_node'
  | 'wire'
  | 'arrange_cluster'
  | 'summarize_region'
  | 'move_node'
  | 'delete_node'
  | 'configure_node';

export interface AgentCanvasOp {
  id: string;
  action: AgentCanvasAction;
  /** Node id affected (for spawn: the new node id). */
  nodeId: string;
  /** Target node id (for wire: the target). */
  targetNodeId?: string;
  /** Node spec (for spawn). */
  nodeSpec?: {
    slotId: string;
    providerId?: string;
    title: string;
    category: string;
    layout?: { x: number; y: number; w: number; h: number };
  };
  /** Connection spec (for wire). */
  connectionSpec?: {
    fromPort: string;
    toPort: string;
    type: string;
  };
  /** Layout spec (for arrange/move). */
  layout?: { x: number; y: number; w: number; h: number };
  /** Summary text (for summarize_region). */
  summary?: string;
  /** Status: pending = awaiting HITL, applied = accepted, rejected = rejected. */
  status: 'pending' | 'applied' | 'rejected';
  timestamp: number;
}

export interface AgentCanvasPlan {
  id: string;
  traceId: string;
  /** The natural-language prompt that generated this plan. */
  prompt: string;
  /** Operations in this plan. */
  ops: AgentCanvasOp[];
  /** Overall status. */
  status: 'planning' | 'pending' | 'partial' | 'applied' | 'rejected';
  createdAt: number;
}

export interface AgentCanvasState {
  /** Active plan (if any). */
  activePlan: AgentCanvasPlan | null;
  /** All plans (history). */
  plans: AgentCanvasPlan[];
  /** Whether the agent is currently planning. */
  isPlanning: boolean;
}
