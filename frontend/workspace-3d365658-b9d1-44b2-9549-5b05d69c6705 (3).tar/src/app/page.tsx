'use client';

/**
 * app/page.tsx — Vivim Canvas (V9 SOTA)
 * --------------------------------------------------------------------
 * Clean, professional interface. No emojis. SVG Icon system.
 * Glass surfaces, refined typography, consistent spacing.
 */

import { useEffect, useState } from 'react';
import {
  LivingCanvas,
  LiveConfigProvider,
  useLiveConfig,
  WorkspaceSwitcher,
  CommandPalette,
  NotificationsCenter,
  OnboardingTour,
  QuickActionsMenu,
  PresenceIndicator,
  ThemeSettings,
  AuditDashboard,
  RbacManager,
  TemplatesGallery,
  DocCard,
  MediaCard,
  AutomationCard,
  AgentCard,
  ShellCard,
  DocEditor,
  ZLayerPanel,
  DrawerSystem,
  Icon,
  type IconName,
} from '@/components/canvas';
import type { AccountContext, PlanTier } from '@/shared/route-context';
import type { DocumentCard as DocumentCardRow } from '@/shared/document';
import type { MediaCard as MediaCardRow } from '@/shared/media';
import type { AutomationDefinition } from '@/shared/automation';
import type { AgentDefinition } from '@/shared/agent';
import type { SearchHit } from '@/shared/search';

const PROVIDER_OPTIONS = [
  { id: 'chatgpt', label: 'ChatGPT' },
  { id: 'claude', label: 'Claude' },
  { id: 'gemini', label: 'Gemini' },
  { id: 'gmail', label: 'Gmail' },
  { id: 'outlook', label: 'Outlook' },
  { id: 'whatsapp', label: 'WhatsApp' },
  { id: 'slack', label: 'Slack' },
  { id: 'telegram', label: 'Telegram' },
  { id: 'twitter', label: 'Twitter' },
  { id: 'linkedin', label: 'LinkedIn' },
  { id: 'mastodon', label: 'Mastodon' },
  { id: 'notion', label: 'Notion' },
  { id: 'linear', label: 'Linear' },
];

const TIER_OPTIONS: PlanTier[] = ['free', 'trial', 'pro', 'enterprise'];

const SURFACES: Array<{ slug: string; label: string; icon: IconName }> = [
  { slug: 'chat', label: 'Canvas', icon: 'layers' },
  { slug: 'docs', label: 'Documents', icon: 'document' },
  { slug: 'editor', label: 'Editor', icon: 'document' },
  { slug: 'media', label: 'Media', icon: 'video' },
  { slug: 'automation', label: 'Automation', icon: 'bolt' },
  { slug: 'agents', label: 'Agents', icon: 'robot' },
  { slug: 'shell', label: 'Shell', icon: 'terminal' },
  { slug: 'audit', label: 'Audit', icon: 'chart' },
  { slug: 'rbac', label: 'Access', icon: 'shield' },
  { slug: 'templates', label: 'Templates', icon: 'template' },
  { slug: 'zlayers', label: 'Layers', icon: 'layers' },
];

export default function Home() {
  return (
    <LiveConfigProvider
      initialWorkspaceId="ws:global"
      initialUserId="user:demo"
      initialProviderIds={['chatgpt']}
      initialAccounts={[
        { accountId: 'acct:chatgpt:free', providerId: 'chatgpt', planTier: 'free' },
      ]}
    >
      <CanvasApp />
    </LiveConfigProvider>
  );
}

function CanvasApp() {
  const { surface, isLoading, error, workspaceId, setWorkspace, providerIds, setProviderIds, accounts, setAccounts, variant, setVariant } = useLiveConfig();
  const [draftVariant, setDraftVariant] = useState('');
  const [activeSurface, setActiveSurface] = useState<string>('chat');
  const [docs, setDocs] = useState<DocumentCardRow[]>([]);
  const [medias, setMedias] = useState<MediaCardRow[]>([]);
  const [automations, setAutomations] = useState<AutomationDefinition[]>([]);
  const [agents, setAgents] = useState<AgentDefinition[]>([]);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [themeOpen, setThemeOpen] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setPaletteOpen((o) => !o);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  useEffect(() => {
    Promise.all([
      fetch('/api/document/open', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title: 'Welcome', mimeType: 'text/markdown', inlineContent: '# Welcome\n\nThis is the Vivim Canvas.', workspaceId }) }).then((r) => r.json()),
      fetch('/api/document/open', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title: 'sample.ts', mimeType: 'text/typescript', inlineContent: 'export function resolve(): Surface {\n  return walk(ctx);\n}\n', language: 'typescript', workspaceId }) }).then((r) => r.json()),
    ]).then((rs) => setDocs((rs as Array<{ ok: boolean; document: DocumentCardRow }>).filter((r) => r.ok).map((r) => r.document)));

    Promise.all([
      fetch('/api/media/open', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title: 'Sample Video', kind: 'video', sourceUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4', mimeType: 'video/mp4', durationSec: 596, workspaceId }) }).then((r) => r.json()),
      fetch('/api/media/open', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title: 'Sample Audio', kind: 'audio', sourceUrl: 'https://example.com/sample.mp3', mimeType: 'audio/mpeg', durationSec: 42, workspaceId }) }).then((r) => r.json()),
    ]).then((rs) => setMedias((rs as Array<{ ok: boolean; media: MediaCardRow }>).filter((r) => r.ok).map((r) => r.media)));

    fetch(`/api/automation/list?workspaceId=${encodeURIComponent(workspaceId)}`).then((r) => r.json()).then((d: { ok: boolean; automations: AutomationDefinition[] }) => setAutomations(d.ok ? d.automations.slice(0, 4) : [])).catch(() => setAutomations([]));
    fetch(`/api/agent/list?workspaceId=${encodeURIComponent(workspaceId)}`).then((r) => r.json()).then((d: { ok: boolean; agents: AgentDefinition[] }) => setAgents(d.ok ? d.agents : [])).catch(() => setAgents([]));
  }, []);

  useEffect(() => {
    fetch('/api/notification/stats?userId=user:demo').then((r) => r.json()).then((d: { ok: boolean; stats: { unread: number } }) => { if (d.ok && d.stats.unread === 0) fetch('/api/notification/seed', { method: 'POST' }).catch(() => {}); }).catch(() => {});
  }, []);

  const toggleProvider = (id: string) => {
    const isOn = providerIds.includes(id);
    if (isOn) { setProviderIds(providerIds.filter((p) => p !== id)); setAccounts(accounts.filter((a) => a.providerId !== id)); }
    else { setProviderIds([...providerIds, id]); setAccounts([...accounts, { accountId: `acct:${id}:free`, providerId: id, planTier: 'free' as const }]); }
  };

  const cycleTier = (providerId: string) => setAccounts(accounts.map((a) => { if (a.providerId !== providerId) return a; const idx = TIER_OPTIONS.indexOf(a.planTier); return { ...a, planTier: TIER_OPTIONS[(idx + 1) % TIER_OPTIONS.length]! }; }));

  const handlePaletteAction = (hit: SearchHit) => {
    if (!hit.actionUrl) return;
    if (hit.actionUrl.startsWith('switch-surface:')) setActiveSurface(hit.actionUrl.slice('switch-surface:'.length));
    else if (hit.actionUrl.startsWith('shell:')) { setActiveSurface('shell'); try { window.localStorage.setItem('vivim.shell.pendingCommand', hit.actionUrl.slice('shell:'.length)); } catch {} }
    else if (hit.actionUrl.startsWith('workspace:')) setWorkspace(hit.actionUrl.slice('workspace:'.length));
  };

  return (
    <div style={{ position: 'fixed', inset: 0, display: 'flex', flexDirection: 'column', fontFamily: 'var(--font-sans)', background: 'var(--background)', color: 'var(--foreground)' }}>
      {/* Top bar */}
      <header style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '6px 12px', borderBottom: '1px solid var(--border)', background: 'var(--card)', flexShrink: 0, height: 44 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <Icon name="layers" size={16} className="text-primary" />
          <span style={{ fontSize: 13, fontWeight: 700, letterSpacing: '-0.02em' }}>Vivim</span>
        </div>
        <div style={{ flex: 1 }} />
        <PresenceIndicator workspaceId={workspaceId} />
        <button onClick={() => setPaletteOpen(true)} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 10px', border: '1px solid var(--border)', background: 'var(--background)', color: 'var(--muted-foreground)', borderRadius: 'var(--radius)', cursor: 'pointer', fontSize: 11, fontFamily: 'inherit', minWidth: 200 }}>
          <Icon name="search" size={13} />
          <span style={{ flex: 1, textAlign: 'left' }}>Search or run command</span>
          <kbd style={{ padding: '1px 5px', background: 'var(--muted)', border: '1px solid var(--border)', borderRadius: 'calc(var(--radius) - 4px)', fontSize: 9, fontFamily: 'var(--font-mono)' }}>K</kbd>
        </button>
        <NotificationsCenter userId="user:demo" />
        <button onClick={() => setThemeOpen((o) => !o)} style={{ padding: '5px 8px', border: '1px solid var(--border)', background: 'var(--card)', borderRadius: 'var(--radius)', cursor: 'pointer', display: 'flex', alignItems: 'center', color: 'var(--muted-foreground)' }}>
          <Icon name="palette" size={14} />
        </button>
        {themeOpen && <ThemeSettings onClose={() => setThemeOpen(false)} />}
      </header>

      <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
        {/* Sidebar */}
        <aside style={{ width: 240, flexShrink: 0, borderRight: '1px solid var(--border)', background: 'var(--sidebar)', overflowY: 'auto', padding: 12, display: 'flex', flexDirection: 'column', gap: 12 }} className="scrollbar-thin">
          <WorkspaceSwitcher currentWorkspaceId={workspaceId} onSwitch={(id) => setWorkspace(id)} />

          <section>
            <div className="text-label" style={{ marginBottom: 4 }}>Variant</div>
            <div style={{ display: 'flex', gap: 4 }}>
              <input value={draftVariant} placeholder="opus, voice" onChange={(e) => setDraftVariant(e.target.value)} style={{ flex: 1, padding: '4px 6px', border: '1px solid var(--border)', background: 'var(--background)', color: 'var(--foreground)', borderRadius: 'calc(var(--radius) - 4px)', fontSize: 11, fontFamily: 'var(--font-mono)' }} />
              <button onClick={() => setVariant(draftVariant || undefined)} style={{ padding: '4px 8px', border: '1px solid var(--border)', background: 'var(--secondary)', color: 'var(--foreground)', borderRadius: 'calc(var(--radius) - 4px)', fontSize: 11, cursor: 'pointer', fontFamily: 'inherit' }}>Set</button>
            </div>
          </section>

          <section>
            <div className="text-label" style={{ marginBottom: 4 }}>Providers ({providerIds.length})</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 2, maxHeight: 280, overflowY: 'auto' }} className="scrollbar-thin">
              {PROVIDER_OPTIONS.map((p) => {
                const isOn = providerIds.includes(p.id);
                const acct = accounts.find((a) => a.providerId === p.id);
                return (
                  <div key={p.id} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '3px 6px', borderRadius: 'calc(var(--radius) - 4px)', background: isOn ? 'color-mix(in oklch, var(--ring) 8%, transparent)' : 'transparent', border: isOn ? '1px solid color-mix(in oklch, var(--ring) 30%, transparent)' : '1px solid transparent' }}>
                    <input type="checkbox" checked={isOn} onChange={() => toggleProvider(p.id)} style={{ margin: 0, accentColor: 'var(--ring)' }} />
                    <span style={{ flex: 1, fontSize: 11 }}>{p.label}</span>
                    {isOn && acct && <button onClick={() => cycleTier(p.id)} style={{ padding: '1px 5px', border: '1px solid var(--border)', background: 'var(--card)', borderRadius: 'calc(var(--radius) - 4px)', fontSize: 9, cursor: 'pointer', fontFamily: 'var(--font-mono)', color: 'var(--muted-foreground)' }}>{acct.planTier}</button>}
                  </div>
                );
              })}
            </div>
          </section>

          <section style={{ marginTop: 'auto', fontSize: 10, color: 'var(--muted-foreground)', borderTop: '1px solid var(--border)', paddingTop: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
              <Icon name="activity" size={11} />
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 9 }}>{surface?.traceId.slice(0, 14)}</span>
            </div>
            <div style={{ marginTop: 2 }}>{surface?.durationMs ?? 0}ms | {surface?.slots.length ?? 0} slots</div>
            {isLoading && <div style={{ color: 'var(--ring)' }}>resolving</div>}
          </section>
        </aside>

        {/* Main content */}
        <main style={{ flex: 1, display: 'flex', flexDirection: 'column', position: 'relative', minWidth: 0 }}>
          {/* Surface tabs */}
          <div style={{ display: 'flex', borderBottom: '1px solid var(--border)', background: 'var(--card)', padding: '0 8px', overflowX: 'auto' }} className="scrollbar-thin">
            {SURFACES.map((s) => {
              const active = activeSurface === s.slug;
              return (
                <button key={s.slug} onClick={() => setActiveSurface(s.slug)} style={{ display: 'flex', alignItems: 'center', gap: 5, padding: '8px 12px', border: 'none', borderBottom: active ? '2px solid var(--ring)' : '2px solid transparent', background: 'transparent', cursor: 'pointer', fontSize: 11, fontWeight: active ? 600 : 400, color: active ? 'var(--foreground)' : 'var(--muted-foreground)', fontFamily: 'inherit', whiteSpace: 'nowrap' }}>
                  <Icon name={s.icon} size={13} />
                  {s.label}
                </button>
              );
            })}
          </div>

          {/* Surface content */}
          <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
            <DrawerSystem workspaceId={workspaceId}>
              {activeSurface === 'chat' && <LivingCanvas workspaceId={workspaceId} userId="user:demo" providerIds={providerIds} accounts={accounts} variant={variant} />}
              {activeSurface === 'docs' && (
                <div style={{ position: 'absolute', inset: 0, padding: 16, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: 16, overflowY: 'auto' }} className="scrollbar-thin">
                  {docs.map((doc) => <div key={doc.id} className="node-surface" style={{ display: 'flex', flexDirection: 'column', minHeight: 320, overflow: 'hidden' }}><div style={{ padding: '6px 10px', borderBottom: '1px solid var(--border)', background: 'var(--secondary)', fontSize: 11, color: 'var(--muted-foreground)', display: 'flex', justifyContent: 'space-between' }}><strong style={{ color: 'var(--foreground)' }}>{doc.title}</strong><span style={{ fontFamily: 'var(--font-mono)', fontSize: 10 }}>{doc.engine}</span></div><div style={{ flex: 1 }}><DocCard document={doc} /></div></div>)}
                </div>
              )}
              {activeSurface === 'editor' && <div style={{ position: 'absolute', inset: 16 }}>{docs.length > 0 && <div style={{ height: '100%', borderRadius: 'var(--radius)', border: '1px solid var(--border)', overflow: 'hidden' }}><DocEditor document={docs[0]!} /></div>}{docs.length === 0 && <div style={{ padding: 48, textAlign: 'center', color: 'var(--muted-foreground)', fontSize: 13 }}>No documents to edit</div>}</div>}
              {activeSurface === 'media' && (
                <div style={{ position: 'absolute', inset: 0, padding: 16, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: 16, overflowY: 'auto' }} className="scrollbar-thin">
                  {medias.map((m) => <div key={m.id} className="node-surface" style={{ display: 'flex', flexDirection: 'column', minHeight: 320, overflow: 'hidden' }}><div style={{ padding: '6px 10px', borderBottom: '1px solid var(--border)', background: 'var(--secondary)', fontSize: 11, color: 'var(--muted-foreground)', display: 'flex', justifyContent: 'space-between' }}><strong style={{ color: 'var(--foreground)' }}>{m.title}</strong><span style={{ fontFamily: 'var(--font-mono)', fontSize: 10 }}>{m.engine}</span></div><div style={{ flex: 1 }}><MediaCard media={m} /></div></div>)}
                </div>
              )}
              {activeSurface === 'automation' && (
                <div style={{ position: 'absolute', inset: 0, padding: 16, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: 16, overflowY: 'auto' }} className="scrollbar-thin">
                  {automations.map((a) => <div key={a.id} className="node-surface" style={{ display: 'flex', flexDirection: 'column', minHeight: 320, overflow: 'hidden' }}><div style={{ padding: '6px 10px', borderBottom: '1px solid var(--border)', background: 'var(--secondary)', fontSize: 11, color: 'var(--muted-foreground)', display: 'flex', justifyContent: 'space-between' }}><strong style={{ color: 'var(--foreground)' }}>{a.name}</strong><span style={{ fontFamily: 'var(--font-mono)', fontSize: 10 }}>{a.trigger.kind}</span></div><div style={{ flex: 1 }}><AutomationCard automation={a} onExecute={async (id) => { await fetch('/api/automation/execute', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ automationId: id }) }); }} /></div></div>)}
                </div>
              )}
              {activeSurface === 'agents' && (
                <div style={{ position: 'absolute', inset: 0, padding: 16, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))', gap: 16, overflowY: 'auto' }} className="scrollbar-thin">
                  {agents.map((a) => <div key={a.id} className="node-surface" style={{ display: 'flex', flexDirection: 'column', minHeight: 320, overflow: 'hidden' }}><div style={{ padding: '6px 10px', borderBottom: '1px solid var(--border)', background: 'var(--secondary)', fontSize: 11, color: 'var(--muted-foreground)', display: 'flex', justifyContent: 'space-between' }}><strong style={{ color: 'var(--foreground)' }}>{a.name}</strong><span style={{ fontFamily: 'var(--font-mono)', fontSize: 10 }}>agent</span></div><div style={{ flex: 1 }}><AgentCard agent={a} onInvoke={async (id) => { await fetch('/api/agent/invoke', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ agentId: id }) }); }} /></div></div>)}
                </div>
              )}
              {activeSurface === 'shell' && <div style={{ position: 'absolute', inset: 16 }}><ShellCard workspaceId={workspaceId} /></div>}
              {activeSurface === 'audit' && <AuditDashboard workspaceId={workspaceId} />}
              {activeSurface === 'rbac' && <RbacManager workspaceId={workspaceId} />}
              {activeSurface === 'templates' && <TemplatesGallery onCreated={(wsId) => { setWorkspace(wsId); setActiveSurface('chat'); }} />}
              {activeSurface === 'zlayers' && <div style={{ padding: 16, overflowY: 'auto' }} className="scrollbar-thin"><ZLayerPanel workspaceId={workspaceId} /></div>}
            </DrawerSystem>
          </div>
        </main>
      </div>

      <CommandPalette open={paletteOpen} onClose={() => setPaletteOpen(false)} onAction={handlePaletteAction} workspaceId={workspaceId} />
      <OnboardingTour userId="user:demo" onAction={(cmd) => { if (cmd.startsWith('switch-surface:')) setActiveSurface(cmd.slice('switch-surface:'.length)); }} />
      <QuickActionsMenu onSearch={() => setPaletteOpen(true)} onShellCommand={() => setActiveSurface('shell')} onOpenDoc={() => setActiveSurface('docs')} onOpenVideo={() => setActiveSurface('media')} onSwitchWorkspace={() => {}} />
    </div>
  );
}
