# Analysis: UX: Frontend Performance & Asset Modernization

> Every finding below cites a real file and line number from the
> cloned vivim repo (commit 71886e9, 2014-12-22). Open the file at the
> cited line to verify each claim.

## Summary

The frontend ships CoffeeScript (deprecated, removed from Rails 7 defaults), Turbolinks (replaced by Hotwire/Turbo in 2021), jQuery as a global (90KB), three jQuery plugins (flexslider, colorbox, owl.carousel), and render-blocking Google Fonts. All project screenshots are PNG (no WebP). This package cuts the JS payload, removes deprecated tech, and modernizes the asset pipeline.

## Findings (8 total)

## [UX8-01] CoffeeScript is deprecated and removed from Rails 7 defaults

- **Severity**: high
- **Category**: UX & Features

### Evidence

**`app/assets/javascripts/application.js.coffee:1-15`**

```
#= require jquery\n#= require jquery_ujs\n#= require app\n#= require bootstrap\n#= require jquery.flexslider\n#= require jquery.colorbox\n#= require owl.carousel\n#= require turbolinks\n#= require_tree .\n\n$ ->\n  $('a.colorbox').colorbox(rel: 'a.colorbox')\n  $(".group1").colorbox({rel:'group1'})\n  $(".owl-carousel").owlCarousel({\n      autoPlay: 3000\n    })
```

### Impact

CoffeeScript was the Rails default JS language from 2011-2017. It was demoted in Rails 5.1 (2017) and removed from the default Gemfile in Rails 6.0 (2019). The CoffeeScript compiler itself is in maintenance mode - no new features since 2017. New developers will not know the syntax, the tooling is stale, and the language will not receive updates. Modern Rails uses ES6+ via esbuild or importmap.

### Recommendation

Transpile the .coffee file to .js (decaf.js does this automatically). Replace the jQuery plugin calls with vanilla JS or modern npm packages. Remove the coffee-rails gem from the Gemfile.

---

## [UX8-02] Turbolinks is deprecated - replaced by Hotwire/Turbo in 2021

- **Severity**: high
- **Category**: UX & Features

### Evidence

**`app/assets/javascripts/application.js.coffee:8`**

```
#= require turbolinks
```

**`app/views/layouts/application.html.slim:14-15`**

```
= stylesheet_link_tag 'application', 'data-turbolinks-track' => true\n= javascript_include_tag 'application', 'data-turbolinks-track' => true
```

### Impact

Turbolinks was the Rails page-transition accelerator from 2013-2020. It was deprecated in 2020 and replaced by Hotwire/Turbo (turbo-rails gem) in Rails 7. The turbolinks gem has not had a release since 2020 and does not work well with modern JS (it breaks ES modules, import maps, and any code using DOMContentLoaded). Continuing to use it blocks any Rails 6+ upgrade.

### Recommendation

Replace turbolinks with @hotwired/turbo-rails. Change data-turbolinks-track to data-turbo-track. Remove gem 'turbolinks' from the Gemfile.

---

## [UX8-03] jQuery loaded as a global - 90KB+ for what could be 0KB of vanilla JS

- **Severity**: high
- **Category**: UX & Features

### Evidence

**`app/assets/javascripts/application.js.coffee:1`**

```
#= require jquery
```

**`app/assets/javascripts/application.js.coffee:2`**

```
#= require jquery_ujs
```

**`Gemfile:40-45`**

```
(jquery-rails gem is present - provides jQuery 1.x or 2.x)
```

### Impact

jQuery 1.x is ~95KB minified, ~32KB gzipped. The entire use of jQuery on this site is: 3 lines of colorbox setup, 1 line of owl carousel setup, and 2 inline onclick handlers. All of that is replaceable with vanilla JS in <500 bytes. Loading jQuery also trains the team to reach for $('...') instead of document.querySelector, blocking modernization.

### Recommendation

Replace jQuery selectors with native querySelector/querySelectorAll. Replace jQuery.colorbox with GLightbox (5KB). Replace owl.carousel with a CSS-only carousel (scroll-snap). Remove jquery-rails and jquery-ujs from the Gemfile (Rails 7 uses @rails/ujs or rails-ujs via importmap).

---

## [UX8-04] Google Fonts loaded render-blocking without preconnect

- **Severity**: medium
- **Category**: UX & Features

### Evidence

**`app/views/layouts/application.html.slim:16`**

```
link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'
```

### Impact

The Google Fonts stylesheet is render-blocking (no async/media=print trick) and loaded over HTTP (also flagged in WEB-07). Without preconnect, the browser must discover the fonts.googleapis.com DNS, TLS, and TCP round-trips after parsing the <link>. This adds 200-400ms to first paint on cold visits. The font request also loads 10 weights (200/300/400/600/700/900 + italics) when the site visually uses maybe 3.

### Recommendation

Add <link rel='preconnect' href='https://fonts.googleapis.com'> and <link rel='preconnect' href='https://fonts.gstatic.com' crossorigin> before the stylesheet. Cut the URL to only the weights actually used (200, 400, 600, 700). Better: self-host the subset to eliminate the third-party request entirely.

---

## [UX8-05] All project screenshots are PNG (no WebP/AVIF) - 30-50% larger

- **Severity**: medium
- **Category**: UX & Features

### Evidence

**`app/views/index/index.html.slim:62-122`**

```
(13 image references in the project carousel, all .png)
```

### Evidence block

```
Image references in app/views/index/index.html.slim:
  Line 3:   images/devices.png                              (hero)
  Line 13:  images/mobile-app-design-denver.png
  Line 23:  images/feature1.png
  Line 31:  images/feature2.png
  Line 39:  images/feature3.jpg                             (only .jpg in the set)
  Line 47:  images/mobile-app-development-denver.png
  Lines 62-122 (carousel, 13 entries):
    images/iPhone-App-Design-in-denver.png
    images/iPhone-app- develpment-company-denver.png    <-- note the SPACE in filename
    images/mobile-denver-app-development.png
    images/iOS-app-development-in-denver.png
    images/android-app-design-denver.png
    images/android-app-development-company-denver.png
    images/iphone-app-development-company-denver.png
    images/mobile-application-development.png
    images/denver-website-design.png
    images/denver-web-design.png
    images/denver-mobile-application-development.png
    images/android-app-development-denver.png
    images/WebDesign.png

Total: ~19 PNG references, 0 WebP, 0 AVIF. PNG screenshots of UIs compress
30-50% smaller as WebP and 50-70% smaller as AVIF with no visual loss.
```

### Impact

PNG is a lossless format designed for screenshots with limited colors. For photographic or gradient-heavy UI screenshots, WebP and AVIF deliver 30-70% smaller files at equivalent visual quality. The 19 PNGs on this page collectively likely total 2-5MB - converted to WebP they'd be 1-2.5MB. Mobile users on 4G pay the bandwidth cost in seconds of wait.

### Recommendation

Batch-convert all PNGs to WebP using cwebp (or sharp if Node-based). Use the <picture> element with <source srcset='*.webp' type='image/webp'> and a <img src='*.png'> fallback. Add AVIF as a first <source> for browsers that support it (Chrome 85+, Firefox 93+, Safari 16+).

---

## [UX8-06] Stylesheet uses .sass indented syntax (deprecated in favor of .scss)

- **Severity**: medium
- **Category**: UX & Features

### Evidence

**`app/assets/stylesheets/application.css.sass:1-7`**

```
//= require theme\n//= require vendor/font-awesome\n//= require colorbox\n//= require owl.carousel\n//= require owl.theme\n//= require_tree .\n//= require_self
```

### Impact

The .sass indented syntax (no curly braces, no semicolons, whitespace-significant) was the original Sass syntax. The .scss syntax (CSS-superset, curly braces, semicolons) overtook it in popularity around 2010. The Sass team has discussed deprecating .sass entirely. New developers almost universally know .scss, not .sass. Staying on .sass makes hiring and onboarding harder.

### Recommendation

Rename to application.scss (or application.css.scss for Rails compatibility). Convert any indented-syntax rules to scss. The sass-convert CLI tool does this automatically.

---

## [UX8-07] Three jQuery plugins loaded (flexslider, colorbox, owl.carousel) for a single page

- **Severity**: medium
- **Category**: UX & Features

### Evidence

**`app/assets/javascripts/application.js.coffee:4-7`**

```
#= require bootstrap\n#= require jquery.flexslider\n#= require jquery.colorbox\n#= require owl.carousel
```

**`app/assets/stylesheets/application.css.sass:3-6`**

```
//= require colorbox\n//= require owl.carousel\n//= require owl.theme
```

### Impact

Three jQuery plugins loaded for: a lightbox (colorbox, ~20KB), a carousel (owl.carousel, ~30KB), and a slider (flexslider, ~25KB - though flexslider isn't actually used in any view I can find). Combined: ~75KB of JS + their CSS. Each plugin has its own theme, its own API, and its own jQuery version constraints. This is a maintenance and bundle-size nightmare.

### Recommendation

Audit usage: flexslider appears unused (no .flexslider class in any view) - remove it. Replace colorbox with GLightbox (5KB, vanilla JS). Replace owl.carousel with a CSS scroll-snap carousel (0KB JS) or Embla Carousel (5KB). Total JS for these features drops from 75KB to <10KB.

---

## [UX8-08] Google Fonts link has no integrity or crossorigin attributes

- **Severity**: low
- **Category**: UX & Features

### Evidence

**`app/views/layouts/application.html.slim:16`**

```
link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900,200italic,300italic,400italic,600italic,700italic,900italic' rel='stylesheet' type='text/css'
```

### Impact

Without crossorigin='anonymous', the browser cannot use the response for any crossorigin-enabled feature. Without integrity='sha384-...', a compromised Google Fonts CDN could inject modified CSS into the page. While the risk is low (Google's CDN is well-protected), SRI is a defense-in-depth measure and a CSP best practice.

### Recommendation

Add crossorigin='anonymous' and integrity='sha384-...' (compute with openssl dgst -sha384 -binary fonts.css | openssl base64 -A). Better: self-host the font to eliminate the cross-origin request entirely.

---

## Verification protocol

For each finding:

1. Open the cited file in the cloned repo at the cited line.
2. Confirm the snippet matches what is in the file.
3. Confirm the impact description matches what the code does.
4. Apply the recommendation.
5. Run the matching spec in `SPECS.md` to verify the fix.

If any finding's evidence does not match the actual file content,
**do not apply the recommendation** - report the discrepancy so the
analysis can be corrected.
