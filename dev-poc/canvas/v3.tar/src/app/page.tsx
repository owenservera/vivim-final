'use client';

/**
 * app/page.tsx — Vivim Universal Canvas (Phase 2)
 * --------------------------------------------------------------------
 * The unified canvas surface. The shell is dumb (P2): it renders
 * whatever routeSync resolves. No provider conditionals. No hardcoded
 * tools. The richness lives in the engines + DB + plugins.
 *
 * Phase 2 adds:
 *   - Workspace switcher (global + child workspaces, 3D z-depth stack)
 *   - Surface tabs: chat / docs / media / automation / agents / shell
 *   - Doc / Video / Audio / Automation / Agent / Shell cards all
 *     rendered live on the canvas (no rebuild)
 *   - CLI two-way: the ShellCard dispatches commands through the SAME
 *     CommandRegistry the thin CLI client uses (FRONTEND=BACKEND two-way)
 */

import { useEffect, useState } from 'react';
import { CanvasSurface, LiveConfigProvider, useLiveConfig } from '@/components/canvas';
import { WorkspaceSwitcher } from '@/components/canvas/WorkspaceSwitcher';
import {
  DocCard,
  MediaCard,
  AutomationCard,
  AgentCard,
  ShellCard,
} from '@/components/canvas/cards';
import type { AccountContext, PlanTier } from '@/shared/route-context';
import type { DocumentCard as DocumentCardRow } from '@/shared/document';
import type { MediaCard as MediaCardRow } from '@/shared/media';
import type { AutomationDefinition } from '@/shared/automation';
import type { AgentDefinition } from '@/shared/agent';
import type { WorkspaceTaxonomy } from '@/shared/workspace';

const PROVIDER_OPTIONS = [
  { id: 'chatgpt', label: 'ChatGPT (ai-chat)' },
  { id: 'claude', label: 'Claude (ai-chat)' },
  { id: 'gemini', label: 'Gemini (ai-chat)' },
  { id: 'gmail', label: 'Gmail (email)' },
  { id: 'outlook', label: 'Outlook (email)' },
  { id: 'whatsapp', label: 'WhatsApp (messenger)' },
  { id: 'slack', label: 'Slack (messenger)' },
  { id: 'telegram', label: 'Telegram (messenger)' },
  { id: 'twitter', label: 'Twitter (social)' },
  { id: 'linkedin', label: 'LinkedIn (social)' },
  { id: 'mastodon', label: 'Mastodon (social)' },
  { id: 'notion', label: 'Notion (custom)' },
  { id: 'linear', label: 'Linear (custom)' },
];

const TIER_OPTIONS: PlanTier[] = ['free', 'trial', 'pro', 'enterprise'];

const SURFACES = [
  { slug: 'chat', label: 'Chat', icon: '💬' },
  { slug: 'docs', label: 'Documents', icon: '📄' },
  { slug: 'media', label: 'Media', icon: '🎬' },
  { slug: 'automation', label: 'Automation', icon: '⚡' },
  { slug: 'agents', label: 'Agents', icon: '🤖' },
  { slug: 'shell', label: 'Shell', icon: '⌨️' },
] as const;

export default function Home() {
  return (
    <LiveConfigProvider
      initialWorkspaceId="ws:global"
      initialUserId="user:demo"
      initialProviderIds={['chatgpt']}
      initialAccounts={[
        { accountId: 'acct:chatgpt:free', providerId: 'chatgpt', planTier: 'free' },
      ]}
    >
      <CanvasApp />
    </LiveConfigProvider>
  );
}

function CanvasApp() {
  const {
    surface,
    isLoading,
    error,
    workspaceId,
    setWorkspace,
    providerIds,
    setProviderIds,
    accounts,
    setAccounts,
    variant,
    setVariant,
  } = useLiveConfig();

  const [draftVariant, setDraftVariant] = useState('');
  const [activeSurface, setActiveSurface] = useState<(typeof SURFACES)[number]['slug']>('chat');
  const [docs, setDocs] = useState<DocumentCardRow[]>([]);
  const [medias, setMedias] = useState<MediaCardRow[]>([]);
  const [automations, setAutomations] = useState<AutomationDefinition[]>([]);
  const [agents, setAgents] = useState<AgentDefinition[]>([]);
  const [workspaces, setWorkspaces] = useState<WorkspaceTaxonomy[]>([]);

  // Load Phase 2 surfaces on mount.
  useEffect(() => {
    // Docs (one sample doc of each kind).
    Promise.all([
      fetch('/api/document/open', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: 'Welcome to Vivim',
          mimeType: 'text/markdown',
          inlineContent:
            '# Welcome to Vivim Universal Canvas\n\nPhase 2 turns the canvas into a workspace OS:\n\n- **Documents** — PDF, Office, Markdown, code (shiki)\n- **Media** — video / audio via VLC bridge\n- **Automation** — 100 pre-seeded core automations\n- **Agents** — composable step DAGs with HITL gates\n- **Shell** — two-way CLI surface (FRONTEND=BACKEND)\n\nEvery card is a CanvasDefinition row — hot-swappable, no rebuild.',
          workspaceId,
        }),
      }).then((r) => r.json()),
      fetch('/api/document/open', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: 'sample.ts',
          mimeType: 'text/typescript',
          inlineContent:
            '// A sample TypeScript document.\n// Production renders this with shiki syntax highlighting.\n\nexport function routeSync(ctx: RouteContext): ResolvedSurface {\n  return walkTree(ctx);\n}\n',
          language: 'typescript',
          workspaceId,
        }),
      }).then((r) => r.json()),
    ]).then((rs) => {
      const ds = (rs as Array<{ ok: boolean; document: DocumentCardRow }>)
        .filter((r) => r.ok)
        .map((r) => r.document);
      setDocs(ds);
    });

    // Media (one video + one audio sample).
    Promise.all([
      fetch('/api/media/open', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: 'Big Buck Bunny (sample)',
          kind: 'video',
          sourceUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
          mimeType: 'video/mp4',
          durationSec: 596,
          workspaceId,
        }),
      }).then((r) => r.json()),
      fetch('/api/media/open', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: 'Sample audio clip',
          kind: 'audio',
          sourceUrl: 'https://example.com/sample.mp3',
          mimeType: 'audio/mpeg',
          durationSec: 42,
          workspaceId,
        }),
      }).then((r) => r.json()),
    ]).then((rs) => {
      const ms = (rs as Array<{ ok: boolean; media: MediaCardRow }>)
        .filter((r) => r.ok)
        .map((r) => r.media);
      setMedias(ms);
    });

    // Automations + agents (pre-seeded).
    fetch(`/api/automation/list?workspaceId=${encodeURIComponent(workspaceId)}`)
      .then((r) => r.json())
      .then((d: { ok: boolean; automations: AutomationDefinition[] }) =>
        setAutomations(d.ok ? d.automations.slice(0, 4) : []),
      )
      .catch(() => setAutomations([]));

    fetch(`/api/agent/list?workspaceId=${encodeURIComponent(workspaceId)}`)
      .then((r) => r.json())
      .then((d: { ok: boolean; agents: AgentDefinition[] }) =>
        setAgents(d.ok ? d.agents : []),
      )
      .catch(() => setAgents([]));

    fetch('/api/workspace/list')
      .then((r) => r.json())
      .then((d: { ok: boolean; workspaces: WorkspaceTaxonomy[] }) =>
        setWorkspaces(d.ok ? d.workspaces : []),
      )
      .catch(() => setWorkspaces([]));
  }, []);

  const toggleProvider = (id: string) => {
    const isOn = providerIds.includes(id);
    if (isOn) {
      const next = providerIds.filter((p) => p !== id);
      setProviderIds(next);
      setAccounts(accounts.filter((a) => a.providerId !== id));
    } else {
      setProviderIds([...providerIds, id]);
      setAccounts([
        ...accounts,
        { accountId: `acct:${id}:free`, providerId: id, planTier: 'free' as const },
      ]);
    }
  };

  const cycleTier = (providerId: string) => {
    setAccounts(
      accounts.map((a) => {
        if (a.providerId !== providerId) return a;
        const idx = TIER_OPTIONS.indexOf(a.planTier);
        const next = TIER_OPTIONS[(idx + 1) % TIER_OPTIONS.length]!;
        return { ...a, planTier: next };
      }),
    );
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        display: 'flex',
        fontFamily: 'ui-sans-serif, system-ui, -apple-system, sans-serif',
        background: '#fafafa',
        color: '#1f2937',
      }}
    >
      {/* Sidebar */}
      <aside
        style={{
          width: 280,
          flexShrink: 0,
          borderRight: '1px solid #e5e7eb',
          background: 'white',
          overflowY: 'auto',
          padding: 16,
          display: 'flex',
          flexDirection: 'column',
          gap: 16,
        }}
      >
        <header>
          <h1 style={{ margin: 0, fontSize: 18, fontWeight: 700 }}>Vivim Universal Canvas</h1>
          <p style={{ margin: '4px 0 0', fontSize: 11, color: '#6b7280' }}>
            Phase 2 · Workspace OS · Plugin-based · Two-way CLI
          </p>
        </header>

        <WorkspaceSwitcher
          currentWorkspaceId={workspaceId}
          onSwitch={(id) => setWorkspace(id)}
          onCreate={() => {
            const slug = prompt('Workspace slug:');
            if (!slug) return;
            fetch('/api/workspace/list', { method: 'POST' }).catch(() => {});
            setWorkspace(`ws:${slug}`);
          }}
        />

        <section>
          <label style={labelStyle}>Variant</label>
          <div style={{ display: 'flex', gap: 4, marginTop: 4 }}>
            <input
              type="text"
              value={draftVariant}
              placeholder="opus, workspace, voice"
              onChange={(e) => setDraftVariant(e.target.value)}
              style={inputStyle}
            />
            <button onClick={() => setVariant(draftVariant || undefined)} style={btnStyle}>
              Set
            </button>
            <button
              onClick={() => {
                setVariant(undefined);
                setDraftVariant('');
              }}
              style={btnStyle}
            >
              Clear
            </button>
          </div>
          {variant && (
            <div style={{ marginTop: 4, fontSize: 11, color: '#6b7280' }}>
              Current: <code>{variant}</code>
            </div>
          )}
        </section>

        <section>
          <label style={labelStyle}>Providers ({providerIds.length})</label>
          <ul
            style={{
              listStyle: 'none',
              padding: 0,
              margin: '4px 0 0',
              display: 'flex',
              flexDirection: 'column',
              gap: 2,
            }}
          >
            {PROVIDER_OPTIONS.map((p) => {
              const isOn = providerIds.includes(p.id);
              const acct = accounts.find((a) => a.providerId === p.id);
              return (
                <li key={p.id}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 6,
                      padding: '4px 6px',
                      borderRadius: 4,
                      background: isOn ? '#f0fdf4' : 'transparent',
                      border: isOn ? '1px solid #86efac' : '1px solid transparent',
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={isOn}
                      onChange={() => toggleProvider(p.id)}
                      style={{ margin: 0 }}
                    />
                    <span style={{ flex: 1, fontSize: 12 }}>{p.label}</span>
                    {isOn && acct && (
                      <button
                        onClick={() => cycleTier(p.id)}
                        title="Cycle plan tier"
                        style={{
                          padding: '1px 6px',
                          border: '1px solid #d1d5db',
                          background: 'white',
                          borderRadius: 3,
                          fontSize: 10,
                          cursor: 'pointer',
                          fontFamily: 'ui-monospace, monospace',
                        }}
                      >
                        {acct.planTier}
                      </button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        </section>

        <section style={{ marginTop: 'auto', fontSize: 10, color: '#9ca3af', borderTop: '1px solid #e5e7eb', paddingTop: 8 }}>
          <div>trace: <code>{surface?.traceId.slice(0, 16)}…</code></div>
          <div>resolved in {surface?.durationMs ?? '—'}ms</div>
          <div>slots: {surface?.slots.length ?? 0}</div>
          {isLoading && <div style={{ color: '#f59e0b' }}>resolving…</div>}
          {error && <div style={{ color: '#dc2626' }}>error: {String(error.message)}</div>}
        </section>
      </aside>

      {/* Main canvas area */}
      <main style={{ flex: 1, display: 'flex', flexDirection: 'column', position: 'relative' }}>
        {/* Surface tabs */}
        <div
          style={{
            display: 'flex',
            borderBottom: '1px solid #e5e7eb',
            background: 'white',
            padding: '0 8px',
          }}
        >
          {SURFACES.map((s) => {
            const active = activeSurface === s.slug;
            return (
              <button
                key={s.slug}
                onClick={() => setActiveSurface(s.slug)}
                style={{
                  padding: '8px 14px',
                  border: 'none',
                  borderBottom: active ? '2px solid #f59e0b' : '2px solid transparent',
                  background: 'transparent',
                  cursor: 'pointer',
                  fontSize: 12,
                  fontWeight: active ? 600 : 400,
                  color: active ? '#1f2937' : '#6b7280',
                  fontFamily: 'inherit',
                }}
              >
                <span style={{ marginRight: 6 }}>{s.icon}</span>
                {s.label}
              </button>
            );
          })}
        </div>

        {/* Surface content — the shell is dumb; it renders cards based on activeSurface */}
        <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>
          {activeSurface === 'chat' && (
            <CanvasSurface
              workspaceId={workspaceId}
              userId="user:demo"
              providerIds={providerIds}
              accounts={accounts}
              variant={variant}
            />
          )}

          {activeSurface === 'docs' && (
            <CardGrid>
              {docs.map((doc) => (
                <CardFrame key={doc.id} title={doc.title} badge={doc.engine}>
                  <DocCard document={doc} />
                </CardFrame>
              ))}
              {docs.length === 0 && <EmptyCard label="No documents open" />}
            </CardGrid>
          )}

          {activeSurface === 'media' && (
            <CardGrid>
              {medias.map((m) => (
                <CardFrame key={m.id} title={m.title} badge={m.engine}>
                  <MediaCard media={m} />
                </CardFrame>
              ))}
              {medias.length === 0 && <EmptyCard label="No media open" />}
            </CardGrid>
          )}

          {activeSurface === 'automation' && (
            <CardGrid>
              {automations.map((a) => (
                <CardFrame key={a.id} title={a.name} badge={`auto · ${a.trigger.kind}`}>
                  <AutomationCard
                    automation={a}
                    onExecute={async (id) => {
                      await fetch('/api/automation/execute', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ automationId: id }),
                      });
                    }}
                  />
                </CardFrame>
              ))}
              {automations.length === 0 && <EmptyCard label="No automations" />}
            </CardGrid>
          )}

          {activeSurface === 'agents' && (
            <CardGrid>
              {agents.map((a) => (
                <CardFrame key={a.id} title={a.name} badge="agent">
                  <AgentCard
                    agent={a}
                    onInvoke={async (id) => {
                      await fetch('/api/agent/invoke', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ agentId: id }),
                      });
                    }}
                  />
                </CardFrame>
              ))}
              {agents.length === 0 && <EmptyCard label="No agents" />}
            </CardGrid>
          )}

          {activeSurface === 'shell' && (
            <div style={{ position: 'absolute', inset: 16 }}>
              <ShellCard workspaceId={workspaceId} />
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

function CardGrid({ children }: { children: React.ReactNode }) {
  return (
    <div
      style={{
        position: 'absolute',
        inset: 0,
        padding: 16,
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(360px, 1fr))',
        gap: 16,
        overflowY: 'auto',
      }}
    >
      {children}
    </div>
  );
}

function CardFrame({
  title,
  badge,
  children,
}: {
  title: string;
  badge: string;
  children: React.ReactNode;
}) {
  return (
    <div
      style={{
        display: 'flex',
        flexDirection: 'column',
        minHeight: 320,
        borderRadius: 8,
        border: '1px solid #e5e7eb',
        background: 'white',
        boxShadow: '0 6px 24px -8px rgba(0,0,0,0.18)',
        overflow: 'hidden',
      }}
    >
      <div
        style={{
          padding: '6px 10px',
          borderBottom: '1px solid #f3f4f6',
          background: '#fafafa',
          fontSize: 11,
          color: '#6b7280',
          display: 'flex',
          justifyContent: 'space-between',
        }}
      >
        <strong style={{ color: '#374151' }}>{title}</strong>
        <span style={{ fontFamily: 'ui-monospace, monospace', fontSize: 10 }}>{badge}</span>
      </div>
      <div style={{ flex: 1 }}>{children}</div>
    </div>
  );
}

function EmptyCard({ label }: { label: string }) {
  return (
    <div
      style={{
        gridColumn: '1 / -1',
        padding: 48,
        textAlign: 'center',
        color: '#9ca3af',
        fontSize: 13,
      }}
    >
      {label}
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  fontSize: 11,
  fontWeight: 600,
  color: '#6b7280',
  textTransform: 'uppercase',
  letterSpacing: '0.05em',
};
const inputStyle: React.CSSProperties = {
  flex: 1,
  padding: '6px 8px',
  border: '1px solid #d1d5db',
  borderRadius: 4,
  fontSize: 12,
  fontFamily: 'ui-monospace, monospace',
};
const btnStyle: React.CSSProperties = {
  padding: '6px 10px',
  border: '1px solid #d1d5db',
  background: '#f3f4f6',
  borderRadius: 4,
  fontSize: 12,
  cursor: 'pointer',
  fontFamily: 'inherit',
};
