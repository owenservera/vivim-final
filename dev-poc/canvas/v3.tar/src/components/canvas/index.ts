/**
 * components/canvas/index.ts — barrel.
 * Phase 2 adds: WorkspaceSwitcher + cards (Doc/Media/Automation/Agent/Shell).
 */
export { CanvasSurface } from './CanvasSurface';
export type { CanvasSurfaceProps } from './CanvasSurface';
export { CanvasNode } from './CanvasNode';
export type { CanvasNodeProps } from './CanvasNode';
export { SandboxedNode } from './SandboxedNode';
export type { SandboxedNodeProps, SandboxAuditEvent } from './SandboxedNode';
export { useResolvedNodes } from './use-resolved-nodes';
export { useCanvasEvents, getCanvasEventBus } from './use-canvas-events';
export type { CanvasEvent } from './use-canvas-events';
export { EventBus } from './event-bus';
export { CommandStack } from './command-stack';
export type { Command } from './command-stack';
export { QuadTree } from './quad-tree';
export type { BoundingBox, Vec2, QTEntry } from './quad-tree';
export { worldToScreen, screenToWorld, clampZoom } from './transform';
export type { ViewportState } from './transform';
export { LiveConfigProvider, useLiveConfig } from './LiveConfigProvider';
export type { LiveConfigContextValue, LiveConfigProviderProps } from './LiveConfigProvider';

// Phase 2
export { WorkspaceSwitcher } from './WorkspaceSwitcher';
export type { WorkspaceSwitcherProps } from './WorkspaceSwitcher';
export { DocCard, MediaCard, AutomationCard, AgentCard, ShellCard } from './cards';
export type { DocCardProps, MediaCardProps, AutomationCardProps, AgentCardProps } from './cards';
