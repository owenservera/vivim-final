/**
 * storage/contracts/index.ts — barrel.
 * Phase 2 adds: workspace, document, media, automation, agent,
 * hitl-gate, policy-rule, shell-command stores.
 */
export * from './ui-component-store';
export * from './provider-type-store';
export * from './primitive-store';
export * from './provider-store';
export * from './account-store';
export * from './capability-tier-store';
export * from './user-layout-store';
export * from './canvas-definition-store';

// Phase 2
export * from './workspace-store';
export * from './document-store';
export * from './media-store';
export * from './automation-store';
export * from './agent-store';
export * from './shell-command-store';
