#!/usr/bin/env python3
"""
Generate a self-contained HTML page that lets users download
the full Canvas SDK + LLM I/O Harness project as a .zip file.
Uses JSZip (CDN) for in-browser zip generation.
"""

import os
import html
import json
from datetime import datetime

BASE = "/home/z/my-project"
SDK_BASE = os.path.join(BASE, "src/lib/canvas-sdk")
OUT = os.path.join(BASE, "download/canvas-sdk-llm-harness.html")

# ── Read all existing SDK source files ──────────────────────────────────────

def read_file(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()

# Canvas SDK Core
core_types = read_file(os.path.join(SDK_BASE, "types.ts"))
core_event_bus = read_file(os.path.join(SDK_BASE, "event-bus.ts"))
core_command_stack = read_file(os.path.join(SDK_BASE, "command-stack.ts"))
core_scene = read_file(os.path.join(SDK_BASE, "scene.ts"))
core_quad_tree = read_file(os.path.join(SDK_BASE, "quad-tree.ts"))
core_engine = read_file(os.path.join(SDK_BASE, "engine.ts"))
core_plugin_api = read_file(os.path.join(SDK_BASE, "plugin-api.ts"))
core_index = read_file(os.path.join(SDK_BASE, "index.ts"))

# Tools (using the tools/index.ts unified versions + individual files)
tools_index = read_file(os.path.join(SDK_BASE, "tools/index.ts"))

# Renderers
renderers_index = read_file(os.path.join(SDK_BASE, "renderers/index.ts"))

# ── LLM I/O Harness source (from specification) ────────────────────────────

llm_schema_core = r'''/* ============================================================
   LLM I/O Harness — Schema Core: Zod Repair Extensions
   Foundation layer extending Zod with repair-aware metadata.
   ============================================================ */

import { z } from 'zod';

// Custom Zod metadata for repair hints
declare module 'zod' {
  interface ZodType {
    _repair?: RepairMetadata;
    repair(metadata: RepairMetadata): this;
  }
}

export interface RepairMetadata {
  aliases?: string[];           // Alternative key names (e.g., ['usr', 'user_name'])
  coerceFrom?: z.ZodType[];     // Types to attempt coercion from
  defaultValue?: unknown;       // Fallback value
  semanticValidator?: (val: unknown) => boolean;
  description?: string;
}

// Extend Zod with repair capability
z.ZodType.prototype.repair = function(metadata: RepairMetadata) {
  (this as any)._repair = metadata;
  return this;
};

// Helper: Create a repair-aware string field
export const repairString = (opts: {
  aliases?: string[];
  default?: string;
  coerce?: boolean;
}) => z.string()
  .min(1)
  .repair({
    aliases: opts.aliases,
    coerceFrom: opts.coerce ? [z.number(), z.boolean()] : [],
    defaultValue: opts.default,
  });

// Helper: Create a repair-aware number field
export const repairNumber = (opts: {
  aliases?: string[];
  default?: number;
  min?: number;
  max?: number;
}) => z.coerce.number()
  .min(opts.min ?? -Infinity)
  .max(opts.max ?? Infinity)
  .repair({
    aliases: opts.aliases,
    coerceFrom: [z.string()],
    defaultValue: opts.default,
  });
'''

llm_schema_contracts = r'''/* ============================================================
   LLM I/O Harness — Contract Definition Layer
   Defines repair-aware Zod schemas for structured extraction.
   ============================================================ */

import { z } from 'zod';
import { repairString, repairNumber } from './core';

// Example: User Extraction Contract
export const UserExtractionContract = z.object({
  user: z.object({
    id: repairNumber({ aliases: ['user_id', 'uid', 'id'], default: 0 }),
    name: repairString({ aliases: ['user_name', 'username', 'full_name'], default: 'unknown' }),
    email: repairString({ aliases: ['mail', 'user_email'] })
      .email()
      .optional()
      .repair({
        semanticValidator: (val) => typeof val === 'string' && val.includes('@'),
      }),
    role: z.enum(['admin', 'user', 'guest'])
      .default('user')
      .repair({
        aliases: ['user_role', 'type', 'permission'],
        coerceFrom: [z.string()],
      }),
    isActive: z.coerce.boolean()
      .default(true)
      .repair({
        aliases: ['active', 'is_active', 'enabled'],
        coerceFrom: [z.string(), z.number()],
      }),
  }),
  metadata: z.object({
    extractedAt: z.string().datetime().default(() => new Date().toISOString()),
    confidence: z.coerce.number().min(0).max(1).default(0.5),
    source: z.string().default('webapp'),
  }),
});

// Type inference
export type UserExtraction = z.infer<typeof UserExtractionContract>;

// Example: Analysis Result Contract
export const AnalysisContract = z.object({
  title: repairString({ aliases: ['heading', 'subject', 'name'], default: 'Untitled' }),
  summary: repairString({ aliases: ['description', 'abstract', 'overview'], default: '' }),
  score: repairNumber({ aliases: ['rating', 'grade', 'score_value'], default: 0, min: 0, max: 100 }),
  tags: z.array(z.string()).default([]).repair({
    aliases: ['labels', 'categories', 'topics'],
    coerceFrom: [z.string()],
  }),
  items: z.array(z.object({
    id: repairNumber({ default: 0 }),
    content: repairString({ default: '' }),
    priority: z.enum(['high', 'medium', 'low']).default('medium').repair({
      aliases: ['level', 'importance', 'severity'],
      coerceFrom: [z.string()],
    }),
  })).default([]),
  metadata: z.object({
    extractedAt: z.string().datetime().default(() => new Date().toISOString()),
    confidence: z.coerce.number().min(0).max(1).default(0.5),
    source: z.string().default('webapp'),
  }),
});

export type AnalysisResult = z.infer<typeof AnalysisContract>;
'''

llm_schema_registry = r'''/* ============================================================
   LLM I/O Harness — Schema Registry & Versioning
   Manages schema versions with migration support.
   ============================================================ */

import { z } from 'zod';

interface RegistryEntry<T> {
  version: string;
  schema: z.ZodType<T>;
  migrations?: Array<(data: unknown) => unknown>;
  deprecated?: boolean;
  description?: string;
}

export class SchemaRegistry {
  private schemas = new Map<string, Map<string, RegistryEntry<any>>>();

  register<T>(
    name: string,
    version: string,
    schema: z.ZodType<T>,
    options?: {
      migrations?: Array<(data: unknown) => unknown>;
      deprecated?: boolean;
      description?: string;
    }
  ): void {
    if (!this.schemas.has(name)) {
      this.schemas.set(name, new Map());
    }
    this.schemas.get(name)!.set(version, {
      version,
      schema,
      migrations: options?.migrations,
      deprecated: options?.deprecated,
      description: options?.description,
    });
  }

  resolve<T>(name: string, version: string = 'latest'): z.ZodType<T> {
    const versions = this.schemas.get(name);
    if (!versions) throw new Error(`Schema "${name}" not found in registry`);

    if (version === 'latest') {
      const sorted = Array.from(versions.entries())
        .filter(([, entry]) => !entry.deprecated)
        .sort(([a], [b]) => b.localeCompare(a, undefined, { numeric: true }));
      if (sorted.length === 0) {
        const allSorted = Array.from(versions.keys()).sort().reverse();
        return versions.get(allSorted[0])!.schema;
      }
      return sorted[0][1].schema;
    }

    const entry = versions.get(version);
    if (!entry) throw new Error(`Schema "${name}" v${version} not found`);
    if (entry.deprecated) {
      console.warn(`[SchemaRegistry] Schema "${name}" v${version} is deprecated`);
    }
    return entry.schema;
  }

  migrate<T>(name: string, fromVersion: string, toVersion: string, data: unknown): unknown {
    const versions = this.schemas.get(name);
    if (!versions) throw new Error(`Schema "${name}" not found`);

    const versionKeys = Array.from(versions.keys()).sort();
    const fromIdx = versionKeys.indexOf(fromVersion);
    const toIdx = versionKeys.indexOf(toVersion);

    if (fromIdx === -1) throw new Error(`Version "${fromVersion}" not found`);
    if (toIdx === -1) throw new Error(`Version "${toVersion}" not found`);

    const direction = toIdx > fromIdx ? 1 : -1;
    let current = data;

    for (let i = fromIdx + direction; i !== toIdx + direction; i += direction) {
      const entry = versions.get(versionKeys[i]);
      if (entry?.migrations) {
        for (const migration of entry.migrations) {
          current = migration(current);
        }
      }
    }

    return current;
  }

  listSchemas(): Array<{ name: string; versions: string[]; latest: string }> {
    const result: Array<{ name: string; versions: string[]; latest: string }> = [];
    for (const [name, versions] of this.schemas) {
      const versionKeys = Array.from(versions.keys()).sort().reverse();
      result.push({ name, versions: versionKeys, latest: versionKeys[0] });
    }
    return result;
  }
}

export const registry = new SchemaRegistry();
'''

llm_driver = r'''/* ============================================================
   LLM I/O Harness — WebApp Driver (Playwright-based)
   Manages browser automation for interacting with LLM WebApps.
   ============================================================ */

import { chromium, Browser, Page, BrowserContext } from 'playwright';

export interface WebAppConfig {
  url: string;
  inputSelector: string;
  submitSelector: string;
  outputSelector: string;
  loadTimeout?: number;
  streamingWaitSelector?: string;
  headless?: boolean;
  userAgent?: string;
  viewport?: { width: number; height: number };
}

export interface SessionState {
  cookies: any[];
  localStorage: Record<string, string>;
  lastPrompt: string;
  conversationHistory: string[];
}

export class WebAppDriver {
  private browser: Browser | null = null;
  private context: BrowserContext | null = null;
  private page: Page | null = null;
  private config: Required<Pick<WebAppConfig, 'loadTimeout' | 'headless'>> & WebAppConfig;

  constructor(config: WebAppConfig) {
    this.config = {
      loadTimeout: 30000,
      headless: true,
      ...config,
    };
  }

  async init(): Promise<void> {
    this.browser = await chromium.launch({
      headless: this.config.headless,
    });

    this.context = await this.browser.newContext({
      userAgent: this.config.userAgent,
      viewport: this.config.viewport ?? { width: 1280, height: 720 },
    });

    this.page = await this.context.newPage();
    await this.page.goto(this.config.url, { waitUntil: 'networkidle' });
  }

  async initWithSession(state: SessionState): Promise<void> {
    await this.init();
    if (this.context && state.cookies.length > 0) {
      await this.context.addCookies(state.cookies);
    }
    if (this.page && Object.keys(state.localStorage).length > 0) {
      await this.page.evaluate((ls) => {
        for (const [key, value] of Object.entries(ls)) {
          localStorage.setItem(key, value);
        }
      }, state.localStorage);
      await this.page.reload({ waitUntil: 'networkidle' });
    }
  }

  async sendPrompt(prompt: string): Promise<string> {
    if (!this.page) throw new Error('Driver not initialized. Call init() first.');

    // Type the prompt into the input field
    await this.page.fill(this.config.inputSelector, prompt);
    await this.page.click(this.config.submitSelector);

    // Wait for the response output element to appear
    await this.page.waitForSelector(this.config.outputSelector, {
      timeout: this.config.loadTimeout,
    });

    // Wait for streaming to complete (check for streaming indicator)
    if (this.config.streamingWaitSelector) {
      await this.page.waitForFunction(
        (selector: string, streamingSelector: string) => {
          const el = document.querySelector(selector);
          if (!el) return false;
          const streamingEl = document.querySelector(streamingSelector);
          return !streamingEl; // streaming complete when indicator is gone
        },
        this.config.outputSelector,
        this.config.streamingWaitSelector,
        { timeout: 60000 }
      );
    } else {
      // Fallback: wait for content to stabilize
      await this.page.waitForTimeout(2000);
    }

    // Extract raw HTML content
    const rawOutput = await this.page.$eval(
      this.config.outputSelector,
      (el) => el.innerHTML
    );

    return rawOutput;
  }

  async getSessionState(): Promise<SessionState> {
    if (!this.context || !this.page) {
      throw new Error('Driver not initialized');
    }
    const cookies = await this.context.cookies();
    const localStorage = await this.page.evaluate(() => {
      const ls: Record<string, string> = {};
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (key) ls[key] = localStorage.getItem(key) || '';
      }
      return ls;
    });
    return {
      cookies,
      localStorage,
      lastPrompt: '',
      conversationHistory: [],
    };
  }

  async takeScreenshot(path?: string): Promise<Buffer> {
    if (!this.page) throw new Error('Driver not initialized');
    return this.page.screenshot({ path, fullPage: true });
  }

  async cleanup(): Promise<void> {
    await this.page?.close();
    await this.context?.close();
    await this.browser?.close();
    this.page = null;
    this.context = null;
    this.browser = null;
  }

  get isInitialized(): boolean {
    return this.page !== null;
  }
}
'''

llm_extractor = r'''/* ============================================================
   LLM I/O Harness — DOM Extractor & Normalizer
   Parses raw HTML from WebApp responses into structured blocks.
   ============================================================ */

import * as cheerio from 'cheerio';

export interface ExtractedBlock {
  type: 'text' | 'code' | 'json' | 'table' | 'list' | 'markdown';
  content: string;
  language?: string;
  confidence: number;
  metadata?: Record<string, unknown>;
}

export interface ExtractionResult {
  blocks: ExtractedBlock[];
  totalLength: number;
  hasJsonBlock: boolean;
  hasCodeBlock: boolean;
}

export class ResponseExtractor {
  extract(rawHtml: string): ExtractionResult {
    const $ = cheerio.load(rawHtml);
    const blocks: ExtractedBlock[] = [];

    // 1. Process code blocks first (highest priority)
    $('pre code').each((_, el) => {
      const $el = $(el);
      const classAttr = $el.attr('class') || '';
      const language = classAttr.match(/language-(\w+)/)?.[1];
      const content = $el.text().trim();

      if (content.length > 0) {
        blocks.push({
          type: this.detectBlockType(content, language),
          content,
          language,
          confidence: language === 'json' ? 0.95 : 0.85,
          metadata: { source: 'code-block' },
        });
      }
    });

    // 2. Process inline code with JSON patterns
    $('code').not('pre code').each((_, el) => {
      const content = $(el).text().trim();
      if (content.length > 0 && (content.startsWith('{') || content.startsWith('['))) {
        blocks.push({
          type: 'json',
          content,
          confidence: 0.75,
          metadata: { source: 'inline-code' },
        });
      }
    });

    // 3. Process paragraphs and list items for embedded JSON
    $('p, li, td, div').each((_, el) => {
      const $el = $(el);
      // Skip if already inside a code block
      if ($el.closest('pre').length > 0) return;

      const text = $el.text().trim();
      if (text.length === 0) return;

      // Check for JSON objects/arrays embedded in text
      const jsonPatterns = /[\[{][\s\S]*?[\]}]/g;
      let match: RegExpExecArray | null;
      while ((match = jsonPatterns.exec(text)) !== null) {
        const candidate = match[0];
        // Heuristic: if it looks like JSON (has colons after keys), include it
        if (candidate.includes('":') || candidate.includes('": ')) {
          blocks.push({
            type: 'json',
            content: candidate,
            confidence: 0.6,
            metadata: { source: 'embedded-in-text' },
          });
        }
      }

      // Detect list blocks
      if ($el.is('li')) {
        const listText = $el.text().trim();
        blocks.push({
          type: 'list',
          content: listText,
          confidence: 0.7,
          metadata: { source: 'list-item' },
        });
      }
    });

    // 4. Process tables
    $('table').each((_, el) => {
      const $table = $(el);
      const headers: string[] = [];
      const rows: string[][] = [];

      $table.find('thead th').each((_, th) => {
        headers.push($(th).text().trim());
      });

      $table.find('tbody tr').each((_, tr) => {
        const row: string[] = [];
        $(tr).find('td').each((_, td) => {
          row.push($(td).text().trim());
        });
        if (row.length > 0) rows.push(row);
      });

      if (headers.length > 0 && rows.length > 0) {
        const tableJson = JSON.stringify({ headers, rows }, null, 2);
        blocks.push({
          type: 'table',
          content: tableJson,
          confidence: 0.8,
          metadata: { source: 'html-table', headers, rowCount: rows.length },
        });
      }
    });

    return {
      blocks,
      totalLength: blocks.reduce((sum, b) => sum + b.content.length, 0),
      hasJsonBlock: blocks.some(b => b.type === 'json'),
      hasCodeBlock: blocks.some(b => b.type === 'code'),
    };
  }

  findBestJsonBlock(blocks: ExtractedBlock[]): ExtractedBlock | null {
    // Strategy: find the highest-confidence JSON block
    const jsonBlocks = blocks.filter(b => b.type === 'json');
    if (jsonBlocks.length === 0) return null;

    // Sort by confidence, then by content length (longer = more likely complete)
    jsonBlocks.sort((a, b) => {
      if (b.confidence !== a.confidence) return b.confidence - a.confidence;
      return b.content.length - a.content.length;
    });

    return jsonBlocks[0];
  }

  private detectBlockType(content: string, language?: string): ExtractedBlock['type'] {
    if (language === 'json') return 'json';
    const trimmed = content.trim();
    if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
      // Check if it's actually valid JSON
      try {
        JSON.parse(trimmed);
        return 'json';
      } catch {
        // Might still be JSON with minor issues
        if (trimmed.includes('":') || trimmed.includes('": ')) return 'json';
      }
    }
    return 'code';
  }
}
'''

llm_repair_pipeline = r'''/* ============================================================
   LLM I/O Harness — Repair Pipeline
   Multi-stage pipeline: Syntax Repair -> Key Mapping ->
   Type Coercion -> Semantic Validation. Handles ~90% of
   common LLM output malformations.
   ============================================================ */

import { z } from 'zod';

// Inline JSON repair - avoids external dependency
function tryJsonRepair(content: string): string {
  // Stage 1: Remove markdown code fences
  let repaired = content.replace(/^```(?:json)?\s*\n?/gm, '').replace(/\n?```\s*$/gm, '');

  // Stage 2: Fix trailing commas before } or ]
  repaired = repaired.replace(/,\s*([}\]])/g, '$1');

  // Stage 3: Fix single quotes to double quotes (naive but covers most cases)
  repaired = repaired.replace(/'/g, '"');

  // Stage 4: Fix unquoted keys: { key: -> { "key":
  repaired = repaired.replace(/([{,]\s*)([a-zA-Z_$][a-zA-Z0-9_$]*)\s*:/g, '$1"$2":');

  // Stage 5: Fix Python/other-language literals
  repaired = repaired.replace(/\bTrue\b/g, 'true');
  repaired = repaired.replace(/\bFalse\b/g, 'false');
  repaired = repaired.replace(/\bNone\b/g, 'null');
  repaired = repaired.replace(/\bUndefined\b/g, 'null');

  // Stage 6: Fix multiline strings (remove actual newlines inside strings)
  repaired = repaired.replace(/"([^"\\]*)\n([^"\\]*)"/g, '"$1 $2"');

  // Stage 7: Remove comments (// and /* */)
  repaired = repaired.replace(/\/\/.*$/gm, '');
  repaired = repaired.replace(/\/\*[\s\S]*?\*\//g, '');

  // Stage 8: Add missing quotes around string values after colons
  repaired = repaired.replace(/:\s*([a-zA-Z][a-zA-Z0-9_@.\-]*)(?=\s*[,}])/g, ': "$1"');

  return repaired;
}

export interface ExtractedBlock {
  type: 'text' | 'code' | 'json' | 'table' | 'list' | 'markdown';
  content: string;
  language?: string;
  confidence: number;
  metadata?: Record<string, unknown>;
}

export interface RepairResult<T> {
  success: boolean;
  data?: T;
  errors: RepairError[];
  attempts: number;
  originalContent: string;
  repairedContent?: string;
  repairLog: string[];
}

export interface RepairError {
  stage: 'syntax' | 'coercion' | 'semantic' | 'extraction';
  message: string;
  path?: string;
  received?: unknown;
  expected?: string;
}

interface RepairOptions {
  maxAttempts?: number;
  enableKeyMapping?: boolean;
  enableTypeCoercion?: boolean;
  enableDeepScan?: boolean;
}

export class RepairPipeline<T> {
  private aliasMap: Map<string, string> = new Map();

  constructor(
    private schema: z.ZodType<T>,
    private options: RepairOptions = {}
  ) {
    // Pre-build alias map from schema for fast key resolution
    if (this.options.enableKeyMapping) {
      this.buildAliasMap(schema);
    }
  }

  async repair(block: ExtractedBlock): Promise<RepairResult<T>> {
    const maxAttempts = this.options.maxAttempts ?? 3;
    const errors: RepairError[] = [];
    const repairLog: string[] = [];
    let currentContent = block.content;

    repairLog.push(`Starting repair pipeline for block type: ${block.type}, confidence: ${block.confidence}`);

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      repairLog.push(`--- Attempt ${attempt}/${maxAttempts} ---`);

      // Stage 1: Syntax Repair
      const syntaxResult = this.repairSyntax(currentContent);
      if (!syntaxResult.success) {
        errors.push(syntaxResult.error!);
        repairLog.push(`[SYNTAX] Failed: ${syntaxResult.error!.message}`);
        continue;
      }
      currentContent = syntaxResult.repaired!;
      repairLog.push(`[SYNTAX] Repaired successfully`);

      // Stage 2: Parse JSON
      let parsed: unknown;
      try {
        parsed = JSON.parse(currentContent);
        repairLog.push(`[PARSE] JSON parsed successfully`);
      } catch (e) {
        errors.push({
          stage: 'syntax',
          message: `JSON parse failed after repair: ${(e as Error).message}`,
          received: currentContent.substring(0, 200),
        });
        repairLog.push(`[PARSE] Failed: ${(e as Error).message}`);
        continue;
      }

      // Stage 3: Key Mapping & Normalization
      if (this.options.enableKeyMapping && typeof parsed === 'object' && parsed !== null) {
        const before = JSON.stringify(parsed);
        parsed = this.normalizeKeys(parsed);
        const after = JSON.stringify(parsed);
        if (before !== after) {
          repairLog.push(`[KEYS] Normalized keys (changes detected)`);
        } else {
          repairLog.push(`[KEYS] No key normalization needed`);
        }
      }

      // Stage 4: Deep scan for nested JSON strings
      if (this.options.enableDeepScan) {
        parsed = this.deepScanForJson(parsed);
        repairLog.push(`[DEEP] Deep scan complete`);
      }

      // Stage 5: Schema-Aware Coercion
      const coercionResult = await this.coerceToSchema(parsed);
      if (coercionResult.success) {
        repairLog.push(`[COERCE] Schema validation passed`);
        return {
          success: true,
          data: coercionResult.data,
          errors: [],
          attempts: attempt,
          originalContent: block.content,
          repairedContent: currentContent,
          repairLog,
        };
      }

      repairLog.push(`[COERCE] Failed with ${coercionResult.errors.length} error(s)`);
      errors.push(...coercionResult.errors);

      // Stage 6: Manual coercion attempt
      const manualResult = this.attemptManualCoercion(parsed, coercionResult.errors);
      if (manualResult) {
        const retryResult = await this.schema.safeParseAsync(manualResult);
        if (retryResult.success) {
          repairLog.push(`[MANUAL] Manual coercion succeeded`);
          return {
            success: true,
            data: retryResult.data,
            errors: [],
            attempts: attempt,
            originalContent: block.content,
            repairedContent: JSON.stringify(manualResult, null, 2),
            repairLog,
          };
        }
        repairLog.push(`[MANUAL] Manual coercion failed`);
      }
    }

    return {
      success: false,
      errors,
      attempts: maxAttempts,
      originalContent: block.content,
      repairedContent: currentContent,
      repairLog,
    };
  }

  private repairSyntax(content: string): { success: boolean; repaired?: string; error?: RepairError } {
    // First, try parsing as-is
    try {
      JSON.parse(content);
      return { success: true, repaired: content };
    } catch {
      // Proceed with repair
    }

    // Try our built-in repair
    const repaired = tryJsonRepair(content);
    try {
      JSON.parse(repaired);
      return { success: true, repaired };
    } catch {
      // Continue to more aggressive repairs
    }

    // Aggressive: try to extract JSON from surrounding text
    const jsonMatch = content.match(/[\[{][\s\S]*[\]}]/);
    if (jsonMatch) {
      const extracted = tryJsonRepair(jsonMatch[0]);
      try {
        JSON.parse(extracted);
        return { success: true, repaired: extracted };
      } catch {
        // Give up
      }
    }

    return {
      success: false,
      error: {
        stage: 'syntax',
        message: 'All syntax repair strategies failed',
        received: content.substring(0, 300),
      },
    };
  }

  private normalizeKeys(data: unknown): unknown {
    if (typeof data !== 'object' || data === null) return data;
    if (Array.isArray(data)) {
      return data.map(item => this.normalizeKeys(item));
    }

    const normalized: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(data as Record<string, unknown>)) {
      const canonicalKey = this.aliasMap.get(key) || key;
      normalized[canonicalKey] = this.normalizeKeys(value);
    }

    return normalized;
  }

  private buildAliasMap(schema: z.ZodType, prefix: string = ''): void {
    const def = (schema as any)._def;
    if (!def) return;

    if (def.shape) {
      for (const [key, fieldSchema] of Object.entries(def.shape)) {
        const fullKey = prefix ? `${prefix}.${key}` : key;
        const fieldDef = (fieldSchema as any);
        const repair = fieldDef._def?._repair || fieldDef._repair;

        if (repair?.aliases) {
          for (const alias of repair.aliases) {
            this.aliasMap.set(alias, key);
            this.aliasMap.set(`${prefix ? prefix + '.' : ''}${alias}`, fullKey);
          }
        }

        // Recurse into nested objects
        this.buildAliasMap(fieldSchema as z.ZodType, fullKey);
      }
    }
  }

  private deepScanForJson(data: unknown): unknown {
    if (typeof data === 'string') {
      // Check if string contains JSON
      const trimmed = data.trim();
      if ((trimmed.startsWith('{') || trimmed.startsWith('[')) && trimmed.length > 2) {
        try {
          return JSON.parse(trimmed);
        } catch {
          // Try repair
          const repaired = tryJsonRepair(trimmed);
          try {
            return JSON.parse(repaired);
          } catch {
            // Leave as string
          }
        }
      }
      return data;
    }

    if (typeof data === 'object' && data !== null) {
      if (Array.isArray(data)) {
        return data.map(item => this.deepScanForJson(item));
      }
      const result: Record<string, unknown> = {};
      for (const [key, value] of Object.entries(data as Record<string, unknown>)) {
        result[key] = this.deepScanForJson(value);
      }
      return result;
    }

    return data;
  }

  private async coerceToSchema(data: unknown): Promise<{ success: boolean; data?: T; errors: RepairError[] }> {
    const errors: RepairError[] = [];

    try {
      const result = await this.schema.safeParseAsync(data);

      if (result.success) {
        return { success: true, data: result.data };
      }

      for (const issue of result.error.issues) {
        errors.push({
          stage: 'coercion',
          message: issue.message,
          path: issue.path.join('.'),
          received: this.getNestedValue(data, issue.path),
          expected: issue.code,
        });
      }

      return { success: false, errors };
    } catch (e) {
      errors.push({
        stage: 'coercion',
        message: `Unexpected error: ${(e as Error).message}`,
      });
      return { success: false, errors };
    }
  }

  private attemptManualCoercion(data: unknown, errors: RepairError[]): unknown | null {
    if (typeof data !== 'object' || data === null) return null;

    const clone = JSON.parse(JSON.stringify(data));

    for (const error of errors) {
      if (!error.path) continue;
      const parts = error.path.split('.');
      let target: any = clone;
      for (const part of parts) {
        if (target && typeof target === 'object' && part in target) {
          target = target[part];
        } else {
          target = undefined;
          break;
        }
      }

      if (target === undefined) continue;

      // String "true"/"false" -> boolean
      if (typeof target === 'string' && (target.toLowerCase() === 'true' || target.toLowerCase() === 'false')) {
        this.setNestedValue(clone, parts, target.toLowerCase() === 'true');
        continue;
      }

      // String number -> number
      if (typeof target === 'string' && /^\d+(\.\d+)?$/.test(target)) {
        this.setNestedValue(clone, parts, Number(target));
        continue;
      }

      // Number 0/1 -> boolean
      if (typeof target === 'number' && (target === 0 || target === 1) && error.expected === 'invalid_type') {
        this.setNestedValue(clone, parts, target === 1);
        continue;
      }

      // String "null" -> null
      if (typeof target === 'string' && target.toLowerCase() === 'null') {
        this.setNestedValue(clone, parts, null);
        continue;
      }
    }

    return clone;
  }

  private getNestedValue(data: unknown, path: (string | number)[]): unknown {
    let current: any = data;
    for (const key of path) {
      if (current && typeof current === 'object' && key in current) {
        current = current[key];
      } else {
        return undefined;
      }
    }
    return current;
  }

  private setNestedValue(obj: any, path: string[], value: unknown): void {
    let current = obj;
    for (let i = 0; i < path.length - 1; i++) {
      if (current[path[i]] === undefined) current[path[i]] = {};
      current = current[path[i]];
    }
    current[path[path.length - 1]] = value;
  }
}
'''

llm_feedback = r'''/* ============================================================
   LLM I/O Harness — Feedback Engine
   Generates contextual repair prompts for retry loops.
   ============================================================ */

import { RepairResult, RepairError } from '../repair/pipeline';
import type { z } from 'zod';

export interface FeedbackOptions {
  maxRetries?: number;
  includeSchemaDescription?: boolean;
  tone?: 'precise' | 'conversational' | 'minimal';
}

export class FeedbackEngine {
  private schemaDescription: string = '';

  constructor(private options: FeedbackOptions = {}) {}

  setSchemaDescription(description: string): void {
    this.schemaDescription = description;
  }

  setSchemaFromZod<T>(schema: z.ZodType<T>): void {
    // Generate a human-readable description from the Zod schema
    this.schemaDescription = this.zodToDescription(schema);
  }

  generateRepairPrompt(
    originalPrompt: string,
    result: RepairResult<unknown>
  ): string {
    const tone = this.options.tone ?? 'precise';
    const errorSummary = this.formatErrors(result.errors, tone);

    if (tone === 'minimal') {
      return `${originalPrompt}\n\n[Previous output had errors. Fix and respond with ONLY valid JSON.]\nErrors: ${errorSummary}`;
    }

    const schemaSection = this.options.includeSchemaDescription !== false && this.schemaDescription
      ? `\n\nExpected schema:\n\`\`\`json\n${this.schemaDescription}\n\`\`\``
      : '';

    return [
      `I need you to fix the JSON output from your previous response.`,
      ``,
      `Original request: ${originalPrompt}`,
      ``,
      `Your previous response had these issues:`,
      errorSummary,
      ``,
      `Please provide a corrected JSON response that:`,
      `1. Is valid JSON syntax`,
      `2. Uses the correct field names`,
      `3. Has the correct data types`,
      `4. Includes all required fields`,
      schemaSection,
      ``,
      `Respond ONLY with the corrected JSON, no explanation.`,
    ].join('\n');
  }

  generateExtractionPrompt(
    textToExtract: string,
    schemaHint: string
  ): string {
    return [
      `Extract structured data from the following text and respond with JSON.`,
      ``,
      `Text to analyze:`,
      textToExtract,
      ``,
      `Expected output format:`,
      schemaHint,
      ``,
      `Respond ONLY with valid JSON. No explanation, no markdown code fences.`,
    ].join('\n');
  }

  private formatErrors(errors: RepairError[], tone: string): string {
    if (errors.length === 0) return 'No JSON block found in response.';

    return errors
      .map((e, i) => {
        const path = e.path ? ` at "${e.path}"` : '';
        const received = e.received !== undefined
          ? ` (received: ${JSON.stringify(e.received).substring(0, 50)})`
          : '';
        return `${i + 1}. [${e.stage.toUpperCase()}]${path}: ${e.message}${received}`;
      })
      .join('\n');
  }

  private zodToDescription<T>(schema: z.ZodType<T>, indent: number = 0): string {
    const def = (schema as any)._def;
    const pad = '  '.repeat(indent);
    const typeMap: Record<string, string> = {
      ZodString: 'string',
      ZodNumber: 'number',
      ZodBoolean: 'boolean',
      ZodArray: 'array',
      ZodObject: 'object',
      ZodEnum: 'enum',
      ZodOptional: 'optional',
      ZodDefault: 'with default',
    };

    const typeName = def?.typeName || 'unknown';
    const friendlyType = typeMap[typeName] || typeName;

    if (typeName === 'ZodObject' && def.shape) {
      const fields = Object.entries(def.shape)
        .map(([key, fieldSchema]) => {
          const fieldDef = (fieldSchema as any)._def;
          const fieldType = typeMap[fieldDef?.typeName] || 'any';
          const isOptional = fieldDef?.typeName === 'ZodOptional';
          const repair = (fieldSchema as any)._repair || fieldDef?._repair;
          const aliasInfo = repair?.aliases?.length
            ? ` (aliases: ${repair.aliases.join(', ')})`
            : '';
          return `${pad}  "${key}": ${fieldType}${isOptional ? ' (optional)' : ''}${aliasInfo}`;
        })
        .join('\n');
      return `{\n${fields}\n${pad}}`;
    }

    if (typeName === 'ZodArray' && def.type) {
      return `${this.zodToDescription(def.type, indent)}[]`;
    }

    if (typeName === 'ZodEnum' && def.values) {
      return `(${def.values.join(' | ')})`;
    }

    if (typeName === 'ZodDefault' && def.innerType) {
      return `${this.zodToDescription(def.innerType, indent)} (default: ${JSON.stringify(def.defaultValue())})`;
    }

    if (typeName === 'ZodOptional' && def.innerType) {
      return `${this.zodToDescription(def.innerType, indent)}?`;
    }

    return friendlyType;
  }

  shouldRetry(result: RepairResult<unknown>, attempt: number): boolean {
    const maxRetries = this.options.maxRetries ?? 3;
    if (attempt >= maxRetries) return false;

    // Don't retry if all errors are semantic (unlikely to fix with retry)
    const allSemantic = result.errors.length > 0 && result.errors.every(e => e.stage === 'semantic');
    if (allSemantic && attempt >= 1) return false;

    return true;
  }
}
'''

llm_orchestrator = r'''/* ============================================================
   LLM I/O Harness — Orchestrator
   Coordinates WebApp Driver, Extractor, Repair Pipeline, and
   Feedback Engine into a unified query interface.
   ============================================================ */

import type { z } from 'zod';
import { WebAppDriver, WebAppConfig } from './driver/webapp-driver';
import { ResponseExtractor, ExtractedBlock } from './extraction/extractor';
import { RepairPipeline, RepairResult } from './repair/pipeline';
import { FeedbackEngine } from './feedback/engine';

export interface HarnessConfig {
  driver: WebAppConfig;
  maxRetries?: number;
  enableKeyMapping?: boolean;
  enableTypeCoercion?: boolean;
  enableDeepScan?: boolean;
  feedbackTone?: 'precise' | 'conversational' | 'minimal';
}

export interface QueryResult<T> {
  success: boolean;
  data?: T;
  errors: string[];
  metadata: {
    attempts: number;
    repairStages: string[];
    repairLog: string[];
    extractionConfidence: number;
    durationMs: number;
  };
}

export class LLMHarness<T> {
  private driver: WebAppDriver;
  private extractor: ResponseExtractor;
  private repairPipeline: RepairPipeline<T>;
  private feedbackEngine: FeedbackEngine;
  private maxRetries: number;

  constructor(
    private schema: z.ZodType<T>,
    config: HarnessConfig
  ) {
    this.driver = new WebAppDriver(config.driver);
    this.extractor = new ResponseExtractor();
    this.repairPipeline = new RepairPipeline(schema, {
      maxAttempts: 3,
      enableKeyMapping: config.enableKeyMapping ?? true,
      enableTypeCoercion: config.enableTypeCoercion ?? true,
      enableDeepScan: config.enableDeepScan ?? false,
    });
    this.feedbackEngine = new FeedbackEngine({
      maxRetries: config.maxRetries ?? 3,
      tone: config.feedbackTone ?? 'precise',
    });
    this.feedbackEngine.setSchemaFromZod(schema);
    this.maxRetries = config.maxRetries ?? 3;
  }

  async query(prompt: string): Promise<QueryResult<T>> {
    const startTime = Date.now();
    await this.driver.init();

    try {
      let currentPrompt = prompt;
      let lastResult: RepairResult<T> | null = null;
      const repairLog: string[] = [];

      for (let round = 0; round < this.maxRetries; round++) {
        // 1. Send prompt to WebApp
        const rawResponse = await this.driver.sendPrompt(currentPrompt);
        repairLog.push(`[Round ${round + 1}] Received ${rawResponse.length} chars of HTML`);

        // 2. Extract blocks from response
        const extraction = this.extractor.extract(rawResponse);
        repairLog.push(`[Round ${round + 1}] Extracted ${extraction.blocks.length} blocks`);

        // 3. Find best JSON block
        const jsonBlock = this.extractor.findBestJsonBlock(extraction.blocks);

        if (!jsonBlock) {
          repairLog.push(`[Round ${round + 1}] No JSON block found, generating feedback`);
          currentPrompt = this.feedbackEngine.generateRepairPrompt(
            prompt,
            {
              success: false,
              errors: [{ stage: 'extraction', message: 'No JSON block found in response' }],
              attempts: round + 1,
              originalContent: rawResponse.substring(0, 500),
              repairLog: [],
            }
          );
          continue;
        }

        repairLog.push(`[Round ${round + 1}] Best JSON block: confidence=${jsonBlock.confidence}, length=${jsonBlock.content.length}`);

        // 4. Attempt repair
        lastResult = await this.repairPipeline.repair(jsonBlock);
        repairLog.push(...lastResult.repairLog.map(l => `[Round ${round + 1}] ${l}`));

        if (lastResult.success) {
          return {
            success: true,
            data: lastResult.data,
            errors: [],
            metadata: {
              attempts: round + 1,
              repairStages: ['extraction', 'syntax', 'coercion'],
              repairLog,
              extractionConfidence: jsonBlock.confidence,
              durationMs: Date.now() - startTime,
            },
          };
        }

        // 5. Check if we should retry
        if (!this.feedbackEngine.shouldRetry(lastResult, round + 1)) {
          break;
        }

        // 6. Generate feedback for next attempt
        currentPrompt = this.feedbackEngine.generateRepairPrompt(prompt, lastResult);
      }

      return {
        success: false,
        errors: lastResult?.errors.map(e => `[${e.stage}] ${e.message}`) || ['Max retries exceeded'],
        metadata: {
          attempts: this.maxRetries,
          repairStages: ['extraction', 'syntax', 'coercion', 'semantic'],
          repairLog,
          extractionConfidence: 0,
          durationMs: Date.now() - startTime,
        },
      };
    } finally {
      await this.driver.cleanup();
    }
  }

  async queryWithExtractionPrompt(textToExtract: string, schemaHint: string): Promise<QueryResult<T>> {
    const prompt = this.feedbackEngine.generateExtractionPrompt(textToExtract, schemaHint);
    return this.query(prompt);
  }
}
'''

llm_example_usage = r'''/* ============================================================
   LLM I/O Harness — Example Usage
   Demonstrates the complete workflow for extracting structured
   data from LLM WebApp responses.
   ============================================================ */

import { LLMHarness } from './orchestrator';
import { UserExtractionContract, AnalysisContract } from './schema/contracts';

// -- Example 1: User Extraction --

async function extractUser() {
  const harness = new LLMHarness(UserExtractionContract, {
    driver: {
      url: 'https://chat.openai.com',
      inputSelector: 'textarea[data-id="root"]',
      submitSelector: 'button[data-testid="send-button"]',
      outputSelector: '[data-testid="conversation-turn-2"]',
      loadTimeout: 45000,
      headless: false,
    },
    maxRetries: 3,
    enableKeyMapping: true,
    enableTypeCoercion: true,
  });

  const prompt = `Extract user information from the following text and respond with JSON:
"John Doe (john@example.com) is an active admin user with ID 12345."

Expected JSON format:
{
  "user": {
    "id": number,
    "name": string,
    "email": string,
    "role": "admin" | "user" | "guest",
    "isActive": boolean
  },
  "metadata": {
    "extractedAt": "ISO datetime",
    "confidence": number (0-1),
    "source": string
  }
}`;

  const result = await harness.query(prompt);

  if (result.success) {
    console.log('Successfully extracted user:');
    console.log(JSON.stringify(result.data, null, 2));
  } else {
    console.log(`Failed after ${result.metadata.attempts} attempts`);
    console.log('Errors:', result.errors);
    console.log('Repair log:', result.metadata.repairLog);
  }
}

// -- Example 2: Analysis Result --

async function analyzeContent() {
  const harness = new LLMHarness(AnalysisContract, {
    driver: {
      url: 'https://claude.ai',
      inputSelector: 'div[contenteditable="true"]',
      submitSelector: 'button[aria-label="Send"]',
      outputSelector: '[data-testid="assistant-message"]',
      loadTimeout: 60000,
    },
    maxRetries: 2,
    feedbackTone: 'conversational',
  });

  const textToAnalyze = `The project deadline is at high risk. The database migration
failed twice last week. Team morale is medium but improving.
Three critical bugs remain in the authentication module.`;

  const result = await harness.queryWithExtractionPrompt(
    textToAnalyze,
    `{
  "title": "string",
  "summary": "string",
  "score": "number (0-100)",
  "tags": ["string"],
  "items": [{ "id": "number", "content": "string", "priority": "high|medium|low" }],
  "metadata": { "extractedAt": "ISO datetime", "confidence": "number (0-1)", "source": "string" }
}`
  );

  if (result.success) {
    console.log('Analysis complete:');
    console.log(JSON.stringify(result.data, null, 2));
    console.log(`Duration: ${result.metadata.durationMs}ms`);
    console.log(`Confidence: ${result.metadata.extractionConfidence}`);
  }
}

// -- Run examples --

// Uncomment to run:
// extractUser().catch(console.error);
// analyzeContent().catch(console.error);
'''

llm_tests = r'''/* ============================================================
   LLM I/O Harness — Repair Pipeline Tests
   Comprehensive tests for the multi-stage repair pipeline.
   ============================================================ */

import { RepairPipeline, ExtractedBlock } from '../repair/pipeline';
import { z } from 'zod';

describe('RepairPipeline', () => {
  const schema = z.object({
    name: z.string(),
    age: z.coerce.number(),
    isActive: z.coerce.boolean().default(true),
  });

  const createPipeline = (opts = {}) =>
    new RepairPipeline(schema, { enableKeyMapping: true, enableTypeCoercion: true, ...opts });

  it('should handle valid JSON without modification', async () => {
    const pipeline = createPipeline();
    const result = await pipeline.repair({
      type: 'json',
      content: '{"name": "John", "age": 30}',
      confidence: 1.0,
    });
    expect(result.success).toBe(true);
    expect(result.data?.name).toBe('John');
    expect(result.data?.age).toBe(30);
    expect(result.attempts).toBe(1);
  });

  it('should repair trailing commas', async () => {
    const pipeline = createPipeline();
    const result = await pipeline.repair({
      type: 'json',
      content: '{"name": "John", "age": 30,}',
      confidence: 0.9,
    });
    expect(result.success).toBe(true);
    expect(result.data?.name).toBe('John');
  });

  it('should coerce string numbers to actual numbers', async () => {
    const pipeline = createPipeline();
    const result = await pipeline.repair({
      type: 'json',
      content: '{"name": "John", "age": "30"}',
      confidence: 0.9,
    });
    expect(result.success).toBe(true);
    expect(result.data?.age).toBe(30);
    expect(typeof result.data?.age).toBe('number');
  });

  it('should strip markdown code fences', async () => {
    const pipeline = createPipeline();
    const result = await pipeline.repair({
      type: 'json',
      content: '```json\n{"name": "John", "age": 30}\n```',
      confidence: 0.9,
    });
    expect(result.success).toBe(true);
  });

  it('should fix Python-style booleans', async () => {
    const pipeline = createPipeline();
    const result = await pipeline.repair({
      type: 'json',
      content: '{"name": "Jane", "age": 25, "isActive": True}',
      confidence: 0.8,
    });
    expect(result.success).toBe(true);
    expect(result.data?.isActive).toBe(true);
  });

  it('should fix None to null', async () => {
    const pipeline = createPipeline();
    const result = await pipeline.repair({
      type: 'json',
      content: '{"name": "Bob", "age": null, "isActive": None}',
      confidence: 0.8,
    });
    expect(result.success).toBe(true);
  });

  it('should fix single quotes to double quotes', async () => {
    const pipeline = createPipeline();
    const result = await pipeline.repair({
      type: 'json',
      content: "{'name': 'Alice', 'age': 28}",
      confidence: 0.7,
    });
    expect(result.success).toBe(true);
    expect(result.data?.name).toBe('Alice');
  });

  it('should fix unquoted keys', async () => {
    const pipeline = createPipeline();
    const result = await pipeline.repair({
      type: 'json',
      content: '{name: "Charlie", age: 35}',
      confidence: 0.7,
    });
    expect(result.success).toBe(true);
  });

  it('should handle boolean coercion from strings', async () => {
    const pipeline = createPipeline();
    const result = await pipeline.repair({
      type: 'json',
      content: '{"name": "Dave", "age": 40, "isActive": "true"}',
      confidence: 0.8,
    });
    expect(result.success).toBe(true);
    expect(result.data?.isActive).toBe(true);
  });

  it('should handle boolean coercion from 0/1', async () => {
    const pipeline = createPipeline();
    const result = await pipeline.repair({
      type: 'json',
      content: '{"name": "Eve", "age": 30, "isActive": 1}',
      confidence: 0.8,
    });
    expect(result.success).toBe(true);
    expect(result.data?.isActive).toBe(true);
  });

  it('should apply default values for missing fields', async () => {
    const pipeline = createPipeline();
    const result = await pipeline.repair({
      type: 'json',
      content: '{"name": "Frank", "age": 45}',
      confidence: 0.9,
    });
    expect(result.success).toBe(true);
    expect(result.data?.isActive).toBe(true); // default value
  });

  it('should return detailed error information on failure', async () => {
    const pipeline = createPipeline({ maxAttempts: 1 });
    const result = await pipeline.repair({
      type: 'json',
      content: 'completely not json at all',
      confidence: 0.3,
    });
    expect(result.success).toBe(false);
    expect(result.errors.length).toBeGreaterThan(0);
    expect(result.repairLog.length).toBeGreaterThan(0);
  });

  it('should include repair log in result', async () => {
    const pipeline = createPipeline();
    const result = await pipeline.repair({
      type: 'json',
      content: '{"name": "Grace", "age": 30}',
      confidence: 0.9,
    });
    expect(result.repairLog.length).toBeGreaterThan(0);
    expect(result.originalContent).toBe('{"name": "Grace", "age": 30}');
    expect(result.repairedContent).toBeDefined();
  });

  it('should handle deeply nested objects', async () => {
    const nestedSchema = z.object({
      user: z.object({
        name: z.string(),
        address: z.object({
          city: z.string(),
          zip: z.coerce.number(),
        }),
      }),
    });

    const pipeline = new RepairPipeline(nestedSchema, { enableKeyMapping: true });
    const result = await pipeline.repair({
      type: 'json',
      content: '{"user": {"name": "Henry", "address": {"city": "NYC", "zip": "10001"}}}',
      confidence: 0.9,
    });
    expect(result.success).toBe(true);
    expect((result.data as any)?.user?.address?.zip).toBe(10001);
  });
});
'''

# ── Package.json files ────────────────────────────────────────────────────

root_package_json = json.dumps({
    "name": "canvas-sdk-project",
    "version": "2.0.0",
    "private": True,
    "description": "Canvas SDK + LLM I/O Harness - SOTA dual-SDK architecture with schema-aware LLM response repair",
    "workspaces": [
        "packages/core",
        "packages/plugin-sdk",
        "plugins",
        "llm-harness"
    ],
    "scripts": {
        "build": "tsc --build",
        "test": "vitest run",
        "test:watch": "vitest",
        "lint": "eslint 'packages/*/src/**/*.ts' 'plugins/src/**/*.ts' 'llm-harness/src/**/*.ts'",
        "playground": "tsx app/main.ts"
    },
    "devDependencies": {
        "typescript": "^5.6.0",
        "vitest": "^2.1.0",
        "eslint": "^9.12.0",
        "@types/node": "^22.5.0",
        "tsx": "^4.19.0"
    }
}, indent=2)

core_package_json = json.dumps({
    "name": "@canvas-sdk/core",
    "version": "2.0.0",
    "description": "Headless canvas engine - scene graph, command stack, event bus, viewport transforms",
    "main": "src/index.ts",
    "types": "src/index.ts",
    "license": "MIT",
    "peerDependencies": {}
}, indent=2)

plugin_sdk_package_json = json.dumps({
    "name": "@canvas-sdk/plugin-sdk",
    "version": "2.0.0",
    "description": "Consumer-facing plugin API for tools, renderers, and commands",
    "main": "src/index.ts",
    "types": "src/index.ts",
    "license": "MIT",
    "dependencies": {
        "@canvas-sdk/core": "workspace:*"
    }
}, indent=2)

plugins_package_json = json.dumps({
    "name": "@canvas-sdk/plugins",
    "version": "2.0.0",
    "description": "Built-in tools and renderers for the Canvas SDK",
    "main": "src/index.ts",
    "license": "MIT",
    "dependencies": {
        "@canvas-sdk/core": "workspace:*",
        "@canvas-sdk/plugin-sdk": "workspace:*",
        "uuid": "^10.0.0"
    }
}, indent=2)

llm_harness_package_json = json.dumps({
    "name": "@canvas-sdk/llm-harness",
    "version": "1.0.0",
    "description": "Schema-aware LLM I/O harness for extracting structured data from WebApp responses",
    "main": "src/index.ts",
    "license": "MIT",
    "dependencies": {
        "zod": "^3.23.0",
        "cheerio": "^1.0.0",
        "playwright": "^1.48.0"
    },
    "devDependencies": {
        "vitest": "^2.1.0"
    }
}, indent=2)

tsconfig_json = json.dumps({
    "compilerOptions": {
        "target": "ES2022",
        "module": "ESNext",
        "moduleResolution": "bundler",
        "declaration": True,
        "declarationMap": True,
        "sourceMap": True,
        "outDir": "./dist",
        "strict": True,
        "noUnusedLocals": True,
        "noUnusedParameters": True,
        "noFallthroughCasesInSwitch": True,
        "resolveJsonModule": True,
        "isolatedModules": True,
        "esModuleInterop": True,
        "skipLibCheck": True,
        "forceConsistentCasingInFileNames": True,
        "composite": True
    },
    "references": [
        { "path": "packages/core" },
        { "path": "packages/plugin-sdk" },
        { "path": "plugins" },
        { "path": "llm-harness" }
    ]
}, indent=2)

tsconfig_base_json = json.dumps({
    "extends": "../tsconfig.json",
    "compilerOptions": {
        "composite": True,
        "outDir": "./dist"
    },
    "include": ["src"]
}, indent=2)

readme_content = """# Canvas SDK + LLM I/O Harness

**Version 2.0.0** - SOTA dual-SDK architecture with schema-aware LLM response repair.

## Architecture

```
canvas-sdk-project/
\u251c\u2500\u2500 packages/
\u2502   \u251c\u2500\u2500 core/          # Headless canvas engine
\u2502   \u2514\u2500\u2500 plugin-sdk/    # Consumer-facing plugin API
\u251c\u2500\u2500 plugins/           # Built-in tools & renderers
\u251c\u2500\u2500 llm-harness/       # LLM I/O with repair pipeline
\u2514\u2500\u2500 app/               # Playground consumer
```

### @canvas-sdk/core

Headless canvas engine with:
- **Scene Graph** - Node/Connection/Z-Layer management with QuadTree spatial indexing
- **Event Bus** - Typed pub/sub with wildcard and once-only listeners
- **Command Stack** - Undo/redo with capped history
- **Viewport** - Screen/world coordinate transforms, pan, zoom

### @canvas-sdk/plugin-sdk

Plugin system interfaces:
- **Tools** - activate/deactivate lifecycle, mouse/keyboard handlers
- **Node Renderers** - Type-based dispatch for custom rendering
- **Commands** - Mutation wrappers for undo/redo
- **Plugins** - install(api) pattern for bundling tools + renderers

### @canvas-sdk/plugins

Built-in tools: Select, Rectangle, Ellipse, Line, Text, Freehand, Pan, Connection
Built-in renderers: Rectangle, Ellipse, Line, Text, Freehand

### @canvas-sdk/llm-harness

Schema-aware LLM I/O harness:
- **Schema Stack** - Zod with repair extensions (aliases, coercion, defaults)
- **WebApp Driver** - Playwright-based browser automation
- **DOM Extractor** - HTML to structured blocks (code, JSON, table, list)
- **Repair Pipeline** - Syntax repair, Key mapping, Type coercion, Semantic validation
- **Feedback Engine** - Contextual error prompts for retry loops
- **Orchestrator** - Unified LLMHarness<T> query interface

## Quick Start

```bash
npm install
npm run build
npm run playground
```

## Testing

```bash
npm test
```

## License

MIT
"""

plugin_sdk_index = """/* ============================================================
   @canvas-sdk/plugin-sdk - Barrel Export
   ============================================================ */

export type { ToolContext, BaseTool, NodeRenderer, CommandFactory, Plugin, PluginAPI } from './interfaces';
"""

# ── Build the file map for the zip ────────────────────────────────────────

files = {}

# Root files
files["package.json"] = root_package_json
files["tsconfig.json"] = tsconfig_json
files["README.md"] = readme_content

# packages/core
files["packages/core/package.json"] = core_package_json
files["packages/core/tsconfig.json"] = tsconfig_base_json
files["packages/core/src/types.ts"] = core_types
files["packages/core/src/event-bus.ts"] = core_event_bus
files["packages/core/src/command-stack.ts"] = core_command_stack
files["packages/core/src/scene.ts"] = core_scene
files["packages/core/src/quad-tree.ts"] = core_quad_tree
files["packages/core/src/engine.ts"] = core_engine
files["packages/core/src/index.ts"] = core_index

# packages/plugin-sdk
files["packages/plugin-sdk/package.json"] = plugin_sdk_package_json
files["packages/plugin-sdk/tsconfig.json"] = tsconfig_base_json
files["packages/plugin-sdk/src/interfaces.ts"] = core_plugin_api
files["packages/plugin-sdk/src/index.ts"] = plugin_sdk_index

# plugins
files["plugins/package.json"] = plugins_package_json
files["plugins/tsconfig.json"] = tsconfig_base_json
files["plugins/src/tools/index.ts"] = tools_index
files["plugins/src/tools/select-tool.ts"] = read_file(os.path.join(SDK_BASE, "tools/select-tool.ts"))
files["plugins/src/tools/rectangle-tool.ts"] = read_file(os.path.join(SDK_BASE, "tools/rectangle-tool.ts"))
files["plugins/src/tools/ellipse-tool.ts"] = read_file(os.path.join(SDK_BASE, "tools/ellipse-tool.ts"))
files["plugins/src/tools/line-tool.ts"] = read_file(os.path.join(SDK_BASE, "tools/line-tool.ts"))
files["plugins/src/tools/text-tool.ts"] = read_file(os.path.join(SDK_BASE, "tools/text-tool.ts"))
files["plugins/src/tools/freehand-tool.ts"] = read_file(os.path.join(SDK_BASE, "tools/freehand-tool.ts"))
files["plugins/src/tools/pan-tool.ts"] = read_file(os.path.join(SDK_BASE, "tools/pan-tool.ts"))
files["plugins/src/tools/connection-tool.ts"] = read_file(os.path.join(SDK_BASE, "tools/connection-tool.ts"))
files["plugins/src/renderers/index.ts"] = renderers_index
files["plugins/src/renderers/rectangle-renderer.ts"] = read_file(os.path.join(SDK_BASE, "renderers/rectangle-renderer.ts"))
files["plugins/src/renderers/ellipse-renderer.ts"] = read_file(os.path.join(SDK_BASE, "renderers/ellipse-renderer.ts"))
files["plugins/src/renderers/line-renderer.ts"] = read_file(os.path.join(SDK_BASE, "renderers/line-renderer.ts"))
files["plugins/src/renderers/text-renderer.ts"] = read_file(os.path.join(SDK_BASE, "renderers/text-renderer.ts"))
files["plugins/src/renderers/freehand-renderer.ts"] = read_file(os.path.join(SDK_BASE, "renderers/freehand-renderer.ts"))

# llm-harness
files["llm-harness/package.json"] = llm_harness_package_json
files["llm-harness/tsconfig.json"] = tsconfig_base_json
files["llm-harness/src/schema/core.ts"] = llm_schema_core
files["llm-harness/src/schema/contracts.ts"] = llm_schema_contracts
files["llm-harness/src/schema/registry.ts"] = llm_schema_registry
files["llm-harness/src/driver/webapp-driver.ts"] = llm_driver
files["llm-harness/src/extraction/extractor.ts"] = llm_extractor
files["llm-harness/src/repair/pipeline.ts"] = llm_repair_pipeline
files["llm-harness/src/feedback/engine.ts"] = llm_feedback
files["llm-harness/src/orchestrator.ts"] = llm_orchestrator
files["llm-harness/src/example-usage.ts"] = llm_example_usage
files["llm-harness/src/tests/repair-pipeline.test.ts"] = llm_tests
files["llm-harness/src/index.ts"] = "export { LLMHarness } from './orchestrator';\nexport type { HarnessConfig, QueryResult } from './orchestrator';\nexport { SchemaRegistry } from './schema/registry';\nexport { ResponseExtractor } from './extraction/extractor';\nexport { RepairPipeline } from './repair/pipeline';\nexport type { RepairResult, RepairError, ExtractedBlock } from './repair/pipeline';\nexport { FeedbackEngine } from './feedback/engine';\nexport { WebAppDriver } from './driver/webapp-driver';\nexport type { WebAppConfig, SessionState } from './driver/webapp-driver';\nexport * from './schema/contracts';\n"

# app/playground
files["app/main.ts"] = """/* ============================================================
   Canvas SDK - Playground Consumer
   Demonstrates wiring the engine, plugins, and LLM harness.
   ============================================================ */

import { CanvasEngine, ALL_TOOLS, ALL_RENDERERS } from '../plugins/src/tools/index';
import type { ToolContext, BaseTool } from '../packages/plugin-sdk/src/interfaces';

// 1. Create engine
const engine = new CanvasEngine();

// 2. Register renderers
for (const renderer of ALL_RENDERERS) {
  engine.registerRenderer(renderer.type, renderer.render);
}

// 3. Attach to canvas
const canvas = document.getElementById('canvas') as HTMLCanvasElement;
if (canvas) {
  engine.attach(canvas);

  // 4. Setup tool context
  let selectedNodeId: string | null = null;
  let mouseWorld = { x: 0, y: 0 };
  let mouseScreen = { x: 0, y: 0 };

  const toolCtx: ToolContext = {
    engine,
    getMouseWorld: () => mouseWorld,
    getMouseScreen: () => mouseScreen,
    selectNode: (id) => {
      selectedNodeId = id;
      engine.eventBus.emit('selection:changed', { nodeId: id });
    },
    getSelectedNodeId: () => selectedNodeId,
  };

  // 5. Activate default tool
  let activeTool: BaseTool = ALL_TOOLS[0]; // Select
  activeTool.activate(toolCtx);

  // 6. Wire canvas events
  canvas.addEventListener('pointerdown', (e) => {
    const rect = canvas.getBoundingClientRect();
    mouseScreen = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    mouseWorld = engine.screenToWorld(mouseScreen.x, mouseScreen.y);
    activeTool.onMouseDown?.(e);
  });

  canvas.addEventListener('pointermove', (e) => {
    const rect = canvas.getBoundingClientRect();
    mouseScreen = { x: e.clientX - rect.left, y: e.clientY - rect.top };
    mouseWorld = engine.screenToWorld(mouseScreen.x, mouseScreen.y);
    activeTool.onMouseMove?.(e);
  });

  canvas.addEventListener('pointerup', (e) => {
    activeTool.onMouseUp?.(e);
  });

  document.addEventListener('keydown', (e) => {
    activeTool.onKeyDown?.(e);
  });

  // 7. Wheel zoom
  canvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    const rect = canvas.getBoundingClientRect();
    engine.zoomAt(e.clientX - rect.left, e.clientY - rect.top, e.deltaY);
  });

  // 8. Tool switching
  (window as any).__switchTool = (name: string) => {
    activeTool.deactivate();
    const tool = ALL_TOOLS.find(t => t.name === name);
    if (tool) {
      activeTool = tool;
      activeTool.activate(toolCtx);
      canvas.style.cursor = tool.cursor || 'default';
    }
  };
}
"""

# ── Build tree structure for the UI ───────────────────────────────────────

def build_tree(files_dict):
    """Build a nested tree structure from flat file paths."""
    tree = {}
    for path in sorted(files_dict.keys()):
        parts = path.split('/')
        current = tree
        for part in parts[:-1]:
            if part not in current:
                current[part] = {}
            current = current[part]
        current[parts[-1]] = None  # file marker
    return tree

def tree_to_html(tree, depth=0):
    """Convert tree to collapsible HTML."""
    result = ''
    for key, value in sorted(tree.items()):
        if value is None:
            # File
            ext = key.split('.')[-1] if '.' in key else ''
            icon_map = {'ts': '\U0001f537', 'json': '\U0001f4cb', 'md': '\U0001f4dd'}
            icon = icon_map.get(ext, '\U0001f4c4')
            result += f'<div class="file-item" style="padding-left: {(depth + 1) * 20 + 12}px">'
            result += f'<span class="file-icon">{icon}</span>'
            result += f'<span class="file-name">{html.escape(key)}</span>'
            result += '</div>\n'
        else:
            # Directory
            result += f'<div class="dir-item" style="padding-left: {depth * 20 + 12}px">'
            result += f'<span class="dir-arrow" onclick="toggleDir(this)">&#9654;</span>'
            result += f'<span class="dir-icon">\U0001f4c1</span>'
            result += f'<span class="dir-name">{html.escape(key)}/</span>'
            result += '</div>\n'
            result += f'<div class="dir-children">'
            result += tree_to_html(value, depth + 1)
            result += '</div>\n'
    return result

tree = build_tree(files)
tree_html = tree_to_html(tree)

# ── Count stats ────────────────────────────────────────────────────────────

total_files = len(files)
total_lines = sum(content.count('\n') + 1 for content in files.values())
total_bytes = sum(len(content.encode('utf-8')) for content in files.values())

# ── Build JavaScript file map ──────────────────────────────────────────────

def js_string(s: str) -> str:
    """Escape a string for embedding in JS template literal."""
    s = s.replace('\\', '\\\\')
    s = s.replace('`', '\\`')
    s = s.replace('${', '\\${')
    return s

file_map_parts = []
for path, content in files.items():
    file_map_parts.append(f'    "{js_string(path)}": `{js_string(content)}`')
file_map_js = '{\n' + ',\n'.join(file_map_parts) + '\n  }'

# ── Generate the HTML ─────────────────────────────────────────────────────

today = datetime.now().strftime('%Y-%m-%d')

html_doc = f'''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Canvas SDK + LLM I/O Harness - Download</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"><\/script>
<style>
  :root {{
    --bg: #0a0a0f;
    --bg-card: #12121a;
    --bg-hover: #1a1a28;
    --fg: #e8e8f0;
    --fg-dim: #8888a0;
    --accent: #7c5cff;
    --accent-glow: rgba(124, 92, 255, 0.3);
    --success: #2dd4bf;
    --border: #2a2a3a;
    --radius: 12px;
  }}
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    background: var(--bg);
    color: var(--fg);
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    min-height: 100vh;
    line-height: 1.6;
  }}
  .container {{ max-width: 960px; margin: 0 auto; padding: 60px 24px; }}
  .header {{ text-align: center; margin-bottom: 48px; }}
  .badge {{
    display: inline-block;
    background: var(--accent-glow);
    color: var(--accent);
    padding: 4px 14px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
    letter-spacing: 0.5px;
    margin-bottom: 16px;
    border: 1px solid rgba(124, 92, 255, 0.25);
  }}
  h1 {{
    font-size: 42px;
    font-weight: 800;
    letter-spacing: -1px;
    margin-bottom: 12px;
    background: linear-gradient(135deg, #e8e8f0 0%, #7c5cff 50%, #2dd4bf 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    background-clip: text;
  }}
  .subtitle {{
    color: var(--fg-dim);
    font-size: 17px;
    max-width: 620px;
    margin: 0 auto;
  }}
  .stats {{
    display: flex;
    gap: 24px;
    justify-content: center;
    margin-top: 32px;
    flex-wrap: wrap;
  }}
  .stat {{
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 16px 24px;
    text-align: center;
    min-width: 140px;
  }}
  .stat-value {{ font-size: 28px; font-weight: 800; color: var(--accent); }}
  .stat-label {{
    font-size: 12px;
    color: var(--fg-dim);
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-top: 4px;
  }}
  .card {{
    background: var(--bg-card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    margin-bottom: 24px;
    overflow: hidden;
  }}
  .card-header {{
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16px 20px;
    border-bottom: 1px solid var(--border);
  }}
  .card-title {{
    font-size: 15px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 8px;
  }}
  .download-btn {{
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: linear-gradient(135deg, #7c5cff, #5b3fd4);
    color: #fff;
    border: none;
    padding: 12px 28px;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
    text-decoration: none;
  }}
  .download-btn:hover {{
    transform: translateY(-1px);
    box-shadow: 0 8px 24px rgba(124, 92, 255, 0.4);
  }}
  .download-btn:active {{ transform: translateY(0); }}
  .download-btn.loading {{ opacity: 0.7; pointer-events: none; }}
  .download-btn .spinner {{
    display: none;
    width: 16px; height: 16px;
    border: 2px solid rgba(255,255,255,0.3);
    border-top-color: #fff;
    border-radius: 50%;
    animation: spin 0.6s linear infinite;
  }}
  .download-btn.loading .spinner {{ display: block; }}
  .download-btn.loading .btn-icon {{ display: none; }}
  @keyframes spin {{ to {{ transform: rotate(360deg); }} }}
  .file-tree {{
    padding: 12px 0;
    max-height: 500px;
    overflow-y: auto;
  }}
  .file-tree::-webkit-scrollbar {{ width: 6px; }}
  .file-tree::-webkit-scrollbar-track {{ background: transparent; }}
  .file-tree::-webkit-scrollbar-thumb {{ background: var(--border); border-radius: 3px; }}
  .file-item {{
    padding: 4px 12px;
    font-size: 13px;
    font-family: 'JetBrains Mono', 'Fira Code', 'SF Mono', monospace;
    cursor: default;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: background 0.1s;
  }}
  .file-item:hover {{ background: var(--bg-hover); }}
  .file-icon {{ font-size: 14px; width: 18px; text-align: center; }}
  .file-name {{ color: #c0c0d8; }}
  .dir-item {{
    padding: 6px 12px;
    font-size: 13px;
    font-family: 'JetBrains Mono', 'Fira Code', 'SF Mono', monospace;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 6px;
    user-select: none;
  }}
  .dir-item:hover {{ background: var(--bg-hover); }}
  .dir-arrow {{
    display: inline-block;
    font-size: 10px;
    transition: transform 0.15s;
    width: 14px;
    text-align: center;
    color: var(--fg-dim);
  }}
  .dir-arrow.open {{ transform: rotate(90deg); }}
  .dir-icon {{ font-size: 14px; }}
  .dir-name {{ color: var(--accent); }}
  .dir-children {{ overflow: hidden; }}
  .dir-children.collapsed {{ display: none; }}
  .modules {{
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 16px;
    padding: 20px;
  }}
  .module {{
    background: var(--bg);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 16px;
  }}
  .module-name {{
    font-size: 14px;
    font-weight: 700;
    color: var(--accent);
    margin-bottom: 8px;
  }}
  .module-desc {{
    font-size: 13px;
    color: var(--fg-dim);
    line-height: 1.5;
  }}
  .footer {{
    text-align: center;
    margin-top: 48px;
    padding: 24px;
    color: var(--fg-dim);
    font-size: 13px;
    border-top: 1px solid var(--border);
  }}
  .toast {{
    position: fixed;
    bottom: 24px;
    right: 24px;
    background: #1a2e1a;
    border: 1px solid #2dd4bf;
    color: #2dd4bf;
    padding: 12px 20px;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    transform: translateY(100px);
    opacity: 0;
    transition: all 0.3s;
    z-index: 1000;
  }}
  .toast.show {{ transform: translateY(0); opacity: 1; }}
  @media (max-width: 600px) {{
    .container {{ padding: 32px 16px; }}
    h1 {{ font-size: 28px; }}
    .stats {{ flex-direction: column; align-items: center; }}
    .modules {{ grid-template-columns: 1fr; }}
    .card-header {{ flex-direction: column; gap: 12px; align-items: flex-start; }}
  }}
</style>
</head>
<body>

<div class="container">
  <div class="header">
    <div class="badge">v2.0.0 &mdash; SOTA July 2026</div>
    <h1>Canvas SDK + LLM I/O Harness</h1>
    <p class="subtitle">
      Dual-SDK architecture: headless canvas engine with plugin system, plus a schema-aware
      repair pipeline for extracting structured data from LLM WebApp responses.
    </p>
    <div class="stats">
      <div class="stat">
        <div class="stat-value">{total_files}</div>
        <div class="stat-label">Files</div>
      </div>
      <div class="stat">
        <div class="stat-value">{total_lines:,}</div>
        <div class="stat-label">Lines of Code</div>
      </div>
      <div class="stat">
        <div class="stat-value">{total_bytes / 1024:.1f} KB</div>
        <div class="stat-label">Total Size</div>
      </div>
      <div class="stat">
        <div class="stat-value">5</div>
        <div class="stat-label">Packages</div>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <span class="card-title">
        <span>&#128230;</span> Download Project Archive
      </span>
      <button class="download-btn" id="downloadBtn" onclick="downloadZip()">
        <span class="spinner"></span>
        <span class="btn-icon">&#8595;</span>
        Download .zip
      </button>
    </div>
    <div class="file-tree" id="fileTree">
      {tree_html}
    </div>
  </div>

  <div class="card">
    <div class="card-header">
      <span class="card-title">
        <span>&#128640;</span> Package Modules
      </span>
    </div>
    <div class="modules">
      <div class="module">
        <div class="module-name">@canvas-sdk/core</div>
        <div class="module-desc">Headless canvas engine with scene graph, QuadTree spatial indexing, command stack (undo/redo), typed event bus, and viewport transforms (pan/zoom).</div>
      </div>
      <div class="module">
        <div class="module-name">@canvas-sdk/plugin-sdk</div>
        <div class="module-desc">Consumer-facing plugin API: tools (activate/deactivate/mouse/keyboard), node renderers (type-based dispatch), command factories, and the Plugin interface.</div>
      </div>
      <div class="module">
        <div class="module-name">@canvas-sdk/plugins</div>
        <div class="module-desc">8 built-in tools (Select, Rectangle, Ellipse, Line, Text, Freehand, Pan, Connection) and 5 renderers with smooth quadratic curves.</div>
      </div>
      <div class="module">
        <div class="module-name">@canvas-sdk/llm-harness</div>
        <div class="module-desc">Schema-aware LLM I/O: Zod repair extensions, Playwright WebApp driver, DOM extractor, multi-stage repair pipeline, feedback engine, and orchestrated query interface.</div>
      </div>
      <div class="module">
        <div class="module-name">app (Playground)</div>
        <div class="module-desc">Consumer playground wiring the engine, plugins, and LLM harness together into a working canvas application with tool switching.</div>
      </div>
    </div>
  </div>

  <div class="footer">
    Canvas SDK + LLM I/O Harness &mdash; MIT License &mdash; Generated {today}
  </div>
</div>

<div class="toast" id="toast">Download complete!</div>

<script>
// File contents map
const FILES = {file_map_js};

// Directory toggle
function toggleDir(arrow) {{
  const children = arrow.closest('.dir-item').nextElementSibling;
  if (children && children.classList.contains('dir-children')) {{
    arrow.classList.toggle('open');
    children.classList.toggle('collapsed');
  }}
}}

// Auto-expand first level directories
document.querySelectorAll('.dir-arrow').forEach(a => a.classList.add('open'));

// Download .zip via JSZip
async function downloadZip() {{
  const btn = document.getElementById('downloadBtn');
  btn.classList.add('loading');

  try {{
    const zip = new JSZip();
    const root = zip.folder('canvas-sdk-project');

    for (const [path, content] of Object.entries(FILES)) {{
      root.file(path, content);
    }}

    const blob = await zip.generateAsync({{
      type: 'blob',
      compression: 'DEFLATE',
      compressionOptions: {{ level: 6 }},
      comment: 'Canvas SDK v2.0.0 + LLM I/O Harness - Generated from download page'
    }});

    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'canvas-sdk-llm-harness.zip';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showToast('Download complete! canvas-sdk-llm-harness.zip');
  }} catch (err) {{
    console.error('Download failed:', err);
    showToast('Download failed. Check console for details.');
  }} finally {{
    btn.classList.remove('loading');
  }}
}}

function showToast(msg) {{
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}}
<\/script>
</body>
</html>'''

# ── Write the HTML file ────────────────────────────────────────────────────

os.makedirs(os.path.dirname(OUT), exist_ok=True)
with open(OUT, "w", encoding="utf-8") as f:
    f.write(html_doc)

print(f"Generated: {OUT}")
print(f"  {total_files} files, {total_lines:,} lines, {total_bytes / 1024:.1f} KB")