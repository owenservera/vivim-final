'use client';

import dynamic from 'next/dynamic';
import { useDownloadSDK } from '@/components/canvas/DownloadButton';

const CanvasPlayground = dynamic(
  () => import('@/components/canvas/CanvasPlayground'),
  { ssr: false }
);

export default function Page() {
  const { download, downloading } = useDownloadSDK();

  return (
    <>
      <CanvasPlayground />
      {/* Floating Download Button */}
      <button
        onClick={download}
        disabled={downloading}
        style={{
          position: 'fixed',
          top: 12,
          left: '50%',
          transform: 'translateX(-50%)',
          zIndex: 1000,
          padding: '8px 20px',
          borderRadius: 8,
          border: '1.5px solid var(--c-accent, #7c5cff)',
          background: 'var(--c-bg2, #0c0e16)',
          backdropFilter: 'blur(12px)',
          color: 'var(--c-accent, #7c5cff)',
          fontSize: 12,
          fontWeight: 600,
          fontFamily: "'Inter', system-ui, sans-serif",
          cursor: downloading ? 'wait' : 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          transition: 'all 0.2s ease',
          boxShadow: 'var(--c-glow, 0 0 24px rgba(124,92,255,0.35))',
          letterSpacing: '0.02em',
        }}
        onMouseEnter={e => {
          (e.currentTarget as HTMLElement).style.background = 'var(--c-accent, #7c5cff)';
          (e.currentTarget as HTMLElement).style.color = 'var(--c-accent-fg, #fff)';
        }}
        onMouseLeave={e => {
          (e.currentTarget as HTMLElement).style.background = 'var(--c-bg2, #0c0e16)';
          (e.currentTarget as HTMLElement).style.color = 'var(--c-accent, #7c5cff)';
        }}
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
          <polyline points="7 10 12 15 17 10" />
          <line x1="12" y1="15" x2="12" y2="3" />
        </svg>
        {downloading ? 'Generating...' : 'Download Canvas SDK (.zip)'}
      </button>
    </>
  );
}