'use client';

import React, { useRef, useEffect, useState, useCallback } from 'react';
import { v4 as uuid } from 'uuid';
import {
  CanvasEngine, EventBus, Scene, CommandStack,
  type Node, type Vec2, type Theme, type ZLayer, type ViewportState,
  type BaseTool, type ToolContext,
  ALL_TOOLS, ALL_RENDERERS,
} from '@/lib/canvas-sdk';
import type { Connection } from '@/lib/canvas-sdk/types';

/* ========== THEMES ========== */
const THEMES: Theme[] = [
  {
    id: 'midnight', name: 'Midnight',
    tokens: {
      bg: '#06070b', bgSecondary: '#0c0e16', bgTertiary: '#141826', bgGlass: 'rgba(20,24,38,0.72)',
      fg: '#f5f7fb', fgSecondary: '#c8cdd9', fgMuted: '#565d72',
      border: 'rgba(255,255,255,0.12)', borderLight: 'rgba(255,255,255,0.06)',
      accent: '#7c5cff', accentFg: '#ffffff', accentSoft: 'rgba(124,92,255,0.16)',
      success: '#2dd4bf', warn: '#fbbf24', danger: '#f43f5e', info: '#38bdf8',
      grid: 'rgba(124,92,255,0.06)', glow: '0 0 24px rgba(124,92,255,0.35)',
    },
  },
  {
    id: 'daylight', name: 'Daylight',
    tokens: {
      bg: '#f7f8fb', bgSecondary: '#ffffff', bgTertiary: '#eef1f6', bgGlass: 'rgba(255,255,255,0.78)',
      fg: '#0b0d14', fgSecondary: '#2a2f3d', fgMuted: '#8a92a6',
      border: 'rgba(0,0,0,0.12)', borderLight: 'rgba(0,0,0,0.06)',
      accent: '#4f46e5', accentFg: '#ffffff', accentSoft: 'rgba(79,70,229,0.1)',
      success: '#0d9488', warn: '#d97706', danger: '#dc2626', info: '#0284c7',
      grid: 'rgba(79,70,229,0.08)', glow: '0 0 24px rgba(79,70,229,0.18)',
    },
  },
  {
    id: 'carbon', name: 'Carbon',
    tokens: {
      bg: '#0a0a0a', bgSecondary: '#111111', bgTertiary: '#1a1a1a', bgGlass: 'rgba(20,20,20,0.78)',
      fg: '#fafafa', fgSecondary: '#d4d4d4', fgMuted: '#525252',
      border: 'rgba(255,255,255,0.10)', borderLight: 'rgba(255,255,255,0.05)',
      accent: '#f97316', accentFg: '#0a0a0a', accentSoft: 'rgba(249,115,22,0.14)',
      success: '#10b981', warn: '#eab308', danger: '#ef4444', info: '#3b82f6',
      grid: 'rgba(249,115,22,0.05)', glow: '0 0 24px rgba(249,115,22,0.35)',
    },
  },
  {
    id: 'cyber', name: 'Cyber',
    tokens: {
      bg: '#050014', bgSecondary: '#0a0220', bgTertiary: '#150634', bgGlass: 'rgba(21,6,52,0.7)',
      fg: '#e0f7ff', fgSecondary: '#b5e8ff', fgMuted: '#3d5577',
      border: 'rgba(0,240,255,0.18)', borderLight: 'rgba(0,240,255,0.08)',
      accent: '#00f0ff', accentFg: '#050014', accentSoft: 'rgba(0,240,255,0.15)',
      success: '#00ff9d', warn: '#ffea00', danger: '#ff2e88', info: '#b388ff',
      grid: 'rgba(0,240,255,0.08)', glow: '0 0 24px rgba(0,240,255,0.5), 0 0 48px rgba(0,240,255,0.2)',
    },
  },
  {
    id: 'paper', name: 'Paper',
    tokens: {
      bg: '#f5f0e6', bgSecondary: '#fbf7ee', bgTertiary: '#efe6d2', bgGlass: 'rgba(251,247,238,0.85)',
      fg: '#2a1f10', fgSecondary: '#4a3826', fgMuted: '#a89880',
      border: 'rgba(74,56,38,0.18)', borderLight: 'rgba(74,56,38,0.10)',
      accent: '#b45309', accentFg: '#fbf7ee', accentSoft: 'rgba(180,83,9,0.12)',
      success: '#15803d', warn: '#ca8a04', danger: '#b91c1c', info: '#1d4ed8',
      grid: 'rgba(180,83,9,0.06)', glow: '0 0 24px rgba(180,83,9,0.2)',
    },
  },
];

/* ========== TOOL DEFINITIONS FOR UI ========== */
const TOOL_DEFS = [
  { name: 'select', label: 'Select', shortcut: 'V', svg: '<path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/>' },
  { name: 'pan', label: 'Pan', shortcut: 'H', svg: '<path d="M5 9l-3 3 3 3"/><path d="M9 5l3-3 3 3"/><path d="M15 19l-3 3-3-3"/><path d="M19 9l3 3-3 3"/><line x1="2" y1="12" x2="22" y2="12"/><line x1="12" y1="2" x2="12" y2="22"/>' },
  { name: 'rectangle', label: 'Rectangle', shortcut: 'R', svg: '<rect x="3" y="3" width="18" height="18" rx="2"/>' },
  { name: 'ellipse', label: 'Ellipse', shortcut: 'E', svg: '<ellipse cx="12" cy="12" rx="10" ry="7"/>' },
  { name: 'line', label: 'Line', shortcut: 'L', svg: '<line x1="5" y1="19" x2="19" y2="5"/>' },
  { name: 'text', label: 'Text', shortcut: 'T', svg: '<path d="M4 7V4h16v3"/><path d="M9 20h6"/><path d="M12 4v16"/>' },
  { name: 'freehand', label: 'Pen', shortcut: 'P', svg: '<path d="M12 19l7-7 3 3-7 7-3-3z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"/>' },
  { name: 'connection', label: 'Connect', shortcut: 'C', svg: '<path d="M10 13a5 5 0 007.54.54l3-3a5 5 0 00-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 00-7.54-.54l-3 3a5 5 0 007.07 7.07l1.71-1.71"/>' },
];

/* ========== MAIN COMPONENT ========== */
export default function CanvasPlayground() {
  /* --- Refs --- */
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<CanvasEngine | null>(null);

  /* --- State --- */
  const [theme, setTheme] = useState<Theme>(THEMES[0]);
  const [activeTool, setActiveTool] = useState('select');
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [viewport, setViewport] = useState<ViewportState>({ x: 0, y: 0, zoom: 1 });
  const [layers, setLayers] = useState<ZLayer[]>([]);
  const [connections, setConnections] = useState<Connection[]>([]);
  const [commandInfo, setCommandInfo] = useState({ canUndo: false, canRedo: false, undoDesc: '', redoDesc: '' });
  const [showRightPanel, setShowRightPanel] = useState(true);
  const [showLeftPanel, setShowLeftPanel] = useState(true);
  const [commandInput, setCommandInput] = useState('');
  const [mouseWorld, setMouseWorld] = useState<Vec2>({ x: 0, y: 0 });
  const [nodeCount, setNodeCount] = useState(0);

  const toolsRef = useRef<Map<string, BaseTool>>(new Map());
  const toolCtxRef = useRef<ToolContext | null>(null);
  const isPanningRef = useRef(false);
  const panStartRef = useRef<Vec2>({ x: 0, y: 0 });

  /* --- Initialize Engine --- */
  useEffect(() => {
    if (!canvasRef.current || !containerRef.current) return;

    const engine = new CanvasEngine();
    engineRef.current = engine;

    // Register renderers
    for (const r of ALL_RENDERERS) {
      engine.registerRenderer(r.type, r.render);
    }

    // Attach canvas
    engine.attach(canvasRef.current);

    // Register tools
    const toolMap = new Map<string, BaseTool>();
    for (const t of ALL_TOOLS) {
      toolMap.set(t.name, t);
    }
    toolsRef.current = toolMap;

    // Create tool context
    const toolCtx: ToolContext = {
      engine,
      getMouseWorld: () => mouseWorld,
      getMouseScreen: () => ({ x: 0, y: 0 }),
      selectNode: (id: string | null) => {
        setSelectedNodeId(id);
        engine.eventBus.emit('selection:changed', id);
      },
      getSelectedNodeId: () => selectedNodeId,
    };
    toolCtxRef.current = toolCtx;

    // Activate default tool
    const defaultTool = toolMap.get('select');
    if (defaultTool) defaultTool.activate(toolCtx);

    // Listen to events
    const unsubs = [
      engine.eventBus.on('viewport:changed', (vp: ViewportState) => setViewport({ ...vp })),
      engine.eventBus.on('scene:node-added', () => setNodeCount(engine.scene.nodeCount)),
      engine.eventBus.on('scene:node-removed', () => setNodeCount(engine.scene.nodeCount)),
    ];

    // Resize handler
    const onResize = () => engine.resize();
    window.addEventListener('resize', onResize);

    // Initial layer state
    setLayers(engine.scene.getAllLayers());

    return () => {
      unsubs.forEach(u => u());
      window.removeEventListener('resize', onResize);
      engine.stop();
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* --- Update tool context refs --- */
  useEffect(() => {
    if (toolCtxRef.current) {
      toolCtxRef.current.selectNode = (id: string | null) => {
        setSelectedNodeId(id);
        engineRef.current?.eventBus.emit('selection:changed', id);
      };
      toolCtxRef.current.getSelectedNodeId = () => selectedNodeId;
    }
  }, [selectedNodeId]);

  useEffect(() => {
    if (toolCtxRef.current) {
      toolCtxRef.current.getMouseWorld = () => mouseWorld;
    }
  }, [mouseWorld]);

  /* --- Update command info --- */
  useEffect(() => {
    const interval = setInterval(() => {
      if (!engineRef.current) return;
      const cs = engineRef.current.commandStack;
      setCommandInfo({
        canUndo: cs.canUndo(),
        canRedo: cs.canRedo(),
        undoDesc: cs.getUndoDescription() ?? '',
        redoDesc: cs.getRedoDescription() ?? '',
      });
    }, 200);
    return () => clearInterval(interval);
  }, []);

  /* --- Keyboard shortcuts --- */
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      // Ctrl+Z / Ctrl+Shift+Z
      if ((e.ctrlKey || e.metaKey) && e.key === 'z' && !e.shiftKey) {
        e.preventDefault();
        engineRef.current?.commandStack.undo();
      }
      if ((e.ctrlKey || e.metaKey) && (e.key === 'Z' || e.key === 'y')) {
        e.preventDefault();
        engineRef.current?.commandStack.redo();
      }

      // Tool shortcuts
      const shortcutMap: Record<string, string> = { v: 'select', h: 'pan', r: 'rectangle', e: 'ellipse', l: 'line', t: 'text', p: 'freehand', c: 'connection' };
      if (!e.ctrlKey && !e.metaKey && !e.altKey) {
        const tool = shortcutMap[e.key.toLowerCase()];
        if (tool) switchTool(tool);

        if (e.key === 'Delete' || e.key === 'Backspace') {
          const activeT = toolsRef.current.get(activeTool);
          if (activeT?.onKeyDown) activeT.onKeyDown(e);
        }
      }

      // Space for temporary pan
      if (e.key === ' ') {
        e.preventDefault();
        if (!isPanningRef.current) {
          isPanningRef.current = true;
          const panTool = toolsRef.current.get('pan');
          if (panTool && activeTool !== 'pan') panTool.activate(toolCtxRef.current!);
        }
      }
    };
    const upHandler = (e: KeyboardEvent) => {
      if (e.key === ' ' && isPanningRef.current) {
        isPanningRef.current = false;
        const currentT = toolsRef.current.get(activeTool);
        if (currentT) currentT.activate(toolCtxRef.current!);
      }
    };
    window.addEventListener('keydown', handler);
    window.addEventListener('keyup', upHandler);
    return () => {
      window.removeEventListener('keydown', handler);
      window.removeEventListener('keyup', upHandler);
    };
  }, [activeTool]);

  /* --- Tool Switching --- */
  const switchTool = useCallback((name: string) => {
    const oldTool = toolsRef.current.get(activeTool);
    oldTool?.deactivate();

    const newTool = toolsRef.current.get(name);
    if (newTool && toolCtxRef.current) {
      newTool.activate(toolCtxRef.current);
      setActiveTool(name);
    }
  }, [activeTool]);

  /* --- Canvas Pointer Events --- */
  const getWorldPos = useCallback((e: PointerEvent): Vec2 => {
    return engineRef.current?.screenToWorld(e.clientX, e.clientY) ?? { x: 0, y: 0 };
  }, []);

  const onPointerDown = useCallback((e: PointerEvent) => {
    const world = getWorldPos(e);
    setMouseWorld(world);

    // Middle mouse or shift+click = pan
    if (e.button === 1 || (e.button === 0 && (e.shiftKey || isPanningRef.current))) {
      e.preventDefault();
      const panTool = toolsRef.current.get('pan');
      if (panTool) {
        panTool.activate(toolCtxRef.current!);
        panTool.onMouseDown?.(e);
        panStartRef.current = { x: e.clientX, y: e.clientY };
      }
      return;
    }

    const tool = toolsRef.current.get(activeTool);
    if (tool?.onMouseDown) tool.onMouseDown(e);
  }, [activeTool, getWorldPos]);

  const onPointerMove = useCallback((e: PointerEvent) => {
    const world = getWorldPos(e);
    setMouseWorld(world);

    if (isPanningRef.current || e.buttons === 4) {
      const tool = toolsRef.current.get('pan');
      tool?.onMouseMove?.(e);
      return;
    }

    const tool = toolsRef.current.get(activeTool);
    if (tool?.onMouseMove) tool.onMouseMove(e);
  }, [activeTool, getWorldPos]);

  const onPointerUp = useCallback((e: PointerEvent) => {
    if (isPanningRef.current || e.button === 1) {
      const tool = toolsRef.current.get('pan');
      tool?.onMouseUp?.(e);
      // Re-activate previous tool
      if (isPanningRef.current || e.button === 1) {
        const currentT = toolsRef.current.get(activeTool);
        if (currentT) currentT.activate(toolCtxRef.current!);
      }
      return;
    }

    const tool = toolsRef.current.get(activeTool);
    if (tool?.onMouseUp) tool.onMouseUp(e);
  }, [activeTool]);

  const onWheel = useCallback((e: WheelEvent) => {
    e.preventDefault();
    engineRef.current?.zoomAt(e.clientX, e.clientY, e.deltaY);
  }, []);

  useEffect(() => {
    const el = canvasRef.current?.parentElement;
    if (!el) return;
    el.addEventListener('pointerdown', onPointerDown as EventListener);
    el.addEventListener('pointermove', onPointerMove as EventListener);
    el.addEventListener('pointerup', onPointerUp as EventListener);
    el.addEventListener('wheel', onWheel, { passive: false });
    el.addEventListener('contextmenu', e => e.preventDefault());
    return () => {
      el.removeEventListener('pointerdown', onPointerDown as EventListener);
      el.removeEventListener('pointermove', onPointerMove as EventListener);
      el.removeEventListener('pointerup', onPointerUp as EventListener);
      el.removeEventListener('wheel', onWheel);
    };
  }, [onPointerDown, onPointerMove, onPointerUp, onWheel]);

  /* --- Selected Node --- */
  const selectedNode = selectedNodeId ? engineRef.current?.scene.getNode(selectedNodeId) ?? null : null;

  /* --- Update node prop through command --- */
  const updateNodeProp = useCallback((key: string, value: unknown) => {
    if (!selectedNodeId || !engineRef.current) return;
    const node = engineRef.current.scene.getNode(selectedNodeId);
    if (!node) return;
    const oldVal = node.props[key];
    const nodeId = selectedNodeId;
    engineRef.current.commandStack.execute({
      id: uuid(),
      description: `Edit ${key}`,
      execute: () => {
        const n = engineRef.current!.scene.getNode(nodeId);
        if (n) { n.props[key] = value; engineRef.current!.markDirty(nodeId); }
      },
      undo: () => {
        const n = engineRef.current!.scene.getNode(nodeId);
        if (n) { n.props[key] = oldVal; engineRef.current!.markDirty(nodeId); }
      },
    });
  }, [selectedNodeId]);

  /* --- Command Bar --- */
  const executeCommand = useCallback((input: string) => {
    const cmd = input.trim().toLowerCase();
    if (!cmd) return;
    const eng = engineRef.current;
    if (!eng) return;

    if (cmd === 'undo') { eng.commandStack.undo(); return; }
    if (cmd === 'redo') { eng.commandStack.redo(); return; }
    if (cmd === 'clear') { eng.scene.clear(); return; }
    if (cmd.startsWith('theme ')) {
      const t = THEMES.find(t => t.id === cmd.split(' ')[1]);
      if (t) setTheme(t);
      return;
    }
    if (cmd.startsWith('zoom ')) {
      const z = parseFloat(cmd.split(' ')[1]);
      if (!isNaN(z)) eng.setViewport(eng.getViewport().x, eng.getViewport().y, z / 100);
      return;
    }
    if (cmd === 'reset') { eng.setViewport(0, 0, 1); return; }
    if (cmd.startsWith('add rectangle') || cmd.startsWith('add rect')) {
      const nodeId = uuid();
      const pos = { x: viewport.x - 50, y: viewport.y - 25 };
      eng.scene.addNode({
        id: nodeId, type: 'rectangle', position: pos, rotation: 0,
        boundingBox: { ...pos, width: 100, height: 50 },
        props: { fill: theme.tokens.accent, stroke: theme.tokens.fgMuted, strokeWidth: 2, opacity: 1, cornerRadius: 8 },
        layerId: eng.scene.getActiveLayerId(),
        documentation: 'Rectangle added via command.',
        editableProps: { fill: { type: 'color', label: 'Fill' }, stroke: { type: 'color', label: 'Stroke' } },
      });
      return;
    }
  }, [viewport, theme]);

  /* --- Theme CSS variable application --- */
  useEffect(() => {
    const t = theme.tokens;
    const root = document.documentElement;
    root.style.setProperty('--c-bg', t.bg);
    root.style.setProperty('--c-bg2', t.bgSecondary);
    root.style.setProperty('--c-bg3', t.bgTertiary);
    root.style.setProperty('--c-glass', t.bgGlass);
    root.style.setProperty('--c-fg', t.fg);
    root.style.setProperty('--c-fg2', t.fgSecondary);
    root.style.setProperty('--c-fg3', t.fgMuted);
    root.style.setProperty('--c-border', t.border);
    root.style.setProperty('--c-border-light', t.borderLight);
    root.style.setProperty('--c-accent', t.accent);
    root.style.setProperty('--c-accent-fg', t.accentFg);
    root.style.setProperty('--c-accent-soft', t.accentSoft);
    root.style.setProperty('--c-success', t.success);
    root.style.setProperty('--c-warn', t.warn);
    root.style.setProperty('--c-danger', t.danger);
    root.style.setProperty('--c-info', t.info);
    root.style.setProperty('--c-glow', t.glow);
  }, [theme]);

  /* ========== RENDER ========== */
  const t = theme.tokens;

  return (
    <div ref={containerRef} style={{
      position: 'fixed', inset: 0, display: 'grid',
      gridTemplateColumns: `${showLeftPanel ? '52px' : '0px'} ${showRightPanel ? '1fr 300px' : '1fr 0px'}`,
      gridTemplateRows: '1fr 48px',
      gridTemplateAreas: '"rail canvas right" "rail cmd cmd"',
      background: t.bg, color: t.fg, fontFamily: "'Inter', system-ui, sans-serif",
      overflow: 'hidden', transition: 'background 0.4s ease',
    }}>

      {/* ===== LEFT RAIL ===== */}
      <aside style={{ gridArea: 'rail', background: t.bgSecondary, borderRight: `1px solid ${t.borderLight}`, display: 'flex', flexDirection: 'column', alignItems: 'center', padding: '8px 0', gap: '4px', zIndex: 10 }}>
        {/* Logo */}
        <div style={{ width: 32, height: 32, borderRadius: 8, background: `linear-gradient(135deg, ${t.accent}, ${t.info})`, display: 'grid', placeItems: 'center', fontWeight: 800, fontSize: 14, color: t.accentFg, marginBottom: 8, boxShadow: t.glow }}>
          C
        </div>

        {/* Tool buttons */}
        {TOOL_DEFS.map(td => (
          <button key={td.name} title={`${td.label} (${td.shortcut})`} onClick={() => switchTool(td.name)} style={{
            width: 36, height: 36, borderRadius: 8, border: 'none', background: activeTool === td.name ? t.accentSoft : 'transparent',
            color: activeTool === td.name ? t.accent : t.fgMuted, cursor: 'pointer',
            display: 'grid', placeItems: 'center', transition: 'all 0.12s ease', position: 'relative',
          }}
            onMouseEnter={e => { if (activeTool !== td.name) (e.target as HTMLElement).style.background = t.bgTertiary; }}
            onMouseLeave={e => { if (activeTool !== td.name) (e.target as HTMLElement).style.background = 'transparent'; }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" dangerouslySetInnerHTML={{ __html: td.svg }} />
            {activeTool === td.name && <div style={{ position: 'absolute', left: -4, top: 6, bottom: 6, width: 3, borderRadius: 4, background: t.accent }} />}
          </button>
        ))}

        <div style={{ flex: 1 }} />

        {/* Theme swatches */}
        {THEMES.map(th => (
          <button key={th.id} title={th.name} onClick={() => setTheme(th)} style={{
            width: 22, height: 22, borderRadius: 6, border: theme.id === th.id ? `2px solid ${t.accent}` : `2px solid ${t.border}`,
            background: th.tokens.accent, cursor: 'pointer', boxShadow: theme.id === th.id ? t.glow : 'none',
            transition: 'all 0.15s ease',
          }} />
        ))}

        <div style={{ height: 8 }} />
      </aside>

      {/* ===== CANVAS AREA ===== */}
      <main style={{ gridArea: 'canvas', position: 'relative', overflow: 'hidden' }}>
        <canvas ref={canvasRef} style={{ display: 'block', width: '100%', height: '100%' }} />

        {/* HUD - Coordinates */}
        <div style={{
          position: 'absolute', bottom: 8, left: 8, display: 'flex', gap: 12,
          background: t.bgGlass, backdropFilter: 'blur(8px)', border: `1px solid ${t.borderLight}`,
          borderRadius: 8, padding: '4px 10px', fontFamily: "'JetBrains Mono', monospace", fontSize: 11,
          color: t.fgMuted, pointerEvents: 'none', zIndex: 5,
        }}>
          <span><b style={{ color: t.fgSecondary }}>X</b> {Math.round(mouseWorld.x)}</span>
          <span><b style={{ color: t.fgSecondary }}>Y</b> {Math.round(mouseWorld.y)}</span>
          <span><b style={{ color: t.fgSecondary }}>ZOOM</b> {Math.round(viewport.zoom * 100)}%</span>
          <span><b style={{ color: t.fgSecondary }}>NODES</b> {nodeCount}</span>
        </div>

        {/* Z-Layer pills */}
        <div style={{
          position: 'absolute', top: 8, right: 8, display: 'flex', gap: 4,
          background: t.bgGlass, backdropFilter: 'blur(12px)', border: `1px solid ${t.border}`,
          borderRadius: 8, padding: '4px 8px', zIndex: 5,
        }}>
          {engineRef.current?.scene.getAllLayers().map(layer => (
            <button key={layer.id} onClick={() => engineRef.current?.scene.setActiveLayer(layer.id)} style={{
              padding: '2px 8px', borderRadius: 4, border: 'none',
              background: layer.id === engineRef.current.scene.getActiveLayerId() ? t.accent : 'transparent',
              color: layer.id === engineRef.current.scene.getActiveLayerId() ? t.accentFg : t.fgMuted,
              fontSize: 10, fontFamily: "'JetBrains Mono', monospace", fontWeight: 600,
              cursor: 'pointer', opacity: layer.visible ? 1 : 0.4, transition: 'all 0.12s',
            }}>
              {layer.name}
            </button>
          ))}
        </div>

        {/* Selection highlight on canvas (rendered via canvas overlay concept - selection box) */}
        {selectedNode && (() => {
          const eng = engineRef.current;
          if (!eng) return null;
          const { x, y, width, height } = selectedNode.boundingBox;
          const tl = eng.worldToScreen(x, y);
          const br = eng.worldToScreen(x + width, y + height);
          const sw = br.x - tl.x;
          const sh = br.y - tl.y;
          return (
            <div style={{
              position: 'absolute', left: tl.x - 1, top: tl.y - 1, width: sw + 2, height: sh + 2,
              border: `1.5px solid ${t.accent}`, borderRadius: 2, pointerEvents: 'none',
              boxShadow: t.glow, zIndex: 5,
            }}>
              {/* Resize handle */}
              <div style={{
                position: 'absolute', right: -3, bottom: -3, width: 8, height: 8,
                background: t.accent, borderRadius: 2, cursor: 'nwse-resize',
              }} />
            </div>
          );
        })()}

        {/* Connection wires SVG overlay */}
        {engineRef.current && (() => {
          const conns = engineRef.current.scene.getAllConnections();
          if (conns.length === 0) return null;
          return (
            <svg style={{ position: 'absolute', inset: 0, pointerEvents: 'none', zIndex: 4 }}>
              {conns.map(conn => {
                const fromNode = engineRef.current!.scene.getNode(conn.fromNodeId);
                const toNode = engineRef.current!.scene.getNode(conn.toNodeId);
                if (!fromNode || !toNode) return null;
                const fp = engineRef.current!.worldToScreen(
                  fromNode.boundingBox.x + fromNode.boundingBox.width / 2,
                  fromNode.boundingBox.y + fromNode.boundingBox.height / 2,
                );
                const tp = engineRef.current!.worldToScreen(
                  toNode.boundingBox.x + toNode.boundingBox.width / 2,
                  toNode.boundingBox.y + toNode.boundingBox.height / 2,
                );
                const mx = (fp.x + tp.x) / 2;
                const d = `M${fp.x},${fp.y} C${mx},${fp.y} ${mx},${tp.y} ${tp.x},${tp.y}`;
                return (
                  <path key={conn.id} d={d} fill="none" stroke={conn.color || t.accent} strokeWidth="2"
                    strokeDasharray="8 4" opacity={0.6}
                    style={{ animation: 'dash-flow 1s linear infinite' }} />
                );
              })}
            </svg>
          );
        })()}
      </main>

      {/* ===== RIGHT PANEL (Inspector) ===== */}
      {showRightPanel && (
        <aside style={{
          gridArea: 'right', background: t.bgSecondary, borderLeft: `1px solid ${t.borderLight}`,
          display: 'flex', flexDirection: 'column', overflow: 'hidden', zIndex: 10,
        }}>
          <div style={{ padding: '10px 14px', borderBottom: `1px solid ${t.borderLight}`, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.08em', color: t.fgMuted }}>
              {selectedNode ? selectedNode.type : 'Inspector'}
            </span>
            {selectedNode?.documentation && (
              <span style={{ fontSize: 9, color: t.info, marginLeft: 'auto' }}>i</span>
            )}
          </div>

          <div style={{ flex: 1, overflowY: 'auto', padding: 12 }}>
            {selectedNode ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {/* Documentation */}
                {selectedNode.documentation && (
                  <div style={{ fontSize: 11, color: t.fgMuted, lineHeight: 1.5, padding: 8, background: t.bgTertiary, borderRadius: 6, borderLeft: `2px solid ${t.info}` }}>
                    {selectedNode.documentation}
                  </div>
                )}

                {/* Position */}
                <div style={{ fontSize: 10, fontWeight: 600, color: t.fgMuted, textTransform: 'uppercase', letterSpacing: '0.06em', marginTop: 4 }}>Position</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 6 }}>
                  <label style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <span style={{ fontSize: 10, color: t.fgMuted }}>X</span>
                    <input type="number" value={Math.round(selectedNode.position.x)} readOnly style={{
                      background: t.bgTertiary, border: `1px solid ${t.borderLight}`, borderRadius: 4,
                      padding: '4px 6px', fontSize: 12, color: t.fg, outline: 'none', fontFamily: "'JetBrains Mono', monospace",
                    }} />
                  </label>
                  <label style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <span style={{ fontSize: 10, color: t.fgMuted }}>Y</span>
                    <input type="number" value={Math.round(selectedNode.position.y)} readOnly style={{
                      background: t.bgTertiary, border: `1px solid ${t.borderLight}`, borderRadius: 4,
                      padding: '4px 6px', fontSize: 12, color: t.fg, outline: 'none', fontFamily: "'JetBrains Mono', monospace",
                    }} />
                  </label>
                </div>

                {/* Editable Props */}
                {selectedNode.editableProps && Object.entries(selectedNode.editableProps).map(([key, schema]) => (
                  <label key={key} style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
                    <span style={{ fontSize: 10, color: t.fgMuted }}>{schema.label}</span>
                    {schema.type === 'color' ? (
                      <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                        <input type="color" value={(selectedNode.props[key] as string) || '#000000'} onChange={e => updateNodeProp(key, e.target.value)} style={{ width: 32, height: 24, border: `1px solid ${t.border}`, borderRadius: 4, background: 'none', cursor: 'pointer', padding: 1 }} />
                        <span style={{ fontSize: 11, fontFamily: "'JetBrains Mono', monospace", color: t.fgSecondary }}>{selectedNode.props[key] as string}</span>
                      </div>
                    ) : schema.type === 'number' ? (
                      <input type="number" value={selectedNode.props[key] as number} min={schema.min} max={schema.max} onChange={e => updateNodeProp(key, parseFloat(e.target.value))} style={{
                        background: t.bgTertiary, border: `1px solid ${t.borderLight}`, borderRadius: 4,
                        padding: '4px 6px', fontSize: 12, color: t.fg, outline: 'none', fontFamily: "'JetBrains Mono', monospace",
                      }} />
                    ) : schema.type === 'string' ? (
                      <input type="text" value={(selectedNode.props[key] as string) || ''} onChange={e => updateNodeProp(key, e.target.value)} style={{
                        background: t.bgTertiary, border: `1px solid ${t.borderLight}`, borderRadius: 4,
                        padding: '4px 6px', fontSize: 12, color: t.fg, outline: 'none',
                      }} />
                    ) : schema.type === 'select' ? (
                      <select value={(selectedNode.props[key] as string) || ''} onChange={e => updateNodeProp(key, e.target.value)} style={{
                        background: t.bgTertiary, border: `1px solid ${t.borderLight}`, borderRadius: 4,
                        padding: '4px 6px', fontSize: 12, color: t.fg, outline: 'none',
                      }}>
                        {schema.options?.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    ) : (
                      <span style={{ fontSize: 11, color: t.fgMuted }}>{String(selectedNode.props[key])}</span>
                    )}
                  </label>
                ))}

                {/* Connections */}
                {engineRef.current && (() => {
                  const nodeConns = engineRef.current.scene.getConnectionsForNode(selectedNodeId!);
                  if (nodeConns.length === 0) return null;
                  return (
                    <div style={{ marginTop: 8 }}>
                      <div style={{ fontSize: 10, fontWeight: 600, color: t.fgMuted, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 6 }}>Connections</div>
                      {nodeConns.map(c => {
                        const otherId = c.fromNodeId === selectedNodeId ? c.toNodeId : c.fromNodeId;
                        const otherNode = engineRef.current!.scene.getNode(otherId);
                        return (
                          <div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '4px 6px', background: t.bgTertiary, borderRadius: 4, marginBottom: 4, fontSize: 11 }}>
                            <span style={{ color: t.accent }}>→</span>
                            <span style={{ color: t.fgSecondary }}>{otherNode?.type ?? otherId}</span>
                            <button onClick={() => engineRef.current!.scene.removeConnection(c.id)} style={{ marginLeft: 'auto', background: 'none', border: 'none', color: t.fgMuted, cursor: 'pointer', fontSize: 12 }}>&times;</button>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}

                {/* Delete button */}
                <button onClick={() => {
                  if (!selectedNodeId || !engineRef.current) return;
                  const node = engineRef.current.scene.getNode(selectedNodeId);
                  if (!node) return;
                  const nid = selectedNodeId;
                  engineRef.current.commandStack.execute({
                    id: uuid(), description: `Delete ${node.type}`,
                    execute: () => { engineRef.current!.scene.removeNode(nid); setSelectedNodeId(null); },
                    undo: () => { engineRef.current!.scene.addNode(node); setSelectedNodeId(nid); },
                  });
                }} style={{
                  marginTop: 12, padding: '6px 0', borderRadius: 6, border: `1px solid ${t.danger}`,
                  background: 'transparent', color: t.danger, fontSize: 12, fontWeight: 600,
                  cursor: 'pointer', transition: 'all 0.12s',
                }}>
                  Delete Node
                </button>
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100%', color: t.fgMuted, fontSize: 12, textAlign: 'center', gap: 8 }}>
                <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" opacity={0.4}>
                  <path d="M3 3l7.07 16.97 2.51-7.39 7.39-2.51L3 3z" />
                </svg>
                <span>Select a node to inspect</span>
                <span style={{ fontSize: 10 }}>or draw one with the tools</span>
              </div>
            )}
          </div>
        </aside>
      )}

      {/* ===== COMMAND BAR ===== */}
      <div style={{
        gridArea: 'cmd', background: t.bgSecondary, borderTop: `1px solid ${t.borderLight}`,
        display: 'flex', alignItems: 'center', gap: 10, padding: '0 14px', zIndex: 20,
      }}>
        <div style={{
          width: 28, height: 28, borderRadius: 6, background: t.accentSoft, color: t.accent,
          display: 'grid', placeItems: 'center', flexShrink: 0,
        }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 18l6-6-6-6" /></svg>
        </div>
        <input value={commandInput} onChange={e => setCommandInput(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') { executeCommand(commandInput); setCommandInput(''); } }}
          placeholder='Commands: "theme cyber" · "add rectangle" · "undo" · "redo" · "reset" · "zoom 200%"'
          style={{
            flex: 1, background: 'transparent', border: 'none', outline: 'none',
            fontSize: 13, color: t.fg, padding: '8px 0', fontFamily: "'JetBrains Mono', monospace",
          }}
        />
        <span style={{ fontSize: 10, color: t.fgMuted, fontFamily: "'JetBrains Mono', monospace" }}>
          {commandInfo.canUndo ? `↩ ${commandInfo.undoDesc}` : ''}
        </span>
        <div style={{ display: 'flex', gap: 4 }}>
          <button onClick={() => engineRef.current?.commandStack.undo()} disabled={!commandInfo.canUndo} style={{
            padding: '4px 10px', borderRadius: 6, background: commandInfo.canUndo ? t.bgTertiary : 'transparent',
            border: `1px solid ${t.borderLight}`, color: commandInfo.canUndo ? t.fgSecondary : t.fgMuted,
            fontSize: 11, cursor: commandInfo.canUndo ? 'pointer' : 'default', transition: 'all 0.12s',
          }}>Undo</button>
          <button onClick={() => engineRef.current?.commandStack.redo()} disabled={!commandInfo.canRedo} style={{
            padding: '4px 10px', borderRadius: 6, background: commandInfo.canRedo ? t.bgTertiary : 'transparent',
            border: `1px solid ${t.borderLight}`, color: commandInfo.canRedo ? t.fgSecondary : t.fgMuted,
            fontSize: 11, cursor: commandInfo.canRedo ? 'pointer' : 'default', transition: 'all 0.12s',
          }}>Redo</button>
        </div>
      </div>

      {/* ===== CSS ANIMATIONS ===== */}
      <style>{`
        @keyframes dash-flow { to { stroke-dashoffset: -12; } }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: var(--c-border, rgba(255,255,255,0.12)); border-radius: 9px; }
      `}</style>
    </div>
  );
}