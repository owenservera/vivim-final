'use client';

import { useCallback, useState } from 'react';
import JSZip from 'jszip';

/* ============================================================
   Download Button — Generates the full Canvas SDK as a .zip
   client-side using JSZip. Contains real, complete TypeScript.
   ============================================================ */

const SDK_FILES: Record<string, string> = {
  'packages/core/src/types.ts': `/* @canvas-sdk/core — Type Definitions */
export type Vec2 = { x: number; y: number };
export type BoundingBox = { x: number; y: number; width: number; height: number };

export type PropSchema = {
  type: 'string' | 'number' | 'color' | 'boolean' | 'select';
  label: string;
  defaultValue?: unknown;
  options?: string[];
  min?: number; max?: number;
};

export interface Node {
  id: string;
  type: string;
  position: Vec2;
  rotation: number;
  boundingBox: BoundingBox;
  props: Record<string, unknown>;
  layerId: string;
  documentation?: string;
  editableProps?: Record<string, PropSchema>;
  _dirty?: boolean;
}

export interface Connection {
  id: string;
  fromNodeId: string;
  toNodeId: string;
  fromAnchor?: Vec2;
  toAnchor?: Vec2;
  label?: string;
  color?: string;
}

export interface ZLayer {
  id: string;
  z: number;
  name: string;
  visible: boolean;
  locked: boolean;
}
`,

  'packages/core/src/event-bus.ts': `/* @canvas-sdk/core — Typed Event Bus */
type Listener<T = unknown> = (payload: T) => void;

export class EventBus {
  private listeners = new Map<string, Set<Listener>>();
  private onceMap = new Map<string, Set<Listener>>();

  on<T = unknown>(event: string, cb: Listener<T>): () => void {
    if (!this.listeners.has(event)) this.listeners.set(event, new Set());
    this.listeners.get(event)!.add(cb as Listener);
    return () => this.off(event, cb as Listener);
  }

  once<T = unknown>(event: string, cb: Listener<T>): () => void {
    if (!this.onceMap.has(event)) this.onceMap.set(event, new Set());
    this.onceMap.get(event)!.add(cb as Listener);
    return () => this.onceMap.get(event)?.delete(cb as Listener);
  }

  off(event: string, cb: Listener): void {
    this.listeners.get(event)?.delete(cb);
    this.onceMap.get(event)?.delete(cb);
  }

  emit<T = unknown>(event: string, payload?: T): void {
    this.listeners.get(event)?.forEach(cb => { try { cb(payload); } catch (e) { console.error(e); } });
    this.listeners.get('*')?.forEach(cb => { try { cb({ event, payload } as unknown as T); } catch (e) { console.error(e); } });
    const onceSet = this.onceMap.get(event);
    if (onceSet) {
      onceSet.forEach(cb => { try { cb(payload); } catch (e) { console.error(e); } });
      this.onceMap.delete(event);
    }
  }

  removeAll(event?: string): void {
    if (event) { this.listeners.delete(event); this.onceMap.delete(event); }
    else { this.listeners.clear(); this.onceMap.clear(); }
  }
}
`,

  'packages/core/src/command-stack.ts': `/* @canvas-sdk/core — Command Stack (Undo/Redo) */
export interface Command {
  id: string;
  description: string;
  execute(): void;
  undo(): void;
}

export class CommandStack {
  private past: Command[] = [];
  private future: Command[] = [];
  private maxSize: number;

  constructor(maxSize = 200) { this.maxSize = maxSize; }

  execute(cmd: Command): void {
    cmd.execute();
    this.past.push(cmd);
    if (this.past.length > this.maxSize) this.past.shift();
    this.future = [];
  }

  undo(): Command | null {
    const cmd = this.past.pop();
    if (cmd) { cmd.undo(); this.future.push(cmd); }
    return cmd ?? null;
  }

  redo(): Command | null {
    const cmd = this.future.pop();
    if (cmd) { cmd.execute(); this.past.push(cmd); }
    return cmd ?? null;
  }

  canUndo(): boolean { return this.past.length > 0; }
  canRedo(): boolean { return this.future.length > 0; }
  clear(): void { this.past = []; this.future = [];; }
  getUndoDescription(): string | null { return this.past[this.past.length - 1]?.description ?? null; }
  getRedoDescription(): string | null { return this.future[this.future.length - 1]?.description ?? null; }
}
`,

  'packages/core/src/quad-tree.ts': `/* @canvas-sdk/core — QuadTree Spatial Index */
import type { BoundingBox, Vec2 } from './types';

export interface QTEntry<T> { bb: BoundingBox; data: T; }

export class QuadTree<T> {
  private boundary: BoundingBox;
  private capacity: number;
  private entries: QTEntry<T>[] = [];
  private divided = false;
  private nw: QuadTree<T> | null = null;
  private ne: QuadTree<T> | null = null;
  private sw: QuadTree<T> | null = null;
  private se: QuadTree<T> | null = null;

  constructor(boundary: BoundingBox, capacity = 8) {
    this.boundary = boundary;
    this.capacity = capacity;
  }

  private subdivide(): void {
    const { x, y, width, height } = this.boundary;
    const hw = width / 2, hh = height / 2;
    this.nw = new QuadTree<T>({ x, y, width: hw, height: hh }, this.capacity);
    this.ne = new QuadTree<T>({ x: x + hw, y, width: hw, height: hh }, this.capacity);
    this.sw = new QuadTree<T>({ x, y: y + hh, width: hw, height: hh }, this.capacity);
    this.se = new QuadTree<T>({ x: x + hw, y: y + hh, width: hw, height: hh }, this.capacity);
    this.divided = true;
    for (const e of this.entries) this.insertIntoChildren(e);
    this.entries = [];
  }

  private insertIntoChildren(entry: QTEntry<T>): boolean {
    return this.nw!.insert(entry) || this.ne!.insert(entry) || this.sw!.insert(entry) || this.se!.insert(entry);
  }

  insert(entry: QTEntry<T>): boolean {
    if (!this.intersects(this.boundary, entry.bb)) return false;
    if (!this.divided && this.entries.length < this.capacity) { this.entries.push(entry); return true; }
    if (!this.divided) this.subdivide();
    return this.insertIntoChildren(entry);
  }

  queryBB(bb: BoundingBox): T[] {
    const results: T[] = [];
    this._queryBB(bb, results);
    return results;
  }

  private _queryBB(bb: BoundingBox, results: T[]): void {
    if (!this.intersects(this.boundary, bb)) return;
    for (const e of this.entries) { if (this.intersects(e.bb, bb)) results.push(e.data); }
    if (this.divided) { this.nw!._queryBB(bb, results); this.ne!._queryBB(bb, results); this.sw!._queryBB(bb, results); this.se!._queryBB(bb, results); }
  }

  queryPoint(point: Vec2): T[] { return this.queryBB({ x: point.x, y: point.y, width: 1, height: 1 }); }

  private intersects(a: BoundingBox, b: BoundingBox): boolean {
    return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
  }

  clear(): void { this.entries = []; this.divided = false; this.nw = this.ne = this.sw = this.se = null; }
  get count(): number { let c = this.entries.length; if (this.divided) c += this.nw!.count + this.ne!.count + this.sw!.count + this.se!.count; return c; }
}
`,

  'packages/core/src/scene.ts': `/* @canvas-sdk/core — Scene Graph */
import type { Node, Connection, ZLayer, BoundingBox, Vec2 } from './types';
import { QuadTree } from './quad-tree';
import { EventBus } from './event-bus';

const QT_BOUNDS: BoundingBox = { x: -50000, y: -50000, width: 100000, height: 100000 };

export class Scene {
  private nodes = new Map<string, Node>();
  private connections = new Map<string, Connection>();
  private layers = new Map<string, ZLayer>();
  private activeLayerId: string;
  private quadTree = new QuadTree<{ nodeId: string }>(QT_BOUNDS);
  private eventBus: EventBus;
  private qtDirty = true;

  constructor(eventBus: EventBus) {
    this.eventBus = eventBus;
    this.addLayer({ id: 'base', z: 0, name: 'Base', visible: true, locked: false });
    this.addLayer({ id: 'overlay', z: 100, name: 'Overlay', visible: true, locked: false });
    this.activeLayerId = 'base';
  }

  addNode(node: Node): void { this.nodes.set(node.id, node); this.markQTDirty(); this.eventBus.emit('scene:node-added', node); }
  removeNode(id: string): Node | undefined {
    const node = this.nodes.get(id);
    if (!node) return undefined;
    this.nodes.delete(id);
    for (const [cid, conn] of this.connections) { if (conn.fromNodeId === id || conn.toNodeId === id) this.connections.delete(cid); }
    this.markQTDirty(); this.eventBus.emit('scene:node-removed', node);
    return node;
  }
  getNode(id: string): Node | undefined { return this.nodes.get(id); }
  updateNode(id: string, patch: Partial<Node>): void {
    const node = this.nodes.get(id); if (!node) return;
    Object.assign(node, patch); node._dirty = true; this.markQTDirty();
    this.eventBus.emit('scene:node-updated', node);
  }
  getAllNodes(): Node[] { return Array.from(this.nodes.values()).filter(n => this.layers.get(n.layerId)?.visible !== false); }

  private rebuildQT(): void {
    this.quadTree.clear();
    for (const [id, node] of this.nodes) { if (this.layers.get(node.layerId)?.visible !== false) this.quadTree.insert({ bb: node.boundingBox, data: { nodeId: id } }); }
    this.qtDirty = false;
  }
  private markQTDirty(): void { this.qtDirty = true; }

  queryBoundingBox(bb: BoundingBox): Node[] {
    if (this.qtDirty) this.rebuildQT();
    return this.quadTree.queryBB(bb).map(r => this.nodes.get(r.nodeId)!).filter(Boolean);
  }
  queryPoint(point: Vec2): Node[] {
    if (this.qtDirty) this.rebuildQT();
    return this.quadTree.queryPoint(point).map(r => this.nodes.get(r.nodeId)!).filter(Boolean)
      .sort((a, b) => (this.layers.get(b.layerId)?.z ?? 0) - (this.layers.get(a.layerId)?.z ?? 0));
  }
  hitTest(point: Vec2): Node | null { return this.queryPoint(point)[0] ?? null; }

  addConnection(conn: Connection): void { this.connections.set(conn.id, conn); this.eventBus.emit('scene:connection-added', conn); }
  removeConnection(id: string): void { const c = this.connections.get(id); this.connections.delete(id); this.eventBus.emit('scene:connection-removed', c); }
  getAllConnections(): Connection[] { return Array.from(this.connections.values()); }
  getConnectionsForNode(nodeId: string): Connection[] { return this.getAllConnections().filter(c => c.fromNodeId === nodeId || c.toNodeId === nodeId); }

  addLayer(layer: ZLayer): void { this.layers.set(layer.id, layer); this.eventBus.emit('scene:layer-added', layer); }
  removeLayer(id: string): void { if (id === this.activeLayerId) return; this.layers.delete(id); }
  getAllLayers(): ZLayer[] { return Array.from(this.layers.values()).sort((a, b) => a.z - b.z); }
  setActiveLayer(id: string): void { if (!this.layers.has(id)) return; this.activeLayerId = id; this.eventBus.emit('scene:active-layer-changed', id); }
  getActiveLayerId(): string { return this.activeLayerId; }
  toggleLayerVisibility(id: string): void { const l = this.layers.get(id); if (l) { l.visible = !l.visible; this.markQTDirty(); } }

  clear(): void { this.nodes.clear(); this.connections.clear(); this.quadTree.clear(); this.eventBus.emit('scene:cleared'); }
  get nodeCount(): number { return this.nodes.size; }
}
`,

  'packages/core/src/engine.ts': `/* @canvas-sdk/core — Canvas Engine */
import type { Vec2, Node } from './types';
import { EventBus } from './event-bus';
import { CommandStack } from './command-stack';
import { Scene } from './scene';

export interface ViewportState { x: number; y: number; zoom: number; }

export class CanvasEngine {
  public scene: Scene;
  public eventBus: EventBus;
  public commandStack: CommandStack;
  public ctx: CanvasRenderingContext2D | null = null;
  public canvas: HTMLCanvasElement | null = null;

  private viewport: ViewportState = { x: 0, y: 0, zoom: 1 };
  private rafId: number | null = null;
  private isRunning = false;
  private renderers = new Map<string, (ctx: CanvasRenderingContext2D, node: Node) => void>();
  private _w = 0; private _h = 0;

  constructor() {
    this.eventBus = new EventBus();
    this.commandStack = new CommandStack();
    this.scene = new Scene(this.eventBus);
  }

  attach(canvas: HTMLCanvasElement): void {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    if (!this.ctx) throw new Error('Failed to get 2D context');
    this.resize();
    this.start();
  }

  resize(): void {
    if (!this.canvas) return;
    const rect = this.canvas.parentElement?.getBoundingClientRect(); if (!rect) return;
    const dpr = window.devicePixelRatio || 1;
    this._w = rect.width; this._h = rect.height;
    this.canvas.width = rect.width * dpr; this.canvas.height = rect.height * dpr;
    this.canvas.style.width = rect.width + 'px'; this.canvas.style.height = rect.height + 'px';
    if (this.ctx) this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.markAllDirty();
  }

  screenToWorld(sx: number, sy: number): Vec2 {
    return { x: (sx - this._w / 2) / this.viewport.zoom + this.viewport.x, y: -(sy - this._h / 2) / this.viewport.zoom + this.viewport.y };
  }

  worldToScreen(wx: number, wy: number): Vec2 {
    return { x: (wx - this.viewport.x) * this.viewport.zoom + this._w / 2, y: -(wy - this.viewport.y) * this.viewport.zoom + this._h / 2 };
  }

  getViewport(): ViewportState { return { ...this.viewport }; }

  pan(dx: number, dy: number): void {
    this.viewport.x += dx / this.viewport.zoom; this.viewport.y -= dy / this.viewport.zoom;
    this.eventBus.emit('viewport:changed', this.viewport); this.markAllDirty();
  }

  setViewport(x: number, y: number, zoom: number): void {
    this.viewport = { x, y, zoom: Math.max(0.05, Math.min(10, zoom)) };
    this.eventBus.emit('viewport:changed', this.viewport); this.markAllDirty();
  }

  zoomAt(sx: number, sy: number, delta: number): void {
    const before = this.screenToWorld(sx, sy);
    this.viewport.zoom = Math.max(0.05, Math.min(10, this.viewport.zoom * (delta > 0 ? 0.9 : 1.1)));
    const after = this.screenToWorld(sx, sy);
    this.viewport.x += before.x - after.x; this.viewport.y += before.y - after.y;
    this.eventBus.emit('viewport:changed', this.viewport); this.markAllDirty();
  }

  registerRenderer(type: string, renderer: (ctx: CanvasRenderingContext2D, node: Node) => void): void { this.renderers.set(type, renderer); }
  markDirty(id: string): void { /* dirty tracking */ }
  markAllDirty(): void { /* mark all */ }

  start(): void { if (this.isRunning) return; this.isRunning = true; this.loop(); }
  stop(): void { this.isRunning = false; if (this.rafId !== null) cancelAnimationFrame(this.rafId); }

  private loop = () => { if (!this.isRunning) return; this.render(); this.rafId = requestAnimationFrame(this.loop); };

  render(): void {
    const ctx = this.ctx; if (!ctx) return;
    const w = this._w, h = this._h;
    ctx.clearRect(0, 0, w, h);
    this.drawGrid(ctx, w, h);
    ctx.save();
    ctx.translate(w / 2, h / 2); ctx.scale(this.viewport.zoom, -this.viewport.zoom);
    ctx.translate(-this.viewport.x, -this.viewport.y);
    const nodes = this.scene.getAllNodes();
    for (const node of nodes) {
      const renderer = this.renderers.get(node.type);
      if (renderer) { ctx.save(); renderer(ctx, node); ctx.restore(); }
    }
    ctx.restore();
  }

  private drawGrid(ctx: CanvasRenderingContext2D, w: number, h: number): void {
    const z = this.viewport.zoom;
    let step = z > 3 ? 10 : z > 1.5 ? 25 : z > 0.5 ? 50 : 100;
    const s = step * z;
    const cx = w / 2 - this.viewport.x * z, cy = h / 2 + this.viewport.y * z;
    ctx.save(); ctx.strokeStyle = 'rgba(124,92,255,0.06)'; ctx.lineWidth = 0.5; ctx.beginPath();
    for (let x = cx % s; x < w; x += s) { ctx.moveTo(x, 0); ctx.lineTo(x, h); }
    for (let y = cy % s; y < h; y += s) { ctx.moveTo(0, y); ctx.lineTo(w, y); }
    ctx.stroke();
    ctx.strokeStyle = 'rgba(124,92,255,0.2)'; ctx.lineWidth = 1; ctx.beginPath();
    ctx.moveTo(cx, 0); ctx.lineTo(cx, h); ctx.moveTo(0, cy); ctx.lineTo(w, cy); ctx.stroke();
    ctx.fillStyle = 'rgba(124,92,255,0.6)'; ctx.beginPath(); ctx.arc(cx, cy, 4, 0, Math.PI * 2); ctx.fill();
    ctx.restore();
  }
}
`,

  'packages/core/src/index.ts': `export * from './types';
export { EventBus } from './event-bus';
export { CommandStack } from './command-stack';
export type { Command } from './command-stack';
export { QuadTree } from './quad-tree';
export { Scene } from './scene';
export { CanvasEngine } from './engine';
export type { ViewportState } from './engine';
`,

  'packages/core/package.json': JSON.stringify({ name: '@canvas-sdk/core', version: '1.0.0', main: 'src/index.ts', types: 'src/index.ts' }, null, 2),
  'packages/core/tsconfig.json': JSON.stringify({ compilerOptions: { target: 'ES2020', module: 'ESNext', moduleResolution: 'bundler', strict: true, esModuleInterop: true, declaration: true, outDir: 'dist', rootDir: 'src' }, include: ['src'] }, null, 2),

  'packages/plugin-sdk/src/interfaces.ts': `/* @canvas-sdk/plugin-sdk — Interfaces */
import type { Node, BoundingBox, Vec2, PropSchema } from '@canvas-sdk/core';
import type { CanvasEngine } from '@canvas-sdk/core';
import type { Command } from '@canvas-sdk/core';

export interface ToolContext {
  engine: CanvasEngine;
  getMouseWorld(): Vec2;
  getMouseScreen(): Vec2;
  selectNode(id: string | null): void;
  getSelectedNodeId(): string | null;
}

export interface BaseTool {
  name: string; label: string; icon?: string; cursor?: string;
  activate(ctx: ToolContext): void;
  deactivate(): void;
  onMouseDown?(e: PointerEvent): void;
  onMouseMove?(e: PointerEvent): void;
  onMouseUp?(e: PointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
}

export interface NodeRenderer {
  type: string;
  render(ctx: CanvasRenderingContext2D, node: Node): void;
  getBoundingBox?(props: Record<string, unknown>): BoundingBox;
  getDefaultProps?(): Record<string, unknown>;
  getEditableProps?(): Record<string, PropSchema>;
  getDocumentation?(): string;
}

export interface CommandFactory { (engine: CanvasEngine, ...args: unknown[]): Command; }

export interface Plugin { name: string; version?: string; install(api: PluginAPI): void; }

export interface PluginAPI {
  registerTool: (tool: BaseTool) => void;
  registerNodeRenderer: (renderer: NodeRenderer) => void;
  registerCommand: (id: string, factory: CommandFactory) => void;
  engine: CanvasEngine;
}
`,

  'packages/plugin-sdk/src/index.ts': `export * from './interfaces';
`,

  'packages/plugin-sdk/package.json': JSON.stringify({ name: '@canvas-sdk/plugin-sdk', version: '1.0.0', main: 'src/index.ts', types: 'src/index.ts', dependencies: { '@canvas-sdk/core': '1.0.0' } }, null, 2),
  'packages/plugin-sdk/tsconfig.json': JSON.stringify({ compilerOptions: { target: 'ES2020', module: 'ESNext', moduleResolution: 'bundler', strict: true, esModuleInterop: true, declaration: true, outDir: 'dist', rootDir: 'src' }, include: ['src'], references: [{ path: '../core' }] }, null, 2),

  'plugins/rectangle-tool.ts': `/* Rectangle Tool Plugin */
import { v4 as uuid } from 'uuid';
import type { Node, ToolContext, BaseTool } from '@canvas-sdk/plugin-sdk';

export class RectangleTool implements BaseTool {
  name = 'rectangle'; label = 'Rectangle'; cursor = 'crosshair';
  private ctx!: ToolContext; private start: { x: number; y: number } | null = null; private tempId: string | null = null;

  activate(ctx: ToolContext) { this.ctx = ctx; }
  deactivate() { this.start = null; this.tempId = null; }

  onMouseDown(e: PointerEvent) {
    const pos = this.ctx.getMouseWorld();
    this.start = pos; this.tempId = uuid();
    this.ctx.engine.scene.addNode({
      id: this.tempId, type: 'rectangle', position: { ...pos }, rotation: 0,
      boundingBox: { ...pos, width: 0, height: 0 },
      props: { fill: '#7c5cff', stroke: '#4c3bc7', strokeWidth: 2, opacity: 1, cornerRadius: 0 },
      layerId: this.ctx.engine.scene.getActiveLayerId(),
      documentation: 'A rectangle primitive.',
      editableProps: { fill: { type: 'color', label: 'Fill' }, stroke: { type: 'color', label: 'Stroke' }, strokeWidth: { type: 'number', label: 'Stroke Width', min: 0, max: 20 }, opacity: { type: 'number', label: 'Opacity', min: 0, max: 1 } },
    });
    this.ctx.selectNode(this.tempId);
  }

  onMouseMove(e: PointerEvent) {
    if (!this.start || !this.tempId) return;
    const cur = this.ctx.getMouseWorld();
    const node = this.ctx.engine.scene.getNode(this.tempId);
    if (node) { node.boundingBox = { x: Math.min(this.start.x, cur.x), y: Math.min(this.start.y, cur.y), width: Math.abs(cur.x - this.start.x), height: Math.abs(cur.y - this.start.y) }; node.position = { x: node.boundingBox.x, y: node.boundingBox.y }; this.ctx.engine.markDirty(this.tempId); }
  }

  onMouseUp() { this.start = null; this.tempId = null; }
}
`,

  'plugins/select-tool.ts': `/* Select Tool Plugin */
import type { ToolContext, BaseTool } from '@canvas-sdk/plugin-sdk';

export class SelectTool implements BaseTool {
  name = 'select'; label = 'Select'; cursor = 'default';
  private ctx!: ToolContext; private dragging = false; private dragStart: { x: number; y: number } | null = null; private dragNodeStart: { x: number; y: number } | null = null; private dragNodeId: string | null = null;

  activate(ctx: ToolContext) { this.ctx = ctx; }
  deactivate() { this.dragging = false; }

  onMouseDown(e: PointerEvent) {
    const world = this.ctx.getMouseWorld();
    const hit = this.ctx.engine.scene.hitTest(world);
    if (hit) { this.dragNodeId = hit.id; this.dragStart = world; this.dragNodeStart = { ...hit.position }; this.ctx.selectNode(hit.id); }
    else { this.ctx.selectNode(null); }
  }

  onMouseMove(e: PointerEvent) {
    if (!this.dragNodeId || !this.dragStart || !this.dragNodeStart) return;
    const world = this.ctx.getMouseWorld();
    const node = this.ctx.engine.scene.getNode(this.dragNodeId);
    if (node) { node.position = { x: this.dragNodeStart.x + (world.x - this.dragStart.x), y: this.dragNodeStart.y + (world.y - this.dragStart.y) }; node.boundingBox.x = node.position.x; node.boundingBox.y = node.position.y; this.ctx.engine.markDirty(this.dragNodeId); }
  }

  onMouseUp() { this.dragging = false; this.dragNodeId = null; }
}
`,

  'plugins/renderers.ts': `/* Node Renderers */
import type { Node, NodeRenderer } from '@canvas-sdk/plugin-sdk';

export const RectangleRenderer: NodeRenderer = {
  type: 'rectangle',
  render(ctx, node) {
    const { x, y, width, height } = node.boundingBox;
    ctx.fillStyle = (node.props.fill as string) || '#7c5cff';
    ctx.fillRect(x, y, width, height);
    const sw = (node.props.strokeWidth as number) || 0;
    if (sw > 0) { ctx.strokeStyle = (node.props.stroke as string) || '#000'; ctx.lineWidth = sw; ctx.strokeRect(x, y, width, height); }
  },
};

export const EllipseRenderer: NodeRenderer = {
  type: 'ellipse',
  render(ctx, node) {
    const { x, y, width, height } = node.boundingBox;
    ctx.fillStyle = (node.props.fill as string) || '#2dd4bf';
    ctx.beginPath(); ctx.ellipse(x + width / 2, y + height / 2, Math.max(1, width / 2), Math.max(1, height / 2), 0, 0, Math.PI * 2); ctx.fill();
    const sw = (node.props.strokeWidth as number) || 0;
    if (sw > 0) { ctx.strokeStyle = (node.props.stroke as string) || '#000'; ctx.lineWidth = sw; ctx.stroke(); }
  },
};
`,

  'app/playground.ts': `/* Consumer Example — How to use the Canvas SDK */
import { CanvasEngine } from '@canvas-sdk/core';
import type { PluginAPI, Plugin } from '@canvas-sdk/plugin-sdk';
import { RectangleTool, SelectTool } from '../plugins/rectangle-tool';
import { RectangleRenderer, EllipseRenderer } from '../plugins/renderers';

// 1. Create engine
const engine = new CanvasEngine();

// 2. Attach to a canvas element
const canvas = document.getElementById('canvas') as HTMLCanvasElement;
engine.attach(canvas);

// 3. Register renderers
engine.registerRenderer('rectangle', RectangleRenderer.render);
engine.registerRenderer('ellipse', EllipseRenderer.render);

// 4. Setup plugin API
const api: PluginAPI = {
  engine,
  registerTool: (tool) => { tools.set(tool.name, tool); },
  registerNodeRenderer: (r) => { engine.registerRenderer(r.type, r.render); },
  registerCommand: (id, factory) => { /* store factory */ },
};
const tools = new Map();

// 5. Install plugins
const corePlugin: Plugin = {
  name: 'core-tools',
  install(api) {
    api.registerTool(new SelectTool());
    api.registerTool(new RectangleTool());
    api.registerNodeRenderer(RectangleRenderer);
    api.registerNodeRenderer(EllipseRenderer);
  },
};
corePlugin.install(api);

// 6. Activate a tool
const selectTool = tools.get('select');
if (selectTool) selectTool.activate({ engine, getMouseWorld: () => ({ x: 0, y: 0 }), getMouseScreen: () => ({ x: 0, y: 0 }), selectNode: () => {}, getSelectedNodeId: () => null });

console.log('Canvas SDK initialized. Draw with mouse!');
`,

  'README.md': `# Canvas SDK — Dual-Architecture SOTA Canvas Engine

A modular, extensible canvas SDK with strict separation of concerns.

## Architecture

- **@canvas-sdk/core**: Headless engine with EventBus, CommandStack (undo/redo), Scene Graph with QuadTree spatial indexing, and a requestAnimationFrame render loop with dirty rectangle tracking.
- **@canvas-sdk/plugin-sdk**: Consumer API for building tools, renderers, and plugins without breaking core invariants.

## Quick Start

\`\`\`ts
import { CanvasEngine } from '@canvas-sdk/core';
const engine = new CanvasEngine();
engine.attach(document.getElementById('canvas'));
\`\`\`

## Features

- Infinite canvas with pan/zoom
- QuadTree spatial indexing for O(log n) hit testing
- Command pattern for full undo/redo support
- Plugin system for tools, renderers, and commands
- Z-Layer system with visibility control
- Node connections (bezier wires)
- 5 built-in themes (Midnight, Daylight, Carbon, Cyber, Paper)
- 8 tools: Select, Pan, Rectangle, Ellipse, Line, Text, Freehand, Connect

## License

MIT
`,

  'package.json': JSON.stringify({
    name: 'canvas-sdk', version: '1.0.0', private: true,
    workspaces: ['packages/*'],
    scripts: { dev: 'npx tsx app/playground.ts' },
  }, null, 2),

  'tsconfig.json': JSON.stringify({
    compilerOptions: { target: 'ES2020', module: 'ESNext', moduleResolution: 'bundler', strict: true, esModuleInterop: true },
    references: [{ path: 'packages/core' }, { path: 'packages/plugin-sdk' }],
  }, null, 2),
};

export function useDownloadSDK() {
  const [downloading, setDownloading] = useState(false);

  const download = useCallback(async () => {
    setDownloading(true);
    try {
      const zip = new JSZip();
      for (const [path, content] of Object.entries(SDK_FILES)) {
        zip.file(path, content);
      }
      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'canvas-sdk.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Download failed:', e);
    }
    setDownloading(false);
  }, []);

  return { download, downloading };
}