/* ============================================================
   @canvas-sdk/core — Typed Event Bus
   Decoupled pub/sub with typed listeners. Supports wildcard
   listeners and once-only subscriptions.
   ============================================================ */

type Listener<T = unknown> = (payload: T) => void;

export class EventBus {
  private listeners = new Map<string, Set<Listener>>();
  private onceMap = new Map<string, Set<Listener>>();
  private maxListeners = 100;

  on<T = unknown>(event: string, cb: Listener<T>): () => void {
    if (!this.listeners.has(event)) this.listeners.set(event, new Set());
    const set = this.listeners.get(event)!;
    if (set.size >= this.maxListeners) {
      console.warn(`[EventBus] Max listeners (${this.maxListeners}) reached for "${event}"`);
    }
    set.add(cb as Listener);
    return () => this.off(event, cb as Listener);
  }

  once<T = unknown>(event: string, cb: Listener<T>): () => void {
    if (!this.onceMap.has(event)) this.onceMap.set(event, new Set());
    this.onceMap.get(event)!.add(cb as Listener);
    return () => this.onceMap.delete(event) || this.onceMap.get(event)?.delete(cb as Listener);
  }

  off(event: string, cb: Listener): void {
    this.listeners.get(event)?.delete(cb);
    this.onceMap.get(event)?.delete(cb);
  }

  emit<T = unknown>(event: string, payload?: T): void {
    this.listeners.get(event)?.forEach(cb => {
      try { cb(payload); }
      catch (e) { console.error(`[EventBus] Error in listener for "${event}":`, e); }
    });
    // Wildcard listeners
    this.listeners.get('*')?.forEach(cb => {
      try { cb({ event, payload } as unknown as T); }
      catch (e) { console.error(`[EventBus] Error in wildcard listener:`, e); }
    });
    // Once listeners
    const onceSet = this.onceMap.get(event);
    if (onceSet) {
      onceSet.forEach(cb => {
        try { cb(payload); }
        catch (e) { console.error(`[EventBus] Error in once listener for "${event}":`, e); }
      });
      this.onceMap.delete(event);
    }
  }

  removeAll(event?: string): void {
    if (event) {
      this.listeners.delete(event);
      this.onceMap.delete(event);
    } else {
      this.listeners.clear();
      this.onceMap.clear();
    }
  }

  listenerCount(event: string): number {
    return (this.listeners.get(event)?.size ?? 0) + (this.onceMap.get(event)?.size ?? 0);
  }
}