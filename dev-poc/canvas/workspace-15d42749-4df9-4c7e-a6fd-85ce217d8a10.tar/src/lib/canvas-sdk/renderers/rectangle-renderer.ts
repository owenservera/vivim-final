// ============================================================
// Rectangle Renderer
// ============================================================

import { CanvasNode } from '../types';
import { NodeRenderer } from '../plugin-api';

export const rectangleRenderer: NodeRenderer = {
  type: 'rectangle',
  render(ctx: CanvasRenderingContext2D, node: CanvasNode): void {
    ctx.beginPath();
    ctx.rect(node.x, node.y, node.width, node.height);

    if (node.fill && node.fill !== 'transparent') {
      ctx.fillStyle = node.fill;
      ctx.fill();
    }
    if (node.strokeWidth > 0 && node.stroke && node.stroke !== 'transparent') {
      ctx.strokeStyle = node.stroke;
      ctx.lineWidth = node.strokeWidth;
      ctx.stroke();
    }
  },
};