// ============================================================
// Ellipse Renderer
// ============================================================

import { CanvasNode } from '../types';
import { NodeRenderer } from '../plugin-api';

export const ellipseRenderer: NodeRenderer = {
  type: 'ellipse',
  render(ctx: CanvasRenderingContext2D, node: CanvasNode): void {
    const cx = node.x + node.width / 2;
    const cy = node.y + node.height / 2;
    const rx = Math.abs(node.width) / 2;
    const ry = Math.abs(node.height) / 2;

    ctx.beginPath();
    ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);

    if (node.fill && node.fill !== 'transparent') {
      ctx.fillStyle = node.fill;
      ctx.fill();
    }
    if (node.strokeWidth > 0 && node.stroke && node.stroke !== 'transparent') {
      ctx.strokeStyle = node.stroke;
      ctx.lineWidth = node.strokeWidth;
      ctx.stroke();
    }
  },
};