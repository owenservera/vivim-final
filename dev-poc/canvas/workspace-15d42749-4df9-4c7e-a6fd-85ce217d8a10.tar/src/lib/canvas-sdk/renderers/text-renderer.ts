// ============================================================
// Text Renderer
// ============================================================

import { CanvasNode } from '../types';
import { NodeRenderer } from '../plugin-api';

export const textRenderer: NodeRenderer = {
  type: 'text',
  render(ctx: CanvasRenderingContext2D, node: CanvasNode): void {
    const d = node.data as { text: string; fontSize: number; fontFamily: string };
    if (!d.text) return;

    const fontSize = d.fontSize ?? 16;
    const fontFamily = d.fontFamily ?? 'Inter, system-ui, sans-serif';

    ctx.font = `${fontSize}px ${fontFamily}`;
    ctx.textBaseline = 'top';

    if (node.fill && node.fill !== 'transparent') {
      ctx.fillStyle = node.fill;
      ctx.fillText(d.text, node.x, node.y);
    }

    if (node.strokeWidth > 0 && node.stroke && node.stroke !== 'transparent') {
      ctx.strokeStyle = node.stroke;
      ctx.lineWidth = node.strokeWidth;
      ctx.strokeText(d.text, node.x, node.y);
    }

    // Update node dimensions to match text
    const metrics = ctx.measureText(d.text);
    node.width = metrics.width;
    node.height = fontSize * 1.2;
  },
};