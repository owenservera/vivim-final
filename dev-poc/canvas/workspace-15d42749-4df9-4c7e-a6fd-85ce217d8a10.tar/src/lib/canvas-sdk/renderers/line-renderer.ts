// ============================================================
// Line Renderer
// ============================================================

import { CanvasNode } from '../types';
import { NodeRenderer } from '../plugin-api';

export const lineRenderer: NodeRenderer = {
  type: 'line',
  render(ctx: CanvasRenderingContext2D, node: CanvasNode): void {
    const d = node.data as { x2: number; y2: number };
    if (d.x2 === undefined || d.y2 === undefined) return;

    ctx.beginPath();
    ctx.moveTo(node.x, node.y);
    ctx.lineTo(d.x2, d.y2);

    if (node.strokeWidth > 0 && node.stroke && node.stroke !== 'transparent') {
      ctx.strokeStyle = node.stroke;
      ctx.lineWidth = node.strokeWidth;
      ctx.lineCap = 'round';
      ctx.stroke();
    }
  },
};