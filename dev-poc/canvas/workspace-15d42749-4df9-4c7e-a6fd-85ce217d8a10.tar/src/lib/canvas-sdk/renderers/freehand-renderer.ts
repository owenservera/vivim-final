// ============================================================
// Freehand Renderer
// ============================================================

import { CanvasNode, Vec2 } from '../types';
import { NodeRenderer } from '../plugin-api';

export const freehandRenderer: NodeRenderer = {
  type: 'freehand',
  render(ctx: CanvasRenderingContext2D, node: CanvasNode): void {
    const d = node.data as { points: Vec2[] };
    if (!d.points || d.points.length < 2) return;

    ctx.beginPath();
    ctx.moveTo(d.points[0].x, d.points[0].y);

    // Smooth curve through points
    if (d.points.length === 2) {
      ctx.lineTo(d.points[1].x, d.points[1].y);
    } else {
      for (let i = 1; i < d.points.length - 1; i++) {
        const cp = d.points[i];
        const np = d.points[i + 1];
        const mx = (cp.x + np.x) / 2;
        const my = (cp.y + np.y) / 2;
        ctx.quadraticCurveTo(cp.x, cp.y, mx, my);
      }
      // Last point
      const last = d.points[d.points.length - 1];
      ctx.lineTo(last.x, last.y);
    }

    if (node.stroke && node.stroke !== 'transparent') {
      ctx.strokeStyle = node.stroke;
      ctx.lineWidth = node.strokeWidth;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.stroke();
    }
  },
};