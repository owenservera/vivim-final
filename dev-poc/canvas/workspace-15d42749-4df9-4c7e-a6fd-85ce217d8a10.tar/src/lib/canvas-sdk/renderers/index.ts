/* ============================================================
   Canvas SDK Node Renderers
   Each renderer knows how to paint one node type on the 2D
   canvas context. The engine calls these in the render loop.
   ============================================================ */

import type { Node, NodeRenderer } from '../plugin-api';

export const RectangleRenderer: NodeRenderer = {
  type: 'rectangle',
  render(ctx, node) {
    const { x, y, width, height } = node.boundingBox;
    const fill = (node.props.fill as string) || '#7c5cff';
    const stroke = (node.props.stroke as string) || '#4c3bc7';
    const sw = (node.props.strokeWidth as number) || 2;
    const opacity = (node.props.opacity as number) ?? 1;
    const cr = (node.props.cornerRadius as number) || 0;

    ctx.save();
    ctx.globalAlpha = opacity;
    if (cr > 0) {
      const r = Math.min(cr, width / 2, height / 2);
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.lineTo(x + width - r, y);
      ctx.quadraticCurveTo(x + width, y, x + width, y + r);
      ctx.lineTo(x + width, y + height - r);
      ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
      ctx.lineTo(x + r, y + height);
      ctx.quadraticCurveTo(x, y + height, x, y + height - r);
      ctx.lineTo(x, y + r);
      ctx.quadraticCurveTo(x, y, x + r, y);
      ctx.closePath();
      ctx.fillStyle = fill;
      ctx.fill();
      if (sw > 0) {
        ctx.strokeStyle = stroke;
        ctx.lineWidth = sw;
        ctx.stroke();
      }
    } else {
      ctx.fillStyle = fill;
      ctx.fillRect(x, y, width, height);
      if (sw > 0) {
        ctx.strokeStyle = stroke;
        ctx.lineWidth = sw;
        ctx.strokeRect(x, y, width, height);
      }
    }
    ctx.restore();
  },
};

export const EllipseRenderer: NodeRenderer = {
  type: 'ellipse',
  render(ctx, node) {
    const { x, y, width, height } = node.boundingBox;
    const fill = (node.props.fill as string) || '#2dd4bf';
    const stroke = (node.props.stroke as string) || '#0d9488';
    const sw = (node.props.strokeWidth as number) || 2;
    const opacity = (node.props.opacity as number) ?? 1;

    ctx.save();
    ctx.globalAlpha = opacity;
    ctx.beginPath();
    ctx.ellipse(
      x + width / 2, y + height / 2,
      Math.max(1, width / 2), Math.max(1, height / 2),
      0, 0, Math.PI * 2
    );
    ctx.fillStyle = fill;
    ctx.fill();
    if (sw > 0) {
      ctx.strokeStyle = stroke;
      ctx.lineWidth = sw;
      ctx.stroke();
    }
    ctx.restore();
  },
};

export const LineRenderer: NodeRenderer = {
  type: 'line',
  render(ctx, node) {
    const stroke = (node.props.stroke as string) || '#f59e0b';
    const sw = (node.props.strokeWidth as number) || 2;
    const x2 = (node.props.x2 as number) ?? node.boundingBox.x + node.boundingBox.width;
    const y2 = (node.props.y2 as number) ?? node.boundingBox.y + node.boundingBox.height;

    ctx.save();
    ctx.strokeStyle = stroke;
    ctx.lineWidth = sw;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(node.position.x, node.position.y);
    ctx.lineTo(x2, y2);
    ctx.stroke();
    ctx.restore();
  },
};

export const TextRenderer: NodeRenderer = {
  type: 'text',
  render(ctx, node) {
    const text = (node.props.text as string) || 'Text';
    const fontSize = (node.props.fontSize as number) || 16;
    const fill = (node.props.fill as string) || '#f5f7fb';
    const fontFamily = (node.props.fontFamily as string) || 'Inter, sans-serif';
    const fontWeight = (node.props.fontWeight as string) || '400';

    ctx.save();
    ctx.fillStyle = fill;
    ctx.font = `${fontWeight} ${fontSize}px ${fontFamily}`;
    ctx.textBaseline = 'top';
    ctx.fillText(text, node.position.x, node.position.y);

    // Update bounding box for hit testing
    const metrics = ctx.measureText(text);
    node.boundingBox.width = metrics.width;
    node.boundingBox.height = fontSize * 1.2;
    ctx.restore();
  },
};

export const FreehandRenderer: NodeRenderer = {
  type: 'freehand',
  render(ctx, node) {
    const points = (node.props.points as Array<{ x: number; y: number }>) || [];
    const stroke = (node.props.stroke as string) || '#f43f5e';
    const sw = (node.props.strokeWidth as number) || 2;

    if (points.length < 2) return;

    ctx.save();
    ctx.strokeStyle = stroke;
    ctx.lineWidth = sw;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) {
      const prev = points[i - 1];
      const curr = points[i];
      const mx = (prev.x + curr.x) / 2;
      const my = (prev.y + curr.y) / 2;
      ctx.quadraticCurveTo(prev.x, prev.y, mx, my);
    }
    const last = points[points.length - 1];
    ctx.lineTo(last.x, last.y);
    ctx.stroke();
    ctx.restore();
  },
};

export const ALL_RENDERERS: NodeRenderer[] = [
  RectangleRenderer,
  EllipseRenderer,
  LineRenderer,
  TextRenderer,
  FreehandRenderer,
];