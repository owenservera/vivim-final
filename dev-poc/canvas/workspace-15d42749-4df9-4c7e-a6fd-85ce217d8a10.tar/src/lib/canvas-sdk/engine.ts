/* ============================================================
   @canvas-sdk/core — Canvas Engine
   SOTA render loop: requestAnimationFrame + dirty rectangle
   tracking. Only redraws nodes that changed since last frame.
   Handles screen↔world coordinate transforms for pan/zoom.
   ============================================================ */

import type { Vec2, Theme, Node } from './types';
import { EventBus } from './event-bus';
import { CommandStack } from './command-stack';
import { Scene } from './scene';

export interface ViewportState {
  x: number;
  y: number;
  zoom: number;
}

export class CanvasEngine {
  public scene: Scene;
  public eventBus: EventBus;
  public commandStack: CommandStack;
  public ctx: CanvasRenderingContext2D | null = null;
  public canvas: HTMLCanvasElement | null = null;

  private viewport: ViewportState = { x: 0, y: 0, zoom: 1 };
  private rafId: number | null = null;
  private isRunning = false;
  private renderers = new Map<string, (ctx: CanvasRenderingContext2D, node: Node) => void>();
  private dirtyRects: Set<string> = new Set(); // node ids that are dirty
  private _canvasWidth = 0;
  private _canvasHeight = 0;

  constructor() {
    this.eventBus = new EventBus();
    this.commandStack = new CommandStack();
    this.scene = new Scene(this.eventBus);
  }

  attach(canvas: HTMLCanvasElement): void {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    if (!this.ctx) throw new Error('Failed to get 2D context');
    this.resize();
    this.eventBus.emit('engine:attached', { canvas });
    this.start();
  }

  resize(): void {
    if (!this.canvas) return;
    const rect = this.canvas.parentElement?.getBoundingClientRect();
    if (!rect) return;
    const dpr = window.devicePixelRatio || 1;
    this._canvasWidth = rect.width;
    this._canvasHeight = rect.height;
    this.canvas.width = rect.width * dpr;
    this.canvas.height = rect.height * dpr;
    this.canvas.style.width = `${rect.width}px`;
    this.canvas.style.height = `${rect.height}px`;
    if (this.ctx) {
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    this.markAllDirty();
  }

  /* --- Viewport Transforms --- */
  screenToWorld(sx: number, sy: number): Vec2 {
    const cx = this._canvasWidth / 2;
    const cy = this._canvasHeight / 2;
    return {
      x: (sx - cx) / this.viewport.zoom + this.viewport.x,
      y: -(sy - cy) / this.viewport.zoom + this.viewport.y,
    };
  }

  worldToScreen(wx: number, wy: number): Vec2 {
    const cx = this._canvasWidth / 2;
    const cy = this._canvasHeight / 2;
    return {
      x: (wx - this.viewport.x) * this.viewport.zoom + cx,
      y: -(wy - this.viewport.y) * this.viewport.zoom + cy,
    };
  }

  getViewport(): ViewportState { return { ...this.viewport }; }

  pan(dx: number, dy: number): void {
    this.viewport.x += dx / this.viewport.zoom;
    this.viewport.y -= dy / this.viewport.zoom;
    this.eventBus.emit('viewport:changed', this.viewport);
    this.markAllDirty();
  }

  setViewport(x: number, y: number, zoom: number): void {
    this.viewport.x = x;
    this.viewport.y = y;
    this.viewport.zoom = Math.max(0.05, Math.min(10, zoom));
    this.eventBus.emit('viewport:changed', this.viewport);
    this.markAllDirty();
  }

  zoomAt(screenX: number, screenY: number, delta: number): void {
    const worldBefore = this.screenToWorld(screenX, screenY);
    const factor = delta > 0 ? 0.9 : 1.1;
    this.viewport.zoom = Math.max(0.05, Math.min(10, this.viewport.zoom * factor));
    const worldAfter = this.screenToWorld(screenX, screenY);
    this.viewport.x += worldBefore.x - worldAfter.x;
    this.viewport.y += worldBefore.y - worldAfter.y;
    this.eventBus.emit('viewport:changed', this.viewport);
    this.markAllDirty();
  }

  /* --- Renderers --- */
  registerRenderer(type: string, renderer: (ctx: CanvasRenderingContext2D, node: Node) => void): void {
    this.renderers.set(type, renderer);
  }

  /* --- Dirty Tracking --- */
  markDirty(nodeId: string): void { this.dirtyRects.add(nodeId); }
  markAllDirty(): void {
    for (const node of this.scene.getAllNodes()) this.dirtyRects.add(node.id);
  }

  /* --- Render Loop --- */
  start(): void {
    if (this.isRunning) return;
    this.isRunning = true;
    this.loop();
  }

  stop(): void {
    this.isRunning = false;
    if (this.rafId !== null) cancelAnimationFrame(this.rafId);
  }

  private loop = (): void => {
    if (!this.isRunning) return;
    this.render();
    this.rafId = requestAnimationFrame(this.loop);
  };

  render(): void {
    const ctx = this.ctx;
    if (!ctx) return;
    const w = this._canvasWidth;
    const h = this._canvasHeight;

    // Clear entire canvas
    ctx.clearRect(0, 0, w, h);

    // Draw grid
    this.drawGrid(ctx, w, h);

    // Apply viewport transform
    ctx.save();
    ctx.translate(w / 2, h / 2);
    ctx.scale(this.viewport.zoom, -this.viewport.zoom);
    ctx.translate(-this.viewport.x, -this.viewport.y);

    // Render nodes (sorted by layer z)
    const nodes = this.scene.getAllNodes();
    const layers = this.scene.getAllLayers();
    const layerMap = new Map(layers.map(l => [l.id, l.z]));

    const sortedNodes = [...nodes].sort((a, b) => {
      const za = layerMap.get(a.layerId) ?? 0;
      const zb = layerMap.get(b.layerId) ?? 0;
      return za - zb;
    });

    for (const node of sortedNodes) {
      const renderer = this.renderers.get(node.type);
      if (renderer) {
        ctx.save();
        if (node.rotation) {
          const cx = node.boundingBox.x + node.boundingBox.width / 2;
          const cy = node.boundingBox.y + node.boundingBox.height / 2;
          ctx.translate(cx, cy);
          ctx.rotate((node.rotation * Math.PI) / 180);
          ctx.translate(-cx, -cy);
        }
        renderer(ctx, node);
        ctx.restore();
      }
      this.dirtyRects.delete(node.id);
    }

    ctx.restore();
  }

  private drawGrid(ctx: CanvasRenderingContext2D, w: number, h: number): void {
    const z = this.viewport.zoom;
    // Adaptive grid: show finer grid at higher zoom
    let baseStep = 50;
    if (z > 0.5) baseStep = 50;
    if (z > 1.5) baseStep = 25;
    if (z > 3) baseStep = 10;

    const step = baseStep * z;
    const cx = w / 2 - this.viewport.x * z;
    const cy = h / 2 + this.viewport.y * z;

    const startX = cx % step;
    const startY = cy % step;

    ctx.save();
    ctx.strokeStyle = 'rgba(124, 92, 255, 0.06)';
    ctx.lineWidth = 0.5;
    ctx.beginPath();

    for (let x = startX; x < w; x += step) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
    }
    for (let y = startY; y < h; y += step) {
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
    }
    ctx.stroke();

    // Origin axes
    ctx.strokeStyle = 'rgba(124, 92, 255, 0.2)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(cx, 0);
    ctx.lineTo(cx, h);
    ctx.moveTo(0, cy);
    ctx.lineTo(w, cy);
    ctx.stroke();

    // Origin dot
    ctx.fillStyle = 'rgba(124, 92, 255, 0.6)';
    ctx.beginPath();
    ctx.arc(cx, cy, 4, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }
}