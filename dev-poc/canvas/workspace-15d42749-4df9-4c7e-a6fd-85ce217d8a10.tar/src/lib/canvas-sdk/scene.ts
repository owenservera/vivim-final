/* ============================================================
   @canvas-sdk/core — Scene Graph
   Manages nodes, Z-layers, connections, and spatial queries
   via QuadTree. All mutations should ideally go through
   Commands (via CommandStack) to maintain undo/redo.
   ============================================================ */

import type { Node, Connection, ZLayer, BoundingBox, Vec2 } from './types';
import { QuadTree } from './quad-tree';
import { EventBus } from './event-bus';

const QT_BOUNDS: BoundingBox = { x: -50000, y: -50000, width: 100000, height: 100000 };

export class Scene {
  private nodes = new Map<string, Node>();
  private connections = new Map<string, Connection>();
  private layers = new Map<string, ZLayer>();
  private activeLayerId: string;
  private quadTree = new QuadTree<{ nodeId: string }>(QT_BOUNDS);
  private eventBus: EventBus;
  private qtDirty = true;

  constructor(eventBus: EventBus) {
    this.eventBus = eventBus;
    // Default layers
    this.addLayer({ id: 'base', z: 0, name: 'Base', visible: true, locked: false });
    this.addLayer({ id: 'overlay', z: 100, name: 'Overlay', visible: true, locked: false });
    this.addLayer({ id: 'hud', z: 200, name: 'HUD', visible: true, locked: false });
    this.activeLayerId = 'base';
  }

  /* --- Node CRUD --- */
  addNode(node: Node): void {
    this.nodes.set(node.id, node);
    this.markQTDirty();
    this.eventBus.emit('scene:node-added', node);
  }

  removeNode(id: string): Node | undefined {
    const node = this.nodes.get(id);
    if (!node) return undefined;
    this.nodes.delete(id);
    // Remove connections involving this node
    for (const [cid, conn] of this.connections) {
      if (conn.fromNodeId === id || conn.toNodeId === id) {
        this.connections.delete(cid);
      }
    }
    this.markQTDirty();
    this.eventBus.emit('scene:node-removed', node);
    return node;
  }

  getNode(id: string): Node | undefined { return this.nodes.get(id); }

  updateNode(id: string, patch: Partial<Node>): void {
    const node = this.nodes.get(id);
    if (!node) return;
    Object.assign(node, patch);
    node._dirty = true;
    this.markQTDirty();
    this.eventBus.emit('scene:node-updated', node);
  }

  getAllNodes(): Node[] {
    return Array.from(this.nodes.values()).filter(n => {
      const layer = this.layers.get(n.layerId);
      return layer?.visible !== false;
    });
  }

  getNodesByLayer(layerId: string): Node[] {
    return this.getAllNodes().filter(n => n.layerId === layerId);
  }

  /* --- Spatial Queries (via QuadTree) --- */
  private rebuildQT(): void {
    this.quadTree.clear();
    for (const [id, node] of this.nodes) {
      const layer = this.layers.get(node.layerId);
      if (layer?.visible === false) continue;
      this.quadTree.insert({ bb: node.boundingBox, data: { nodeId: id } });
    }
    this.qtDirty = false;
  }

  private markQTDirty(): void { this.qtDirty = true; }

  queryBoundingBox(bb: BoundingBox): Node[] {
    if (this.qtDirty) this.rebuildQT();
    const results = this.quadTree.queryBB(bb);
    return results.map(r => this.nodes.get(r.nodeId)!).filter(Boolean);
  }

  queryPoint(point: Vec2): Node[] {
    if (this.qtDirty) this.rebuildQT();
    const results = this.quadTree.queryPoint(point);
    // Return in reverse z-order (top-most first)
    return results
      .map(r => this.nodes.get(r.nodeId)!)
      .filter(Boolean)
      .sort((a, b) => {
        const la = this.layers.get(a.layerId)?.z ?? 0;
        const lb = this.layers.get(b.layerId)?.z ?? 0;
        return lb - la;
      });
  }

  hitTest(point: Vec2): Node | null {
    const hits = this.queryPoint(point);
    return hits[0] ?? null;
  }

  /* --- Connections --- */
  addConnection(conn: Connection): void {
    this.connections.set(conn.id, conn);
    this.eventBus.emit('scene:connection-added', conn);
  }

  removeConnection(id: string): void {
    const conn = this.connections.get(id);
    this.connections.delete(id);
    this.eventBus.emit('scene:connection-removed', conn);
  }

  getConnection(id: string): Connection | undefined { return this.connections.get(id); }
  getAllConnections(): Connection[] { return Array.from(this.connections.values()); }
  getConnectionsForNode(nodeId: string): Connection[] {
    return this.getAllConnections().filter(c => c.fromNodeId === nodeId || c.toNodeId === nodeId);
  }

  /* --- Z-Layers --- */
  addLayer(layer: ZLayer): void {
    this.layers.set(layer.id, layer);
    this.eventBus.emit('scene:layer-added', layer);
  }

  removeLayer(id: string): void {
    if (id === this.activeLayerId) return;
    this.layers.delete(id);
    this.eventBus.emit('scene:layer-removed', id);
  }

  getLayer(id: string): ZLayer | undefined { return this.layers.get(id); }
  getAllLayers(): ZLayer[] {
    return Array.from(this.layers.values()).sort((a, b) => a.z - b.z);
  }

  setActiveLayer(id: string): void {
    if (!this.layers.has(id)) return;
    this.activeLayerId = id;
    this.eventBus.emit('scene:active-layer-changed', id);
  }

  getActiveLayerId(): string { return this.activeLayerId; }
  getActiveLayer(): ZLayer | undefined { return this.layers.get(this.activeLayerId); }

  toggleLayerVisibility(id: string): void {
    const layer = this.layers.get(id);
    if (layer) {
      layer.visible = !layer.visible;
      this.eventBus.emit('scene:layer-toggled', layer);
    }
  }

  /* --- Utility --- */
  clear(): void {
    this.nodes.clear();
    this.connections.clear();
    this.quadTree.clear();
    this.eventBus.emit('scene:cleared');
  }

  get nodeCount(): number { return this.nodes.size; }
  get connectionCount(): number { return this.connections.size; }
  get layerCount(): number { return this.layers.size; }
}