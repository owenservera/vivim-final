// ============================================================
// Pan Tool — Drag to pan the canvas viewport
// ============================================================

import { BaseTool, ToolContext } from '../plugin-api';

export class PanTool implements BaseTool {
  id = 'pan';
  name = 'Pan';
  shortcut = 'P';
  cursor = 'grab';

  private ctx: ToolContext | null = null;
  private isPanning = false;
  private lastScreenX = 0;
  private lastScreenY = 0;

  activate(context: ToolContext): void {
    this.ctx = context;
  }

  deactivate(): void {
    this.ctx = null;
  }

  onMouseDown(e: { button: number; screenX: number; screenY: number }): void {
    if (!this.ctx || e.button !== 0) return;

    this.isPanning = true;
    this.lastScreenX = e.screenX;
    this.lastScreenY = e.screenY;
  }

  onMouseMove(e: { screenX: number; screenY: number }): void {
    if (!this.ctx || !this.isPanning) return;

    const vp = this.ctx.engine.getViewport();
    const dx = e.screenX - this.lastScreenX;
    const dy = e.screenY - this.lastScreenY;

    this.ctx.engine.setViewport({
      x: vp.x + dx,
      y: vp.y + dy,
      zoom: vp.zoom,
    });

    this.lastScreenX = e.screenX;
    this.lastScreenY = e.screenY;
  }

  onMouseUp(): void {
    this.isPanning = false;
  }
}