/* ============================================================
   Canvas SDK Tools — Select, Rectangle, Ellipse, Line,
   Text, Freehand, Pan, Connection
   ============================================================ */

import { v4 as uuid } from 'uuid';
import type { Node, BoundingBox, Vec2 } from '../core/types';
import type { ToolContext, BaseTool } from '../plugin-api';
import type { Command } from '../core/command-stack';

/* ---------- Helper: create an add-node command ---------- */
function makeAddNodeCmd(ctx: ToolContext, node: Node): Command {
  return {
    id: uuid(),
    description: `Add ${node.type}`,
    execute: () => ctx.engine.scene.addNode(node),
    undo: () => ctx.engine.scene.removeNode(node.id),
  };
}

/* ========== SELECT TOOL ========== */
export class SelectTool implements BaseTool {
  name = 'select';
  label = 'Select';
  cursor = 'default';
  private ctx!: ToolContext;
  private dragging = false;
  private dragStart: Vec2 | null = null;
  private dragNodeStart: Vec2 | null = null;
  private dragNodeId: string | null = null;

  activate(ctx: ToolContext) { this.ctx = ctx; this.dragging = false; }
  deactivate() { this.dragging = false; this.dragNodeId = null; }

  onMouseDown(e: PointerEvent) {
    const world = this.ctx.getMouseWorld();
    const hit = this.ctx.engine.scene.hitTest(world);
    if (hit) {
      this.dragNodeId = hit.id;
      this.dragStart = world;
      this.dragNodeStart = { ...hit.position };
      this.dragging = false; // becomes true on move
      this.ctx.selectNode(hit.id);
    } else {
      this.ctx.selectNode(null);
    }
  }

  onMouseMove(e: PointerEvent) {
    if (!this.dragNodeId || !this.dragStart || !this.dragNodeStart) return;
    const world = this.ctx.getMouseWorld();
    const dx = world.x - this.dragStart.x;
    const dy = world.y - this.dragStart.y;

    if (!this.dragging && (Math.abs(dx) > 2 || Math.abs(dy) > 2)) {
      this.dragging = true;
    }

    if (this.dragging) {
      const node = this.ctx.engine.scene.getNode(this.dragNodeId);
      if (node) {
        const newX = this.dragNodeStart.x + dx;
        const newY = this.dragNodeStart.y + dy;
        const bbDx = newX - node.position.x;
        const bbDy = newY - node.position.y;
        node.position = { x: newX, y: newY };
        node.boundingBox.x += bbDx;
        node.boundingBox.y += bbDy;
        this.ctx.engine.markDirty(node.id);
        this.ctx.engine.eventBus.emit('selection:moved', node);
      }
    }
  }

  onMouseUp(e: PointerEvent) {
    if (this.dragging && this.dragNodeId && this.dragStart && this.dragNodeStart) {
      const node = this.ctx.engine.scene.getNode(this.dragNodeId);
      if (node) {
        const world = this.ctx.getMouseWorld();
        const newX = this.dragNodeStart.x + (world.x - this.dragStart.x);
        const newY = this.dragNodeStart.y + (world.y - this.dragStart.y);
        const finalX = node.position.x;
        const finalY = node.position.y;
        // Wrap in command for undo
        const nodeId = this.dragNodeId;
        this.ctx.engine.commandStack.execute({
          id: uuid(),
          description: `Move ${node.type}`,
          execute: () => {
            const n = this.ctx.engine.scene.getNode(nodeId);
            if (n) {
              n.position = { x: finalX, y: finalY };
              n.boundingBox.x += finalX - this.dragNodeStart.x;
              n.boundingBox.y += finalY - this.dragNodeStart.y;
              this.ctx.engine.markDirty(nodeId);
            }
          },
          undo: () => {
            const n = this.ctx.engine.scene.getNode(nodeId);
            if (n) {
              n.position = { ...this.dragNodeStart };
              n.boundingBox.x -= finalX - this.dragNodeStart.x;
              n.boundingBox.y -= finalY - this.dragNodeStart.y;
              this.ctx.engine.markDirty(nodeId);
            }
          },
        });
      }
    }
    this.dragging = false;
    this.dragNodeId = null;
    this.dragStart = null;
    this.dragNodeStart = null;
  }

  onKeyDown(e: KeyboardEvent) {
    if (e.key === 'Delete' || e.key === 'Backspace') {
      const nodeId = this.ctx.getSelectedNodeId();
      if (nodeId) {
        const node = this.ctx.engine.scene.getNode(nodeId);
        if (node) {
          this.ctx.engine.commandStack.execute({
            id: uuid(),
            description: `Delete ${node.type}`,
            execute: () => { this.ctx.engine.scene.removeNode(nodeId); this.ctx.selectNode(null); },
            undo: () => { this.ctx.engine.scene.addNode(node); this.ctx.selectNode(nodeId); },
          });
        }
      }
    }
  }
}

/* ========== RECTANGLE TOOL ========== */
export class RectangleTool implements BaseTool {
  name = 'rectangle';
  label = 'Rectangle';
  cursor = 'crosshair';
  private ctx!: ToolContext;
  private startPoint: Vec2 | null = null;
  private tempNodeId: string | null = null;

  activate(ctx: ToolContext) { this.ctx = ctx; }
  deactivate() { this.startPoint = null; this.tempNodeId = null; }

  onMouseDown(e: PointerEvent) {
    const pos = this.ctx.getMouseWorld();
    this.startPoint = pos;
    this.tempNodeId = uuid();
    const node: Node = {
      id: this.tempNodeId,
      type: 'rectangle',
      position: { ...pos },
      rotation: 0,
      boundingBox: { x: pos.x, y: pos.y, width: 0, height: 0 },
      props: { fill: '#7c5cff', stroke: '#4c3bc7', strokeWidth: 2, opacity: 1, cornerRadius: 0 },
      layerId: this.ctx.engine.scene.getActiveLayerId(),
      documentation: 'A rectangle primitive. Supports fill, stroke, corner radius, and opacity.',
      editableProps: {
        fill: { type: 'color', label: 'Fill Color' },
        stroke: { type: 'color', label: 'Stroke Color' },
        strokeWidth: { type: 'number', label: 'Stroke Width', min: 0, max: 20 },
        opacity: { type: 'number', label: 'Opacity', min: 0, max: 1 },
        cornerRadius: { type: 'number', label: 'Corner Radius', min: 0, max: 100 },
      },
    };
    this.ctx.engine.scene.addNode(node);
    this.ctx.selectNode(this.tempNodeId);
  }

  onMouseMove(e: PointerEvent) {
    if (!this.startPoint || !this.tempNodeId) return;
    const current = this.ctx.getMouseWorld();
    const node = this.ctx.engine.scene.getNode(this.tempNodeId);
    if (node) {
      node.boundingBox = {
        x: Math.min(this.startPoint.x, current.x),
        y: Math.min(this.startPoint.y, current.y),
        width: Math.abs(current.x - this.startPoint.x),
        height: Math.abs(current.y - this.startPoint.y),
      };
      node.position = { x: node.boundingBox.x, y: node.boundingBox.y };
      this.ctx.engine.markDirty(this.tempNodeId);
    }
  }

  onMouseUp(e: PointerEvent) {
    if (this.tempNodeId) {
      const node = this.ctx.engine.scene.getNode(this.tempNodeId);
      // The node was already added; wrap removal as undo command
      if (node && node.boundingBox.width < 3 && node.boundingBox.height < 3) {
        // Too small, remove
        this.ctx.engine.scene.removeNode(this.tempNodeId);
        this.ctx.selectNode(null);
      }
    }
    this.startPoint = null;
    this.tempNodeId = null;
  }
}

/* ========== ELLIPSE TOOL ========== */
export class EllipseTool implements BaseTool {
  name = 'ellipse';
  label = 'Ellipse';
  cursor = 'crosshair';
  private ctx!: ToolContext;
  private startPoint: Vec2 | null = null;
  private tempNodeId: string | null = null;

  activate(ctx: ToolContext) { this.ctx = ctx; }
  deactivate() { this.startPoint = null; this.tempNodeId = null; }

  onMouseDown(e: PointerEvent) {
    const pos = this.ctx.getMouseWorld();
    this.startPoint = pos;
    this.tempNodeId = uuid();
    const node: Node = {
      id: this.tempNodeId,
      type: 'ellipse',
      position: { ...pos },
      rotation: 0,
      boundingBox: { x: pos.x, y: pos.y, width: 0, height: 0 },
      props: { fill: '#2dd4bf', stroke: '#0d9488', strokeWidth: 2, opacity: 1 },
      layerId: this.ctx.engine.scene.getActiveLayerId(),
      documentation: 'An ellipse primitive drawn inside its bounding box.',
      editableProps: {
        fill: { type: 'color', label: 'Fill Color' },
        stroke: { type: 'color', label: 'Stroke Color' },
        strokeWidth: { type: 'number', label: 'Stroke Width', min: 0, max: 20 },
        opacity: { type: 'number', label: 'Opacity', min: 0, max: 1 },
      },
    };
    this.ctx.engine.scene.addNode(node);
    this.ctx.selectNode(this.tempNodeId);
  }

  onMouseMove(e: PointerEvent) {
    if (!this.startPoint || !this.tempNodeId) return;
    const current = this.ctx.getMouseWorld();
    const node = this.ctx.engine.scene.getNode(this.tempNodeId);
    if (node) {
      node.boundingBox = {
        x: Math.min(this.startPoint.x, current.x),
        y: Math.min(this.startPoint.y, current.y),
        width: Math.abs(current.x - this.startPoint.x),
        height: Math.abs(current.y - this.startPoint.y),
      };
      node.position = { x: node.boundingBox.x, y: node.boundingBox.y };
      this.ctx.engine.markDirty(this.tempNodeId);
    }
  }

  onMouseUp(e: PointerEvent) {
    if (this.tempNodeId) {
      const node = this.ctx.engine.scene.getNode(this.tempNodeId);
      if (node && node.boundingBox.width < 3 && node.boundingBox.height < 3) {
        this.ctx.engine.scene.removeNode(this.tempNodeId);
        this.ctx.selectNode(null);
      }
    }
    this.startPoint = null;
    this.tempNodeId = null;
  }
}

/* ========== LINE TOOL ========== */
export class LineTool implements BaseTool {
  name = 'line';
  label = 'Line';
  cursor = 'crosshair';
  private ctx!: ToolContext;
  private startPoint: Vec2 | null = null;
  private tempNodeId: string | null = null;

  activate(ctx: ToolContext) { this.ctx = ctx; }
  deactivate() { this.startPoint = null; this.tempNodeId = null; }

  onMouseDown(e: PointerEvent) {
    const pos = this.ctx.getMouseWorld();
    this.startPoint = pos;
    this.tempNodeId = uuid();
    const node: Node = {
      id: this.tempNodeId,
      type: 'line',
      position: { ...pos },
      rotation: 0,
      boundingBox: { x: pos.x, y: pos.y, width: 0, height: 0 },
      props: { stroke: '#f59e0b', strokeWidth: 2, x2: pos.x, y2: pos.y },
      layerId: this.ctx.engine.scene.getActiveLayerId(),
      documentation: 'A straight line from point A to point B.',
      editableProps: {
        stroke: { type: 'color', label: 'Color' },
        strokeWidth: { type: 'number', label: 'Width', min: 1, max: 20 },
      },
    };
    this.ctx.engine.scene.addNode(node);
    this.ctx.selectNode(this.tempNodeId);
  }

  onMouseMove(e: PointerEvent) {
    if (!this.startPoint || !this.tempNodeId) return;
    const current = this.ctx.getMouseWorld();
    const node = this.ctx.engine.scene.getNode(this.tempNodeId);
    if (node) {
      node.props.x2 = current.x;
      node.props.y2 = current.y;
      node.boundingBox = {
        x: Math.min(this.startPoint.x, current.x),
        y: Math.min(this.startPoint.y, current.y),
        width: Math.abs(current.x - this.startPoint.x),
        height: Math.abs(current.y - this.startPoint.y),
      };
      this.ctx.engine.markDirty(this.tempNodeId);
    }
  }

  onMouseUp(e: PointerEvent) {
    if (this.tempNodeId) {
      const node = this.ctx.engine.scene.getNode(this.tempNodeId);
      if (node && node.boundingBox.width < 3 && node.boundingBox.height < 3) {
        this.ctx.engine.scene.removeNode(this.tempNodeId);
        this.ctx.selectNode(null);
      }
    }
    this.startPoint = null;
    this.tempNodeId = null;
  }
}

/* ========== TEXT TOOL ========== */
export class TextTool implements BaseTool {
  name = 'text';
  label = 'Text';
  cursor = 'text';
  private ctx!: ToolContext;

  activate(ctx: ToolContext) { this.ctx = ctx; }
  deactivate() {}

  onMouseDown(e: PointerEvent) {
    const pos = this.ctx.getMouseWorld();
    const nodeId = uuid();
    const text = 'Text';
    const node: Node = {
      id: nodeId,
      type: 'text',
      position: { ...pos },
      rotation: 0,
      boundingBox: { x: pos.x, y: pos.y, width: 100, height: 30 },
      props: { text, fontSize: 16, fill: '#f5f7fb', fontFamily: 'Inter, sans-serif', fontWeight: '400' },
      layerId: this.ctx.engine.scene.getActiveLayerId(),
      documentation: 'A text node. Edit the text content, font size, and color.',
      editableProps: {
        text: { type: 'string', label: 'Text' },
        fontSize: { type: 'number', label: 'Font Size', min: 8, max: 120 },
        fill: { type: 'color', label: 'Color' },
        fontWeight: { type: 'select', label: 'Weight', options: ['300', '400', '500', '600', '700'] },
      },
    };
    this.ctx.engine.scene.addNode(node);
    this.ctx.selectNode(nodeId);
  }
}

/* ========== FREEHAND TOOL ========== */
export class FreehandTool implements BaseTool {
  name = 'freehand';
  label = 'Freehand';
  cursor = 'crosshair';
  private ctx!: ToolContext;
  private tempNodeId: string | null = null;
  private points: Vec2[] = [];

  activate(ctx: ToolContext) { this.ctx = ctx; }
  deactivate() { this.tempNodeId = null; this.points = []; }

  onMouseDown(e: PointerEvent) {
    const pos = this.ctx.getMouseWorld();
    this.points = [pos];
    this.tempNodeId = uuid();
    const node: Node = {
      id: this.tempNodeId,
      type: 'freehand',
      position: { ...pos },
      rotation: 0,
      boundingBox: { x: pos.x, y: pos.y, width: 1, height: 1 },
      props: { stroke: '#f43f5e', strokeWidth: 2, points: [...this.points] },
      layerId: this.ctx.engine.scene.getActiveLayerId(),
      documentation: 'A freehand drawing. Points are captured during mouse drag.',
      editableProps: {
        stroke: { type: 'color', label: 'Color' },
        strokeWidth: { type: 'number', label: 'Width', min: 1, max: 20 },
      },
    };
    this.ctx.engine.scene.addNode(node);
  }

  onMouseMove(e: PointerEvent) {
    if (!this.tempNodeId) return;
    const pos = this.ctx.getMouseWorld();
    this.points.push(pos);
    const node = this.ctx.engine.scene.getNode(this.tempNodeId);
    if (node) {
      node.props.points = [...this.points];
      // Recompute bounding box
      let minX = pos.x, minY = pos.y, maxX = pos.x, maxY = pos.y;
      for (const p of this.points) {
        if (p.x < minX) minX = p.x;
        if (p.y < minY) minY = p.y;
        if (p.x > maxX) maxX = p.x;
        if (p.y > maxY) maxY = p.y;
      }
      node.boundingBox = { x: minX, y: minY, width: maxX - minX, height: maxY - minY };
      this.ctx.engine.markDirty(this.tempNodeId);
    }
  }

  onMouseUp(e: PointerEvent) {
    this.tempNodeId = null;
    this.points = [];
  }
}

/* ========== PAN TOOL ========== */
export class PanTool implements BaseTool {
  name = 'pan';
  label = 'Pan';
  cursor = 'grab';
  private ctx!: ToolContext;
  private isPanning = false;
  private lastScreen: Vec2 | null = null;

  activate(ctx: ToolContext) { this.ctx = ctx; }
  deactivate() { this.isPanning = false; }

  onMouseDown(e: PointerEvent) {
    this.isPanning = true;
    this.lastScreen = { x: e.clientX, y: e.clientY };
  }

  onMouseMove(e: PointerEvent) {
    if (!this.isPanning || !this.lastScreen) return;
    const dx = e.clientX - this.lastScreen.x;
    const dy = e.clientY - this.lastScreen.y;
    this.ctx.engine.pan(dx, dy);
    this.lastScreen = { x: e.clientX, y: e.clientY };
  }

  onMouseUp(e: PointerEvent) {
    this.isPanning = false;
    this.lastScreen = null;
  }
}

/* ========== CONNECTION TOOL ========== */
export class ConnectionTool implements BaseTool {
  name = 'connection';
  label = 'Connect';
  cursor = 'crosshair';
  private ctx!: ToolContext;
  private fromNodeId: string | null = null;
  private fromPos: Vec2 | null = null;

  activate(ctx: ToolContext) { this.ctx = ctx; }
  deactivate() { this.fromNodeId = null; this.fromPos = null; }

  onMouseDown(e: PointerEvent) {
    const world = this.ctx.getMouseWorld();
    const hit = this.ctx.engine.scene.hitTest(world);
    if (hit) {
      this.fromNodeId = hit.id;
      this.fromPos = {
        x: hit.boundingBox.x + hit.boundingBox.width / 2,
        y: hit.boundingBox.y + hit.boundingBox.height / 2,
      };
    }
  }

  onMouseMove(e: PointerEvent) {
    // Could draw a temp line, but we'll skip for now
  }

  onMouseUp(e: PointerEvent) {
    if (!this.fromNodeId) return;
    const world = this.ctx.getMouseWorld();
    const hit = this.ctx.engine.scene.hitTest(world);
    if (hit && hit.id !== this.fromNodeId) {
      const connId = uuid();
      this.ctx.engine.scene.addConnection({
        id: connId,
        fromNodeId: this.fromNodeId,
        toNodeId: hit.id,
        color: '#7c5cff',
      });
      this.ctx.engine.eventBus.emit('connection:created', connId);
    }
    this.fromNodeId = null;
    this.fromPos = null;
  }
}

export const ALL_TOOLS: BaseTool[] = [
  new SelectTool(),
  new PanTool(),
  new RectangleTool(),
  new EllipseTool(),
  new LineTool(),
  new TextTool(),
  new FreehandTool(),
  new ConnectionTool(),
];