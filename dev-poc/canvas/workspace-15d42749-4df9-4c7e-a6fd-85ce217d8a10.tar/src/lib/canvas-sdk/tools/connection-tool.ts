// ============================================================
// Connection Tool — Click+drag between nodes to create bezier wire
// ============================================================

import { v4 as uuidv4 } from 'uuid';
import { BaseTool, ToolContext } from '../plugin-api';

export class ConnectionTool implements BaseTool {
  id = 'connection';
  name = 'Connection';
  shortcut = 'C';
  cursor = 'crosshair';

  private ctx: ToolContext | null = null;
  private sourceNode: string | null = null;
  private previewEnd: { x: number; y: number } | null = null;

  activate(context: ToolContext): void {
    this.ctx = context;
  }

  deactivate(): void {
    this.ctx = null;
    this.sourceNode = null;
    this.previewEnd = null;
  }

  onMouseDown(e: { button: number; worldX: number; worldY: number; shiftKey: boolean }): void {
    if (!this.ctx || e.button !== 0) return;

    const hit = this.ctx.scene.hitTest({ x: e.worldX, y: e.worldY });
    if (hit) {
      if (!this.sourceNode) {
        this.sourceNode = hit.id;
      } else if (hit.id !== this.sourceNode) {
        // Create connection
        const sourceId = this.sourceNode;
        const targetId = hit.id;
        this.ctx.scene.addConnection(sourceId, targetId);
        this.ctx.engine.requestRedraw();
        this.sourceNode = null;
      }
    } else {
      this.sourceNode = null;
    }
  }

  onMouseMove(e: { worldX: number; worldY: number }): void {
    if (!this.ctx) return;
    if (this.sourceNode) {
      this.previewEnd = { x: e.worldX, y: e.worldY };
      this.ctx.engine.requestRedraw();
    }
  }

  onMouseUp(): void {
    this.previewEnd = null;
  }
}