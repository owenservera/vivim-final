// ============================================================
// Select Tool — Click to select, drag to move, resize handles
// ============================================================

import { v4 as uuidv4 } from 'uuid';
import { BaseTool, ToolContext } from '../plugin-api';
import { CanvasNode, Vec2 } from '../types';

export class SelectTool implements BaseTool {
  id = 'select';
  name = 'Select';
  shortcut = 'V';
  cursor = 'default';

  private ctx: ToolContext | null = null;
  private isDragging = false;
  private isResizing = false;
  private resizeHandle: number = -1;
  private dragStart: Vec2 = { x: 0, y: 0 };
  private nodeStartPositions = new Map<string, { x: number; y: number; w: number; h: number }>();
  private hasMoved = false;

  activate(context: ToolContext): void {
    this.ctx = context;
  }

  deactivate(): void {
    this.ctx = null;
    this.isDragging = false;
    this.isResizing = false;
  }

  onMouseDown(e: { button: number; worldX: number; worldY: number; shiftKey: boolean; ctrlKey: boolean }): void {
    if (!this.ctx || e.button !== 0) return;
    const { scene, commandStack } = this.ctx;

    // Check resize handles first
    const selectedNodes = scene.getSelectedNodes();
    if (selectedNodes.length === 1) {
      const handle = this.hitTestHandles(e.worldX, e.worldY, selectedNodes[0]);
      if (handle >= 0) {
        this.isResizing = true;
        this.resizeHandle = handle;
        const node = selectedNodes[0];
        this.nodeStartPositions.set(node.id, { x: node.x, y: node.y, w: node.width, h: node.height });
        this.dragStart = { x: e.worldX, y: e.worldY };
        return;
      }
    }

    // Hit test for node selection
    const hit = scene.hitTest({ x: e.worldX, y: e.worldY });

    if (hit) {
      if (e.shiftKey) {
        // Toggle selection
        const sel = scene.getSelectedIds();
        if (sel.has(hit.id)) {
          scene.removeFromSelection(hit.id);
        } else {
          scene.addToSelection(hit.id);
        }
      } else if (!scene.getSelectedIds().has(hit.id)) {
        scene.selectNode(hit.id);
      }

      // Start dragging
      this.isDragging = true;
      this.hasMoved = false;
      this.dragStart = { x: e.worldX, y: e.worldY };

      const selNodes = scene.getSelectedNodes();
      for (const n of selNodes) {
        this.nodeStartPositions.set(n.id, { x: n.x, y: n.y, w: n.width, h: n.height });
      }
    } else {
      if (!e.shiftKey) {
        scene.clearSelection();
      }
    }

    this.ctx.engine.requestRedraw();
  }

  onMouseMove(e: { worldX: number; worldY: number }): void {
    if (!this.ctx) return;
    const { scene, commandStack, engine } = this.ctx;
    const dx = e.worldX - this.dragStart.x;
    const dy = e.worldY - this.dragStart.y;

    if (this.isDragging && this.nodeStartPositions.size > 0) {
      this.hasMoved = true;
      for (const node of scene.getSelectedNodes()) {
        const start = this.nodeStartPositions.get(node.id);
        if (start) {
          scene.updateNode(node.id, {
            x: start.x + dx,
            y: start.y + dy,
          });
        }
      }
      engine.requestRedraw();
    } else if (this.isResizing && this.nodeStartPositions.size > 0) {
      const selNodes = scene.getSelectedNodes();
      const node = selNodes[0];
      const start = this.nodeStartPositions.get(node.id);
      if (!start) return;

      let newX = start.x;
      let newY = start.y;
      let newW = start.w;
      let newH = start.h;

      switch (this.resizeHandle) {
        case 0: // top-left
          newX = start.x + dx; newY = start.y + dy;
          newW = start.w - dx; newH = start.h - dy;
          break;
        case 1: // top-right
          newY = start.y + dy;
          newW = start.w + dx; newH = start.h - dy;
          break;
        case 2: // bottom-left
          newX = start.x + dx;
          newW = start.w - dx; newH = start.h + dy;
          break;
        case 3: // bottom-right
          newW = start.w + dx; newH = start.h + dy;
          break;
      }

      // Ensure minimum size
      if (newW < 10) { newW = 10; }
      if (newH < 10) { newH = 10; }

      scene.updateNode(node.id, { x: newX, y: newY, width: newW, height: newH });
      engine.requestRedraw();
    }
  }

  onMouseUp(): void {
    if (!this.ctx) return;
    const { scene, commandStack } = this.ctx;

    if (this.isDragging && this.hasMoved && this.nodeStartPositions.size > 0) {
      // Create move command for undo/redo
      const currentNodes = scene.getSelectedNodes();
      const startPositions = new Map(this.nodeStartPositions);
      const nodeIds = currentNodes.map(n => n.id);

      commandStack.execute({
        id: uuidv4(),
        label: 'Move Node',
        execute: () => {
          for (const node of scene.getSelectedNodes()) {
            // Already moved
          }
        },
        undo: () => {
          for (const id of nodeIds) {
            const start = startPositions.get(id);
            if (start) {
              scene.updateNode(id, { x: start.x, y: start.y });
            }
          }
        },
      });
    }

    if (this.isResizing && this.nodeStartPositions.size > 0) {
      const selNodes = scene.getSelectedNodes();
      const node = selNodes[0];
      const start = this.nodeStartPositions.get(node.id);
      if (start) {
        const oldState = { x: start.x, y: start.y, w: start.w, h: start.h };
        const newState = { x: node.x, y: node.y, w: node.width, h: node.height };
        const nodeId = node.id;

        commandStack.execute({
          id: uuidv4(),
          label: 'Resize Node',
          execute: () => { /* Already resized */ },
          undo: () => {
            scene.updateNode(nodeId, { x: oldState.x, y: oldState.y, width: oldState.w, height: oldState.h });
          },
        });
      }
    }

    this.isDragging = false;
    this.isResizing = false;
    this.resizeHandle = -1;
    this.nodeStartPositions.clear();
    this.ctx.engine.requestRedraw();
  }

  onKeyDown(e: { key: string; ctrlKey: boolean; shiftKey: boolean }): void {
    if (!this.ctx) return;
    const { scene, commandStack } = this.ctx;

    if (e.key === 'Delete' || e.key === 'Backspace') {
      const selectedNodes = scene.getSelectedNodes();
      if (selectedNodes.length === 0) return;

      const removed = selectedNodes.map(n => ({ ...n, data: { ...n.data } }));
      commandStack.execute({
        id: uuidv4(),
        label: `Delete ${selectedNodes.length} node(s)`,
        execute: () => {
          for (const n of removed) {
            scene.removeNode(n.id);
          }
          scene.clearSelection();
        },
        undo: () => {
          for (const n of removed) {
            scene.addNode(n);
          }
        },
      });
      this.ctx.engine.requestRedraw();
    }

    if (e.ctrlKey && e.key === 'a') {
      e.ctrlKey = false; // prevent browser default
      scene.selectAll();
      this.ctx.engine.requestRedraw();
    }
  }

  private hitTestHandles(wx: number, wy: number, node: CanvasNode): number {
    const handleSize = 8 / (this.ctx?.engine.getViewport().zoom ?? 1);
    const bounds = { x: node.x, y: node.y, w: node.width, h: node.height };
    const handles = [
      { x: bounds.x, y: bounds.y },
      { x: bounds.x + bounds.w, y: bounds.y },
      { x: bounds.x, y: bounds.y + bounds.h },
      { x: bounds.x + bounds.w, y: bounds.y + bounds.h },
    ];

    for (let i = 0; i < handles.length; i++) {
      const h = handles[i];
      if (
        Math.abs(wx - h.x) <= handleSize &&
        Math.abs(wy - h.y) <= handleSize
      ) {
        return i;
      }
    }
    return -1;
  }
}