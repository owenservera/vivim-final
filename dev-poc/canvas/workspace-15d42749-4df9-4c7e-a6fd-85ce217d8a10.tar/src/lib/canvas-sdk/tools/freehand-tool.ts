// ============================================================
// Freehand/Pen Tool — Draw freehand paths
// ============================================================

import { v4 as uuidv4 } from 'uuid';
import { BaseTool, ToolContext } from '../plugin-api';
import { Vec2 } from '../types';

export class FreehandTool implements BaseTool {
  id = 'freehand';
  name = 'Freehand';
  shortcut = 'F';
  cursor = 'crosshair';

  private ctx: ToolContext | null = null;
  private isDrawing = false;
  private previewNode: string | null = null;
  private points: Vec2[] = [];

  activate(context: ToolContext): void {
    this.ctx = context;
  }

  deactivate(): void {
    if (this.previewNode && this.ctx) {
      this.ctx.scene.removeNode(this.previewNode);
      this.ctx.engine.requestRedraw();
    }
    this.ctx = null;
    this.previewNode = null;
    this.points = [];
  }

  onMouseDown(e: { button: number; worldX: number; worldY: number }): void {
    if (!this.ctx || e.button !== 0) return;

    this.isDrawing = true;
    this.points = [{ x: e.worldX, y: e.worldY }];

    const node = this.ctx.scene.addNode({
      type: 'freehand',
      x: e.worldX,
      y: e.worldY,
      width: 0,
      height: 0,
      fill: 'transparent',
      stroke: this.ctx.options.strokeColor ?? '#2dd4bf',
      strokeWidth: this.ctx.options.strokeWidth ?? 3,
      data: { points: [...this.points] },
    });
    this.previewNode = node.id;
  }

  onMouseMove(e: { worldX: number; worldY: number }): void {
    if (!this.ctx || !this.isDrawing || !this.previewNode) return;

    this.points.push({ x: e.worldX, y: e.worldY });

    // Simplify points (keep every nth point based on distance)
    const simplified = this.simplifyPoints(this.points, 2);
    this.ctx.scene.updateNode(this.previewNode, {
      data: { points: simplified },
    });
    this.ctx.engine.requestRedraw();
  }

  onMouseUp(): void {
    if (!this.ctx || !this.isDrawing || !this.previewNode) return;

    const node = this.ctx.scene.getNode(this.previewNode);
    this.previewNode = null;
    this.isDrawing = false;

    if (node && this.points.length > 2) {
      const nodeId = node.id;
      const nodeData = { ...node, data: { ...node.data, points: [...this.points] } };

      this.ctx.commandStack.execute({
        id: uuidv4(),
        label: 'Add Freehand Path',
        execute: () => { this.ctx.scene.addNode(nodeData); },
        undo: () => { this.ctx.scene.removeNode(nodeId); },
      });

      this.ctx.scene.selectNode(nodeId);
    } else if (node) {
      this.ctx.scene.removeNode(node.id);
    }

    this.points = [];
    this.ctx.engine.requestRedraw();
  }

  private simplifyPoints(points: Vec2[], minDist: number): Vec2[] {
    if (points.length < 2) return points;
    const result: Vec2[] = [points[0]];
    for (let i = 1; i < points.length; i++) {
      const last = result[result.length - 1];
      if (Math.hypot(points[i].x - last.x, points[i].y - last.y) >= minDist) {
        result.push(points[i]);
      }
    }
    // Always include last point
    const lastPoint = points[points.length - 1];
    const lastResult = result[result.length - 1];
    if (lastPoint.x !== lastResult.x || lastPoint.y !== lastResult.y) {
      result.push(lastPoint);
    }
    return result;
  }
}