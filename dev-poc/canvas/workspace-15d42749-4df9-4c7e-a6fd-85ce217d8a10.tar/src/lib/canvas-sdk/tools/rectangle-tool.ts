// ============================================================
// Rectangle Tool — Click+drag to draw rectangles
// ============================================================

import { v4 as uuidv4 } from 'uuid';
import { BaseTool, ToolContext } from '../plugin-api';

export class RectangleTool implements BaseTool {
  id = 'rectangle';
  name = 'Rectangle';
  shortcut = 'R';
  cursor = 'crosshair';

  private ctx: ToolContext | null = null;
  private isDrawing = false;
  private startX = 0;
  private startY = 0;
  private previewNode: string | null = null;

  activate(context: ToolContext): void {
    this.ctx = context;
  }

  deactivate(): void {
    if (this.previewNode && this.ctx) {
      this.ctx.scene.removeNode(this.previewNode);
      this.ctx.engine.requestRedraw();
    }
    this.ctx = null;
    this.previewNode = null;
  }

  onMouseDown(e: { button: number; worldX: number; worldY: number }): void {
    if (!this.ctx || e.button !== 0) return;

    this.isDrawing = true;
    this.startX = e.worldX;
    this.startY = e.worldY;

    const node = this.ctx.scene.addNode({
      type: 'rectangle',
      x: e.worldX,
      y: e.worldY,
      width: 0,
      height: 0,
      fill: this.ctx.options.fillColor ?? '#7c5cff',
      stroke: this.ctx.options.strokeColor ?? '#ffffff',
      strokeWidth: this.ctx.options.strokeWidth ?? 2,
    });
    this.previewNode = node.id;
  }

  onMouseMove(e: { worldX: number; worldY: number }): void {
    if (!this.ctx || !this.isDrawing || !this.previewNode) return;

    const x = Math.min(this.startX, e.worldX);
    const y = Math.min(this.startY, e.worldY);
    const w = Math.abs(e.worldX - this.startX);
    const h = Math.abs(e.worldY - this.startY);

    this.ctx.scene.updateNode(this.previewNode, { x, y, width: w, height: h });
    this.ctx.engine.requestRedraw();
  }

  onMouseUp(): void {
    if (!this.ctx || !this.isDrawing || !this.previewNode) return;

    const node = this.ctx.scene.getNode(this.previewNode);
    this.previewNode = null;
    this.isDrawing = false;

    if (node && node.width > 2 && node.height > 2) {
      // Keep the node — already added via scene.addNode in onMouseDown
      // But we need to wrap it in a command for undo
      const nodeId = node.id;
      const nodeData = { ...node, data: { ...node.data } };

      // Undo should remove, redo should re-add
      // Since it's already added, the command just tracks state
      this.ctx.commandStack.execute({
        id: uuidv4(),
        label: 'Add Rectangle',
        execute: () => {
          this.ctx.scene.addNode(nodeData);
        },
        undo: () => {
          this.ctx.scene.removeNode(nodeId);
        },
      });

      this.ctx.scene.selectNode(nodeId);
    } else if (node) {
      // Too small — remove
      this.ctx.scene.removeNode(node.id);
    }

    this.ctx.engine.requestRedraw();
  }
}