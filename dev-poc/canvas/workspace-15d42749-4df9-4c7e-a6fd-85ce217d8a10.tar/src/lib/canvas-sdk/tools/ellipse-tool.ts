// ============================================================
// Ellipse Tool — Click+drag to draw ellipses
// ============================================================

import { v4 as uuidv4 } from 'uuid';
import { BaseTool, ToolContext } from '../plugin-api';

export class EllipseTool implements BaseTool {
  id = 'ellipse';
  name = 'Ellipse';
  shortcut = 'E';
  cursor = 'crosshair';

  private ctx: ToolContext | null = null;
  private isDrawing = false;
  private startX = 0;
  private startY = 0;
  private previewNode: string | null = null;

  activate(context: ToolContext): void {
    this.ctx = context;
  }

  deactivate(): void {
    if (this.previewNode && this.ctx) {
      this.ctx.scene.removeNode(this.previewNode);
      this.ctx.engine.requestRedraw();
    }
    this.ctx = null;
    this.previewNode = null;
  }

  onMouseDown(e: { button: number; worldX: number; worldY: number }): void {
    if (!this.ctx || e.button !== 0) return;

    this.isDrawing = true;
    this.startX = e.worldX;
    this.startY = e.worldY;

    const node = this.ctx.scene.addNode({
      type: 'ellipse',
      x: e.worldX,
      y: e.worldY,
      width: 0,
      height: 0,
      fill: this.ctx.options.fillColor ?? '#00f0ff',
      stroke: this.ctx.options.strokeColor ?? '#ffffff',
      strokeWidth: this.ctx.options.strokeWidth ?? 2,
    });
    this.previewNode = node.id;
  }

  onMouseMove(e: { worldX: number; worldY: number }): void {
    if (!this.ctx || !this.isDrawing || !this.previewNode) return;

    const x = Math.min(this.startX, e.worldX);
    const y = Math.min(this.startY, e.worldY);
    const w = Math.abs(e.worldX - this.startX);
    const h = Math.abs(e.worldY - this.startY);

    this.ctx.scene.updateNode(this.previewNode, { x, y, width: w, height: h });
    this.ctx.engine.requestRedraw();
  }

  onMouseUp(): void {
    if (!this.ctx || !this.isDrawing || !this.previewNode) return;

    const node = this.ctx.scene.getNode(this.previewNode);
    this.previewNode = null;
    this.isDrawing = false;

    if (node && node.width > 2 && node.height > 2) {
      const nodeId = node.id;
      const nodeData = { ...node, data: { ...node.data } };

      this.ctx.commandStack.execute({
        id: uuidv4(),
        label: 'Add Ellipse',
        execute: () => { this.ctx.scene.addNode(nodeData); },
        undo: () => { this.ctx.scene.removeNode(nodeId); },
      });

      this.ctx.scene.selectNode(nodeId);
    } else if (node) {
      this.ctx.scene.removeNode(node.id);
    }

    this.ctx.engine.requestRedraw();
  }
}