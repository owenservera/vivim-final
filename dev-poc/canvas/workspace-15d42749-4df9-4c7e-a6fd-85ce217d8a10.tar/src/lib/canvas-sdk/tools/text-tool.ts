// ============================================================
// Text Tool — Click to place text
// ============================================================

import { v4 as uuidv4 } from 'uuid';
import { BaseTool, ToolContext } from '../plugin-api';

export class TextTool implements BaseTool {
  id = 'text';
  name = 'Text';
  shortcut = 'T';
  cursor = 'text';

  private ctx: ToolContext | null = null;

  activate(context: ToolContext): void {
    this.ctx = context;
  }

  deactivate(): void {
    this.ctx = null;
  }

  onMouseDown(e: { button: number; worldX: number; worldY: number }): void {
    if (!this.ctx || e.button !== 0) return;

    // Use prompt for text input (simple approach for canvas-based tool)
    const text = 'Text';
    const nodeId = uuidv4();

    this.ctx.commandStack.execute({
      id: uuidv4(),
      label: 'Add Text',
      execute: () => {
        this.ctx.scene.addNode({
          id: nodeId,
          type: 'text',
          x: e.worldX,
          y: e.worldY,
          width: 100,
          height: 24,
          fill: this.ctx.options.fillColor ?? '#f5f7fb',
          stroke: 'transparent',
          strokeWidth: 0,
          data: {
            text,
            fontSize: this.ctx.options.fontSize ?? 20,
            fontFamily: 'Inter, system-ui, sans-serif',
          },
        });
        this.ctx.scene.selectNode(nodeId);
      },
      undo: () => {
        this.ctx.scene.removeNode(nodeId);
      },
    });

    this.ctx.engine.requestRedraw();
  }

  onDoubleClick(e: { worldX: number; worldY: number }): void {
    if (!this.ctx) return;

    // Find node at double-click position and allow editing
    const node = this.ctx.scene.hitTest({ x: e.worldX, y: e.worldY });
    if (node && node.type === 'text') {
      const newText = prompt('Edit text:', (node.data as { text: string }).text);
      if (newText !== null && newText.trim()) {
        const nodeId = node.id;
        const oldText = (node.data as { text: string }).text;
        const oldData = { ...node.data };

        this.ctx.commandStack.execute({
          id: uuidv4(),
          label: 'Edit Text',
          execute: () => {
            this.ctx.scene.updateNode(nodeId, {
              data: { ...oldData, text: newText },
            });
          },
          undo: () => {
            this.ctx.scene.updateNode(nodeId, { data: oldData });
          },
        });

        this.ctx.engine.requestRedraw();
      }
    }
  }

  onMouseMove(): void {}
  onMouseUp(): void {}
}