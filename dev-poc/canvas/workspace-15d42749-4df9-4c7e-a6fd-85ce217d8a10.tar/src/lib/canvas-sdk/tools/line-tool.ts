// ============================================================
// Line Tool — Click+drag to draw lines
// ============================================================

import { v4 as uuidv4 } from 'uuid';
import { BaseTool, ToolContext } from '../plugin-api';

export class LineTool implements BaseTool {
  id = 'line';
  name = 'Line';
  shortcut = 'L';
  cursor = 'crosshair';

  private ctx: ToolContext | null = null;
  private isDrawing = false;
  private previewNode: string | null = null;

  activate(context: ToolContext): void {
    this.ctx = context;
  }

  deactivate(): void {
    if (this.previewNode && this.ctx) {
      this.ctx.scene.removeNode(this.previewNode);
      this.ctx.engine.requestRedraw();
    }
    this.ctx = null;
    this.previewNode = null;
  }

  onMouseDown(e: { button: number; worldX: number; worldY: number }): void {
    if (!this.ctx || e.button !== 0) return;

    this.isDrawing = true;

    const node = this.ctx.scene.addNode({
      type: 'line',
      x: e.worldX,
      y: e.worldY,
      width: 0,
      height: 0,
      fill: 'transparent',
      stroke: this.ctx.options.strokeColor ?? '#fbbf24',
      strokeWidth: this.ctx.options.strokeWidth ?? 3,
      data: { x2: e.worldX, y2: e.worldY },
    });
    this.previewNode = node.id;
  }

  onMouseMove(e: { worldX: number; worldY: number }): void {
    if (!this.ctx || !this.isDrawing || !this.previewNode) return;

    this.ctx.scene.updateNode(this.previewNode, {
      data: { x2: e.worldX, y2: e.worldY },
    });
    this.ctx.engine.requestRedraw();
  }

  onMouseUp(): void {
    if (!this.ctx || !this.isDrawing || !this.previewNode) return;

    const node = this.ctx.scene.getNode(this.previewNode);
    this.previewNode = null;
    this.isDrawing = false;

    if (node) {
      const d = node.data as { x2: number; y2: number };
      const dist = Math.hypot(d.x2 - node.x, d.y2 - node.y);
      if (dist > 3) {
        const nodeId = node.id;
        const nodeData = { ...node, data: { ...node.data } };

        this.ctx.commandStack.execute({
          id: uuidv4(),
          label: 'Add Line',
          execute: () => { this.ctx.scene.addNode(nodeData); },
          undo: () => { this.ctx.scene.removeNode(nodeId); },
        });

        this.ctx.scene.selectNode(nodeId);
      } else {
        this.ctx.scene.removeNode(node.id);
      }
    }

    this.ctx.engine.requestRedraw();
  }
}