/* ============================================================
   @canvas-sdk/core — Type Definitions
   SOTA Canvas SDK primitive types. All coordinates are in
   world-space; the engine handles screen↔world transforms.
   ============================================================ */

export type Vec2 = { x: number; y: number };

export type BoundingBox = {
  x: number;
  y: number;
  width: number;
  height: number;
};

export type PropSchema = {
  type: 'string' | 'number' | 'color' | 'boolean' | 'select';
  label: string;
  defaultValue?: unknown;
  options?: string[];        // for select type
  min?: number; max?: number; // for number type
};

export interface Node {
  id: string;
  type: string;
  position: Vec2;
  rotation: number;
  boundingBox: BoundingBox;
  props: Record<string, unknown>;
  layerId: string;
  /** Human-readable documentation for SDK docs / inspector */
  documentation?: string;
  /** Schema describing which props are editable in the inspector */
  editableProps?: Record<string, PropSchema>;
  /** Computed every frame – set by renderers */
  _dirty?: boolean;
}

export interface Connection {
  id: string;
  fromNodeId: string;
  toNodeId: string;
  fromAnchor?: Vec2;
  toAnchor?: Vec2;
  label?: string;
  color?: string;
}

export interface ZLayer {
  id: string;
  z: number;
  name: string;
  visible: boolean;
  locked: boolean;
}

export type ThemeTokens = {
  bg: string;
  bgSecondary: string;
  bgTertiary: string;
  bgGlass: string;
  fg: string;
  fgSecondary: string;
  fgMuted: string;
  border: string;
  borderLight: string;
  accent: string;
  accentFg: string;
  accentSoft: string;
  success: string;
  warn: string;
  danger: string;
  info: string;
  grid: string;
  glow: string;
};

export interface Theme {
  id: string;
  name: string;
  tokens: ThemeTokens;
}