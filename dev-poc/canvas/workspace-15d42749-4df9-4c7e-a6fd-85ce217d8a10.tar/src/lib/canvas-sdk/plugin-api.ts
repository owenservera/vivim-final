/* ============================================================
   @canvas-sdk/plugin-sdk — Interfaces
   Consumer-facing API for building tools, renderers, and plugins.
   ============================================================ */

import type { Node, BoundingBox, Vec2, PropSchema } from '../core/types';
import type { CanvasEngine } from '../core/engine';
import type { Command } from '../core/command-stack';

export interface ToolContext {
  engine: CanvasEngine;
  getMouseWorld(): Vec2;
  getMouseScreen(): Vec2;
  selectNode(id: string | null): void;
  getSelectedNodeId(): string | null;
}

export interface BaseTool {
  name: string;
  label: string;
  icon?: string;
  cursor?: string;
  activate(ctx: ToolContext): void;
  deactivate(): void;
  onMouseDown?(e: PointerEvent): void;
  onMouseMove?(e: PointerEvent): void;
  onMouseUp?(e: PointerEvent): void;
  onKeyDown?(e: KeyboardEvent): void;
  renderOverlay?(ctx: CanvasRenderingContext2D): void;
}

export interface NodeRenderer {
  type: string;
  render(ctx: CanvasRenderingContext2D, node: Node): void;
  getBoundingBox?(props: Record<string, unknown>): BoundingBox;
  getDefaultProps?(): Record<string, unknown>;
  getEditableProps?(): Record<string, PropSchema>;
  getDocumentation?(): string;
}

export interface CommandFactory {
  (engine: CanvasEngine, ...args: unknown[]): Command;
}

export interface Plugin {
  name: string;
  version?: string;
  install(api: PluginAPI): void;
}

export interface PluginAPI {
  registerTool: (tool: BaseTool) => void;
  registerNodeRenderer: (renderer: NodeRenderer) => void;
  registerCommand: (id: string, factory: CommandFactory) => void;
  engine: CanvasEngine;
}