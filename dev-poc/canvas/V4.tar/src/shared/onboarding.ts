/**
 * shared/onboarding.ts
 * --------------------------------------------------------------------
 * #5 Onboarding Tour — first-run interactive walkthrough.
 * 5 steps, dismissible, re-triggerable from settings.
 */

export interface OnboardingStep {
  id: string;
  title: string;
  body: string;
  /** CSS selector for the highlight target (optional). */
  targetSelector?: string;
  /** Placement of the popover relative to the target. */
  placement?: 'bottom' | 'top' | 'left' | 'right' | 'center';
  /** Action label (e.g. "Switch workspace"). */
  actionLabel?: string;
  /** Action URL or command. */
  actionCommand?: string;
}

export const ONBOARDING_STEPS: OnboardingStep[] = [
  {
    id: 'welcome',
    title: 'Welcome to Vivim',
    body: 'A plugin-based, hot-swappable, live-configurable workspace OS. Every region is a card you can grab, move, or replace. Let\'s take a 30-second tour.',
    placement: 'center',
  },
  {
    id: 'workspace-switcher',
    title: 'Switch workspaces',
    body: 'The global workspace is always here. Click "Research Lab" or "Automation Lab" to switch rooms — the canvas re-resolves under a new traceId, no reload.',
    targetSelector: '[data-onboarding="workspace-switcher"]',
    placement: 'right',
    actionLabel: 'Try it',
  },
  {
    id: 'surface-tabs',
    title: '6 surfaces, one canvas',
    body: 'Tabs switch between Chat / Documents / Media / Automation / Agents / Shell. Each surface is a z-depth layer in the workspace stack.',
    targetSelector: '[data-onboarding="surface-tabs"]',
    placement: 'bottom',
  },
  {
    id: 'shell-card',
    title: 'The canvas is a CLI surface',
    body: 'Open the Shell tab and type "admin db status" — the canvas dispatches through the SAME CommandRegistry the thin CLI client uses. Two-way.',
    targetSelector: '[data-onboarding="shell-tab"]',
    placement: 'bottom',
    actionLabel: 'Open Shell',
    actionCommand: 'switch-surface:shell',
  },
  {
    id: 'command-palette',
    title: 'Press ⌘K anywhere',
    body: 'The Command Palette fuzzy-searches commands, docs, automations, agents, workspaces. Try ⌘K (or Ctrl+K) now.',
    placement: 'center',
    actionLabel: 'Got it',
  },
];

export interface OnboardingState {
  userId: string;
  completedSteps: string[];
  dismissed: boolean;
  /** When the tour was last shown (ms). */
  lastShownAt?: number;
  createdAt: number;
  updatedAt: number;
}
