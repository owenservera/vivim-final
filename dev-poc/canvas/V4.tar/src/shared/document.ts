/**
 * shared/document.ts
 * --------------------------------------------------------------------
 * Document card types. Every document opened in the canvas becomes a
 * Document Card: a CanvasDefinition wrapper carrying an `engineRef` so
 * it can be upgraded by plugins later (Frontend=Backend, UI-is-Data).
 *
 * Supported mime types (Phase 2 §1):
 *   - PDF            → pdfjs-dist
 *   - Office (.docx) → mammoth
 *   - .pptx          → pptxtojson
 *   - .xlsx          → exceljs
 *   - Markdown       → react-markdown + remark/rehype
 *   - Code           → shiki
 *   - Plain text     → native
 *
 * The DocumentEngine picks the renderer by mime; plugins can register a
 * better renderer for the same mimeType and hot-swap in via the existing
 * `registerSlot(slot, slug, Component, opts)` precedence
 * (capabilitySlug > providerSlug > default).
 */

export type DocumentMimeType =
  | 'application/pdf'
  | 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' // .docx
  | 'application/vnd.openxmlformats-officedocument.presentationml.presentation' // .pptx
  | 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' // .xlsx
  | 'text/markdown'
  | 'text/x-markdown'
  | 'text/plain'
  | 'text/html'
  | 'application/json'
  | 'text/typescript'
  | 'text/javascript'
  | 'text/python'
  | 'text/css'
  | 'text/yaml';

export type DocumentEngine = 'pdf' | 'docx' | 'pptx' | 'xlsx' | 'markdown' | 'code' | 'text' | 'html';

export interface DocumentCard {
  id: string;
  slug: string;
  title: string;
  mimeType: DocumentMimeType | string;
  engine: DocumentEngine | string;
  /** Blob URL or data URL the renderer fetches. */
  sourceUrl?: string;
  /** Inline content (for short docs, code snippets, markdown). */
  inlineContent?: string;
  /** Programming language hint for code documents. */
  language?: string;
  /** Page count (PDFs, slides). */
  pageCount?: number;
  /** Word count (text docs). */
  wordCount?: number;
  /** Page currently open (PDFs). */
  currentPage?: number;
  /** SHA-256 of content (dedupe + integrity check). */
  contentHash?: string;
  /** WorkspaceId this doc belongs to (null = global). */
  workspaceId: string | null;
  /** Engine reference — plugins can hot-swap the renderer. */
  engineRef: string; // e.g. 'engine:document:pdf'
  /** Capabilities this document card may invoke. */
  capabilities: string[];
  annotations: string[]; // annotation ids
  createdAt: number;
  updatedAt: number;
}

export interface DocumentOpenInput {
  title: string;
  mimeType: DocumentMimeType | string;
  sourceUrl?: string;
  inlineContent?: string;
  language?: string;
  workspaceId?: string;
}

export interface DocumentSearchHit {
  documentId: string;
  page?: number;
  snippet: string;
  score: number;
}
