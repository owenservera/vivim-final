/**
 * cli/commands/shell.ts
 * --------------------------------------------------------------------
 * The thin CLI client's command catalog. Registers multi-word commands
 * (`admin db status`, `list conversations`, `resolve canvas`, …) into
 * the ShellCommandStore (CommandRegistry). The canvas
 * `cap:canvas:shell-command` capability dispatches through the SAME
 * registry (FRONTEND=BACKEND two-way, invariant 5).
 *
 * Each command is registered with:
 *   - path: ['admin', 'db', 'status']
 *   - capabilityId: 'cap:admin:db_status'
 *   - handler: async (args, ctx) => ShellCommandResult
 *
 * Production swaps the stub handlers for real capability dispatch
 * via /api/capabilities/:id/execute. The resolution + longest-prefix-
 * match logic stays identical.
 */

import type { CommandSpec, ShellCommandContext, ShellCommandResult } from '../../shared/shell-command';
import type { ShellCommandStore } from '../../storage/contracts/shell-command-store';

/**
 * Register the default command catalog. Called once at boot by the
 * engine bootstrap. Each command's handler is a stub that returns a
 * ShellCommandResult; production swaps in real capability dispatch.
 */
export function registerDefaultCommands(store: ShellCommandStore): void {
  const commands: CommandSpec[] = [
    // ── admin ──────────────────────────────────────────────────────────
    {
      path: ['admin', 'db', 'status'],
      description: 'Show database row counts + file size',
      capabilityId: 'cap:admin:db_status',
      handler: async (_args, ctx) => ok(ctx, [
        '═ vivim-final db status ════════════════════',
        '  provider_type:        5 rows',
        '  primitive:           13 rows',
        '  ui_component:        22 rows',
        '  provider_definition: 16 rows',
        '  workspace:            3 rows',
        '  document:             4 rows',
        '  media:                2 rows',
        '  automation:         100 rows',
        '  agent:                3 rows',
        '  trace_entry:        248 rows',
        '  db size:           4.2 MB',
        '  integrity_check:    ok',
      ].join('\n')),
    },
    {
      path: ['admin', 'db', 'migrate'],
      description: 'Apply pending Prisma migrations',
      capabilityId: 'cap:admin:db_migrate',
      handler: async (_args, ctx) => ok(ctx, 'No pending migrations. Schema is up to date.'),
    },
    {
      path: ['admin', 'db', 'reset'],
      description: 'Wipe + migrate + seed (destructive)',
      capabilityId: 'cap:admin:db_reset',
      handler: async (_args, ctx) => ok(ctx, 'Reset aborted: --force flag required for destructive ops.'),
    },
    {
      path: ['admin', 'invariants', 'check'],
      description: 'Verify all 13 project invariants',
      capabilityId: 'cap:admin:invariants_check',
      handler: async (_args, ctx) => ok(ctx, [
        '═ invariants check ════════════════════════',
        '  ✓ Governor Canon     (no engine imports BunCdpClient)',
        '  ✓ Store Contracts    (engines use contracts/* only)',
        '  ✓ Frontend=Backend   (no provider conditionals in UI)',
        '  ✓ UI-is-Data         (sandboxed iframe + CSP)',
        '  ✓ One Entry Point    (/api/interpret → /api/capabilities/:id/execute)',
        '  ✓ No any             (strict + unknown narrowing)',
        '  ✓ Live, not build    (publish = DB write + event)',
        '  ✓ Action Registry    (B8 — Zod-validated)',
        '  ✓ No new canvas migrations',
        '  ✓ Phase 2: FRONTEND=BACKEND two-way (cap:canvas:shell-command)',
        '  ✓ Phase 2: workspace z-depth (3D layer model)',
        '  ✓ Phase 2: doc/media/automation/agent cards',
      ].join('\n')),
    },

    // ── list ───────────────────────────────────────────────────────────
    {
      path: ['list', 'conversations'],
      description: 'List recent conversations',
      capabilityId: 'cap:conversation:list',
      handler: async (_args, ctx) => ok(ctx, [
        '═ conversations (workspace=' + ctx.workspaceId + ') ══════',
        '  conv:01HX…  chatgpt   4 messages   2024-01-15',
        '  conv:01HY…  claude    2 messages   2024-01-14',
        '  conv:01HZ…  gemini    8 messages   2024-01-14',
      ].join('\n')),
    },
    {
      path: ['list', 'providers'],
      description: 'List registered providers',
      capabilityId: 'cap:provider:list',
      handler: async (_args, _ctx) => ok(_ctx, [
        '═ providers ══════════════════════════════',
        '  chatgpt       (ai-chat family)   free/pro/ent',
        '  claude        (ai-chat family)   free/pro',
        '  gemini        (ai-chat family)   free',
        '  gmail         (email family)     free/ent',
        '  slack         (messenger family) free/ent',
        '  twitter       (social family)    free',
        '  notion        (custom family)    free',
      ].join('\n')),
    },
    {
      path: ['list', 'workspaces'],
      description: 'List workspaces (parent + children)',
      capabilityId: 'cap:workspace:list',
      handler: async (_args, ctx) => ok(ctx, [
        '═ workspaces ═════════════════════════════',
        '  ws:global            (global, z=0)  ← current',
        '  ws:research          (standard, z=1)',
        '  ws:content-team      (standard, z=1)',
        '  ws:automation-lab    (automation, z=1)',
      ].join('\n')),
    },
    {
      path: ['list', 'automations'],
      description: 'List automation definitions',
      capabilityId: 'cap:automation:list',
      handler: async (_args, ctx) => ok(ctx, [
        '═ automations (workspace=' + ctx.workspaceId + ') ════',
        '  summarize-new-doc           published  trigger=event',
        '  transcribe-and-clip-video   published  trigger=manual',
        '  route-message-to-notion     published  trigger=event',
        '  daily-digest                published  trigger=cron',
        '  … 100 automations total',
      ].join('\n')),
    },
    {
      path: ['list', 'agents'],
      description: 'List agent definitions',
      capabilityId: 'cap:agent:list',
      handler: async (_args, _ctx) => ok(_ctx, [
        '═ agents ════════════════════════════════',
        '  research-assistant    published  5 steps',
        '  content-curator       published  7 steps',
        '  inbox-triager         published  4 steps',
      ].join('\n')),
    },

    // ── resolve / open ─────────────────────────────────────────────────
    {
      path: ['resolve', 'canvas'],
      description: 'Synchronously resolve the canvas surface',
      capabilityId: 'cap:canvas:resolve',
      handler: async (_args, ctx) => ok(ctx, [
        '═ canvas resolved ════════════════════════',
        '  traceId:    ' + ctx.traceId,
        '  workspace:  ' + ctx.workspaceId,
        '  surface:    chat',
        '  slots:      13',
        '  duration:   8ms',
      ].join('\n')),
    },
    {
      path: ['open', 'document'],
      description: 'Open a document card (open document <path>)',
      capabilityId: 'cap:document:open',
      handler: async (args, ctx) => ok(ctx, `Opening document: ${args.join(' ') || '(no path)'}\n  → created doc card on canvas (engineRef=engine:document:pdf)`),
    },
    {
      path: ['open', 'video'],
      description: 'Open a video card (open video <url>)',
      capabilityId: 'cap:media:open_video',
      handler: async (args, ctx) => ok(ctx, `Opening video: ${args.join(' ') || '(no url)'}\n  → created media card on canvas (engine=vlc, transcript=stubbed)`),
    },
    {
      path: ['open', 'audio'],
      description: 'Open an audio card (open audio <url>)',
      capabilityId: 'cap:media:open_audio',
      handler: async (args, ctx) => ok(ctx, `Opening audio: ${args.join(' ') || '(no url)'}\n  → created media card on canvas (engine=vlc)`),
    },

    // ── publish / patch (live-config) ──────────────────────────────────
    {
      path: ['publish', 'component'],
      description: 'Publish a CanvasDefinition row (live, no rebuild)',
      capabilityId: 'cap:canvas:define',
      handler: async (args, ctx) => ok(ctx, `Published component: ${args.join(' ') || '(no slug)'}\n  → version=1, emitted canvas:def:updated`),
    },
    {
      path: ['patch', 'component'],
      description: 'Live-config patch an existing CanvasDefinition',
      capabilityId: 'cap:canvas:set_layout',
      handler: async (args, ctx) => ok(ctx, `Patched component: ${args.join(' ') || '(no id)'}\n  → version bumped, canvas:def:updated emitted`),
    },

    // ── run / invoke ───────────────────────────────────────────────────
    {
      path: ['run', 'automation'],
      description: 'Execute an automation by slug',
      capabilityId: 'cap:automation:execute',
      handler: async (args, ctx) => ok(ctx, `Running automation: ${args.join(' ') || '(no slug)'}\n  → execution started, walking DAG from trigger`),
    },
    {
      path: ['invoke', 'agent'],
      description: 'Invoke an agent by slug',
      capabilityId: 'cap:agent:invoke',
      handler: async (args, ctx) => ok(ctx, `Invoking agent: ${args.join(' ') || '(no slug)'}\n  → run started, walking step DAG from entry`),
    },

    // ── shell ──────────────────────────────────────────────────────────
    {
      path: ['help'],
      description: 'Show available commands',
      capabilityId: 'cap:help:help',
      handler: async (_args, ctx) => ok(ctx, [
        '═ vivim shell — available commands ════════',
        '  admin db status              Database row counts + size',
        '  admin db migrate             Apply pending migrations',
        '  admin invariants check       Verify all 13 invariants',
        '  list conversations           List recent conversations',
        '  list providers               List registered providers',
        '  list workspaces              List workspaces',
        '  list automations             List automation definitions',
        '  list agents                  List agent definitions',
        '  resolve canvas               Synchronously resolve the canvas',
        '  open document <path>         Open a document card',
        '  open video <url>             Open a video card (VLC)',
        '  open audio <url>             Open an audio card (VLC)',
        '  publish component <slug>     Publish a CanvasDefinition',
        '  patch component <id>         Live-config patch',
        '  run automation <slug>        Execute an automation',
        '  invoke agent <slug>          Invoke an agent',
        '  help                         Show this help',
      ].join('\n')),
    },
  ];

  for (const cmd of commands) {
    store.register(cmd);
  }
}

function ok(ctx: ShellCommandContext, stdout: string): ShellCommandResult {
  return {
    traceId: ctx.traceId,
    ok: true,
    exitCode: 0,
    stdout,
    stderr: '',
    durationMs: 0,
  };
}
