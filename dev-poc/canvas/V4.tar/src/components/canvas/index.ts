/**
 * components/canvas/index.ts — barrel.
 * Phase 2 adds: WorkspaceSwitcher + cards (Doc/Media/Automation/Agent/Shell).
 */
export { CanvasSurface } from './CanvasSurface';
export type { CanvasSurfaceProps } from './CanvasSurface';
export { CanvasNode } from './CanvasNode';
export type { CanvasNodeProps } from './CanvasNode';
export { SandboxedNode } from './SandboxedNode';
export type { SandboxedNodeProps, SandboxAuditEvent } from './SandboxedNode';
export { useResolvedNodes } from './use-resolved-nodes';
export { useCanvasEvents, getCanvasEventBus } from './use-canvas-events';
export type { CanvasEvent } from './use-canvas-events';
export { EventBus } from './event-bus';
export { CommandStack } from './command-stack';
export type { Command } from './command-stack';
export { QuadTree } from './quad-tree';
export type { BoundingBox, Vec2, QTEntry } from './quad-tree';
export { worldToScreen, screenToWorld, clampZoom } from './transform';
export type { ViewportState } from './transform';
export { LiveConfigProvider, useLiveConfig } from './LiveConfigProvider';
export type { LiveConfigContextValue, LiveConfigProviderProps } from './LiveConfigProvider';

// Phase 2
export { WorkspaceSwitcher } from './WorkspaceSwitcher';
export type { WorkspaceSwitcherProps } from './WorkspaceSwitcher';
export { DocCard, MediaCard, AutomationCard, AgentCard, ShellCard } from './cards';
export type { DocCardProps, MediaCardProps, AutomationCardProps, AgentCardProps } from './cards';

// Phase 3 — UX enhancements
export { ThemeProvider, useTheme, ACCENT_COLORS } from './ThemeProvider';
export { ThemeSettings } from './ThemeSettings';
export { CommandPalette } from './CommandPalette';
export type { CommandPaletteProps } from './CommandPalette';
export { NotificationsCenter } from './NotificationsCenter';
export { OnboardingTour } from './OnboardingTour';
export type { OnboardingTourProps } from './OnboardingTour';
export { QuickActionsMenu } from './QuickActionsMenu';
export type { QuickActionsMenuProps } from './QuickActionsMenu';
export { PresenceIndicator } from './PresenceIndicator';
export { AuditDashboard } from './AuditDashboard';
export { RbacManager } from './RbacManager';
export { TemplatesGallery } from './TemplatesGallery';
