/**
 * shared/index.ts — barrel for shared contract types.
 * Conceptual-model and ui-component both export a `ComponentContract`
 * type; we explicitly re-export under disambiguated names to avoid
 * the duplicate-export error (TS2308).
 */
export * from './canvas-types';
export {
  RESOLUTION_CHAIN,
  type ResolutionTier,
  type ProviderTypeSlug,
  type PrimitiveScope,
  type RegionRect,
  type SlotCatalogEntry,
  type GestureCatalog,
  type LayoutRule,
  type InteractionGrammar,
  type ProviderType,
  type Primitive,
  primitiveToSlotId,
} from './conceptual-model';
export type {
  UiComponentStatus,
  UiComponentAuthor,
  ComponentArchetype,
  ComponentConstraints,
  UiComponent,
  uiComponentKey,
} from './ui-component';
export * from './stream-blocks';
export * from './route-context';
