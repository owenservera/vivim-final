/**
 * engines/index.ts — public barrel.
 *
 * Engines depend ONLY on `src/storage/contracts/*` and `src/shared/*`.
 * No engine imports `src/storage/impl/*` or `BunCdpClient` (B1/B2).
 */
export { CapabilityEventBus } from './capability-event-bus';
export type { EngineEvent, EventHandler, WsLike } from './capability-event-bus';

export { StructuredLogger, TraceStore } from './structured-logger';
export type { StructuredLog, LogSink, Span, TraceEntry } from './structured-logger';

export {
  routeSync,
  onContextChange,
  resolveActions,
  resolveFamilies,
  slotToPrimitive,
  primitiveToSlotId,
  diffSurfaces,
} from './route-sync';
export type { RouteSyncDeps, SurfaceDelta } from './route-sync';

export { ConceptualModelService, buildRouteSyncDeps } from './conceptual-model-service';

export { CanvasLayerMounter } from './canvas-layer-mounter';
export type { LayerDefinition, MountedLayer } from './canvas-layer-mounter';

export { CapabilityResolutionEngine } from './capability-resolution';

export { CanvasRegistry } from './canvas-registry';

export { PluginManager } from './plugin-system';
export type { ProviderPlugin } from './plugin-system';

export { PluginHotReload } from './plugin-hot-reload';
export type {
  ProviderPlugin as HotReloadPlugin,
  PluginHandler,
  PluginErrorHandler,
  PluginUnloadHandler,
  DefChangeHandler,
} from './plugin-hot-reload';

export { AdaptiveWorkspace } from './adaptive-workspace';
export type { Workspace, WorkspaceMode } from './adaptive-workspace';
