/**
 * lib/canvas-engine-bootstrap.ts
 * --------------------------------------------------------------------
 * Server-side singleton wiring. Builds one bag of in-memory stores +
 * engines and reuses it across API route handlers. Production swaps the
 * memory impls for Prisma impls (still via the same contracts).
 */

import { CapabilityEventBus } from '../engines/capability-event-bus';
import { StructuredLogger, TraceStore } from '../engines/structured-logger';
import { CanvasLayerMounter } from '../engines/canvas-layer-mounter';
import { CanvasRegistry } from '../engines/canvas-registry';
import { PluginHotReload } from '../engines/plugin-hot-reload';
import { AdaptiveWorkspace } from '../engines/adaptive-workspace';
import { buildRouteSyncDeps } from '../engines/conceptual-model-service';
import {
  MemoryAccountStore,
  MemoryCanvasDefinitionStore,
  MemoryCapabilityTierStore,
  MemoryPrimitiveStore,
  MemoryProviderStore,
  MemoryProviderTypeStore,
  MemoryUiComponentStore,
  MemoryUserLayoutStore,
} from '../storage/impl';
import { ulid } from './ulid';

export interface CanvasEngineBag {
  eventBus: CapabilityEventBus;
  logger: StructuredLogger;
  traceStore: TraceStore;
  uiComponentStore: MemoryUiComponentStore;
  providerTypeStore: MemoryProviderTypeStore;
  primitiveStore: MemoryPrimitiveStore;
  providerStore: MemoryProviderStore;
  accountStore: MemoryAccountStore;
  capabilityTierStore: MemoryCapabilityTierStore;
  userLayoutStore: MemoryUserLayoutStore;
  canvasDefinitionStore: MemoryCanvasDefinitionStore;
  canvasRegistry: CanvasRegistry;
  layerMounter: CanvasLayerMounter;
  hotReload: PluginHotReload;
  workspace: AdaptiveWorkspace;
  routeSyncDeps: ReturnType<typeof buildRouteSyncDeps>;
}

let _bag: CanvasEngineBag | null = null;
let _seeded = false;

export function getEngineBag(): CanvasEngineBag {
  if (_bag) return _bag;
  const eventBus = CapabilityEventBus.getInstance();
  const logger = new StructuredLogger('info');
  const traceStore = new TraceStore();
  logger.addSink((entry) => {
    if (entry.traceId && entry.spanId) {
      traceStore.append({
        id: entry.spanId,
        traceId: entry.traceId,
        spanId: entry.spanId,
        parentSpanId: entry.parentSpanId,
        engine: entry.engine ?? 'unknown',
        method: entry.msg,
        durationMs: entry.durationMs ?? 0,
        ok: !entry.msg.toLowerCase().includes('error'),
        createdAt: entry.ts,
      });
    }
  });

  const uiComponentStore = new MemoryUiComponentStore();
  const providerTypeStore = new MemoryProviderTypeStore();
  const primitiveStore = new MemoryPrimitiveStore();
  const providerStore = new MemoryProviderStore();
  const accountStore = new MemoryAccountStore();
  const capabilityTierStore = new MemoryCapabilityTierStore();
  const userLayoutStore = new MemoryUserLayoutStore();
  const canvasDefinitionStore = new MemoryCanvasDefinitionStore();

  const canvasRegistry = new CanvasRegistry(canvasDefinitionStore, eventBus);
  const layerMounter = new CanvasLayerMounter(eventBus);
  const hotReload = new PluginHotReload();
  const routeSyncDeps = buildRouteSyncDeps({
    eventBus,
    logger,
    uiComponentStore,
    providerTypeStore,
    primitiveStore,
    providerStore,
    accountStore,
    capabilityTierStore,
  });
  const workspace = new AdaptiveWorkspace(routeSyncDeps, eventBus, logger);

  _bag = {
    eventBus,
    logger,
    traceStore,
    uiComponentStore,
    providerTypeStore,
    primitiveStore,
    providerStore,
    accountStore,
    capabilityTierStore,
    userLayoutStore,
    canvasDefinitionStore,
    canvasRegistry,
    layerMounter,
    hotReload,
    workspace,
    routeSyncDeps,
  };
  return _bag;
}

/** Idempotent seed flag — set after the first seedCanvasModel() run. */
export function isSeeded(): boolean {
  return _seeded;
}
export function markSeeded(): void {
  _seeded = true;
}

export function newTraceId(): string {
  return ulid();
}
