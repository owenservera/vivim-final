'use client';

/**
 * app/page.tsx — the Vivim Universal Canvas.
 * --------------------------------------------------------------------
 * The unified canvas surface. The shell is dumb (P2): it renders
 * whatever routeSync resolves. No provider conditionals. No hardcoded
 * tools. The richness lives in:
 *   - backend routeSync (data-driven)
 *   - CanvasDefinition rows (DB-driven UI)
 *   - UIComponentRegistry (live hot-swap)
 *
 * A panel on the left lets you switch workspace / providers / accounts
 * and triggers a live re-resolve (bundle 02 §D onContextChange).
 */

import { useState } from 'react';
import { CanvasSurface } from '@/components/canvas';
import { LiveConfigProvider, useLiveConfig } from '@/components/canvas/LiveConfigProvider';
import type { AccountContext, PlanTier } from '@/shared/route-context';

const PROVIDER_OPTIONS = [
  { id: 'chatgpt', label: 'ChatGPT (ai-chat)', family: 'ai-chat' },
  { id: 'claude', label: 'Claude (ai-chat)', family: 'ai-chat' },
  { id: 'gemini', label: 'Gemini (ai-chat)', family: 'ai-chat' },
  { id: 'gmail', label: 'Gmail (email)', family: 'email' },
  { id: 'outlook', label: 'Outlook (email)', family: 'email' },
  { id: 'whatsapp', label: 'WhatsApp (messenger)', family: 'messenger' },
  { id: 'slack', label: 'Slack (messenger)', family: 'messenger' },
  { id: 'telegram', label: 'Telegram (messenger)', family: 'messenger' },
  { id: 'twitter', label: 'Twitter (social)', family: 'social' },
  { id: 'linkedin', label: 'LinkedIn (social)', family: 'social' },
  { id: 'mastodon', label: 'Mastodon (social)', family: 'social' },
  { id: 'notion', label: 'Notion (custom)', family: 'custom' },
  { id: 'linear', label: 'Linear (custom)', family: 'custom' },
];

const TIER_OPTIONS: PlanTier[] = ['free', 'trial', 'pro', 'enterprise'];

export default function Home() {
  return (
    <LiveConfigProvider
      initialWorkspaceId="ws:demo"
      initialUserId="user:demo"
      initialProviderIds={['chatgpt']}
      initialAccounts={[
        { accountId: 'acct:chatgpt:free', providerId: 'chatgpt', planTier: 'free' },
      ]}
    >
      <CanvasApp />
    </LiveConfigProvider>
  );
}

function CanvasApp() {
  const {
    surface,
    isLoading,
    error,
    workspaceId,
    setWorkspace,
    providerIds,
    setProviderIds,
    accounts,
    setAccounts,
    variant,
    setVariant,
  } = useLiveConfig();

  const [draftVariant, setDraftVariant] = useState('');

  const toggleProvider = (id: string) => {
    const isOn = providerIds.includes(id);
    if (isOn) {
      const next = providerIds.filter((p) => p !== id);
      setProviderIds(next);
      setAccounts(accounts.filter((a) => a.providerId !== id));
    } else {
      setProviderIds([...providerIds, id]);
      setAccounts([
        ...accounts,
        { accountId: `acct:${id}:free`, providerId: id, planTier: 'free' as const },
      ]);
    }
  };

  const cycleTier = (providerId: string) => {
    setAccounts(
      accounts.map((a) => {
        if (a.providerId !== providerId) return a;
        const idx = TIER_OPTIONS.indexOf(a.planTier);
        const next = TIER_OPTIONS[(idx + 1) % TIER_OPTIONS.length]!;
        return { ...a, planTier: next };
      }),
    );
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        display: 'flex',
        fontFamily: 'ui-sans-serif, system-ui, -apple-system, sans-serif',
        background: '#fafafa',
        color: '#1f2937',
      }}
    >
      {/* Sidebar — workspace / provider / account / variant controls */}
      <aside
        style={{
          width: 280,
          flexShrink: 0,
          borderRight: '1px solid #e5e7eb',
          background: 'white',
          overflowY: 'auto',
          padding: 16,
          display: 'flex',
          flexDirection: 'column',
          gap: 16,
        }}
      >
        <header>
          <h1 style={{ margin: 0, fontSize: 18, fontWeight: 700 }}>Vivim Universal Canvas</h1>
          <p style={{ margin: '4px 0 0', fontSize: 11, color: '#6b7280' }}>
            Plugin-based • Hot-swappable • Live-configurable
          </p>
        </header>

        <section>
          <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Workspace
          </label>
          <input
            type="text"
            value={workspaceId}
            onChange={(e) => setWorkspace(e.target.value)}
            style={{
              width: '100%',
              marginTop: 4,
              padding: '6px 8px',
              border: '1px solid #d1d5db',
              borderRadius: 4,
              fontSize: 12,
              fontFamily: 'ui-monospace, monospace',
            }}
          />
        </section>

        <section>
          <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Variant
          </label>
          <div style={{ display: 'flex', gap: 4, marginTop: 4 }}>
            <input
              type="text"
              value={draftVariant}
              placeholder="e.g. opus, workspace, voice"
              onChange={(e) => setDraftVariant(e.target.value)}
              style={{
                flex: 1,
                padding: '6px 8px',
                border: '1px solid #d1d5db',
                borderRadius: 4,
                fontSize: 12,
                fontFamily: 'ui-monospace, monospace',
              }}
            />
            <button
              onClick={() => setVariant(draftVariant || undefined)}
              style={{
                padding: '6px 10px',
                border: '1px solid #d1d5db',
                background: '#f3f4f6',
                borderRadius: 4,
                fontSize: 12,
                cursor: 'pointer',
              }}
            >
              Set
            </button>
            <button
              onClick={() => {
                setVariant(undefined);
                setDraftVariant('');
              }}
              style={{
                padding: '6px 10px',
                border: '1px solid #d1d5db',
                background: '#f3f4f6',
                borderRadius: 4,
                fontSize: 12,
                cursor: 'pointer',
              }}
            >
              Clear
            </button>
          </div>
          {variant && (
            <div style={{ marginTop: 4, fontSize: 11, color: '#6b7280' }}>
              Current: <code>{variant}</code>
            </div>
          )}
        </section>

        <section>
          <label style={{ fontSize: 11, fontWeight: 600, color: '#6b7280', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            Providers ({providerIds.length})
          </label>
          <ul style={{ listStyle: 'none', padding: 0, margin: '4px 0 0', display: 'flex', flexDirection: 'column', gap: 2 }}>
            {PROVIDER_OPTIONS.map((p) => {
              const isOn = providerIds.includes(p.id);
              const acct = accounts.find((a) => a.providerId === p.id);
              return (
                <li key={p.id}>
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 6,
                      padding: '4px 6px',
                      borderRadius: 4,
                      background: isOn ? '#f0fdf4' : 'transparent',
                      border: isOn ? '1px solid #86efac' : '1px solid transparent',
                    }}
                  >
                    <input
                      type="checkbox"
                      checked={isOn}
                      onChange={() => toggleProvider(p.id)}
                      style={{ margin: 0 }}
                    />
                    <span style={{ flex: 1, fontSize: 12 }}>{p.label}</span>
                    {isOn && acct && (
                      <button
                        onClick={() => cycleTier(p.id)}
                        title="Cycle plan tier"
                        style={{
                          padding: '1px 6px',
                          border: '1px solid #d1d5db',
                          background: 'white',
                          borderRadius: 3,
                          fontSize: 10,
                          cursor: 'pointer',
                          fontFamily: 'ui-monospace, monospace',
                        }}
                      >
                        {acct.planTier}
                      </button>
                    )}
                  </div>
                </li>
              );
            })}
          </ul>
        </section>

        <section style={{ marginTop: 'auto', fontSize: 10, color: '#9ca3af', borderTop: '1px solid #e5e7eb', paddingTop: 8 }}>
          <div>trace: <code>{surface?.traceId.slice(0, 16)}…</code></div>
          <div>resolved in {surface?.durationMs ?? '—'}ms</div>
          <div>slots: {surface?.slots.length ?? 0}</div>
          {isLoading && <div style={{ color: '#f59e0b' }}>resolving…</div>}
          {error && <div style={{ color: '#dc2626' }}>error: {String(error.message)}</div>}
        </section>
      </aside>

      {/* Main canvas surface */}
      <main style={{ flex: 1, position: 'relative' }}>
        <CanvasSurface
          workspaceId={workspaceId}
          userId="user:demo"
          providerIds={providerIds}
          accounts={accounts}
          variant={variant}
        />
      </main>
    </div>
  );
}
